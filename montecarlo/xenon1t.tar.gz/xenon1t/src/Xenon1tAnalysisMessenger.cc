#include <G4Geantino.hh>
#include <G4ThreeVector.hh>
#include <G4ParticleTable.hh>
#include <G4UIdirectory.hh>
#include <G4UIcmdWithoutParameter.hh>
#include <G4UIcmdWithAString.hh>
#include <G4UIcmdWithADoubleAndUnit.hh>
#include <G4UIcmdWith3Vector.hh>
#include <G4UIcmdWith3VectorAndUnit.hh>
#include <G4UIcmdWithAnInteger.hh>
#include <G4UIcmdWithADouble.hh>
#include <G4UIcmdWithABool.hh>
#include <G4Tokenizer.hh>
#include <G4ios.hh>
#include <fstream>
#include <iomanip>

#include "Xenon1tAnalysisMessenger.hh"
#include "Xenon1tAnalysisManager.hh"

Xenon1tAnalysisMessenger::Xenon1tAnalysisMessenger(Xenon1tAnalysisManager *pAnalysis):
m_pAnalysis(pAnalysis)
{
	// create directory
	m_pDirectory = new G4UIdirectory("/analysis/settings/");
	m_pDirectory->SetGuidance("Analysis control commands.");

	// save detailed infos for PMT hits
	m_pPMTHitsDetailsCmd = new G4UIcmdWithABool("/analysis/settings/setPMTdetails", this);
	m_pPMTHitsDetailsCmd->SetGuidance("Choose to register or not XYZ of PMTHits for Optical Photons");
	m_pPMTHitsDetailsCmd->SetParameterName("PMTHitsDetails", false); 
	m_pPMTHitsDetailsCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	// print step infos for photons
	m_pOptPhotStepsInfosCmd = new G4UIcmdWithABool("/analysis/settings/setOptStepInfos", this);
	m_pOptPhotStepsInfosCmd->SetGuidance("Choose to print or not infos abouts optical photons steps");
	m_pOptPhotStepsInfosCmd->SetParameterName("OptPhotInfos", false); 
	m_pOptPhotStepsInfosCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

}

Xenon1tAnalysisMessenger::~Xenon1tAnalysisMessenger()
{
	delete m_pDirectory;
	delete m_pPMTHitsDetailsCmd;
	delete m_pOptPhotStepsInfosCmd;
}

void
Xenon1tAnalysisMessenger::SetNewValue(G4UIcommand * command, G4String newValues)
{
  if(command == m_pPMTHitsDetailsCmd){
    m_pAnalysis->SetPMTHitsDetails(m_pPMTHitsDetailsCmd->GetNewBoolValue(newValues));
  }
  if(command == m_pOptPhotStepsInfosCmd){
    m_pAnalysis->SetOptPhotStepsInfos(m_pOptPhotStepsInfosCmd->GetNewBoolValue(newValues));
  }
  

}

