#include <G4UnitsTable.hh>
#include <G4VVisManager.hh>
#include <G4Circle.hh>
#include <G4Colour.hh>
#include <G4VisAttributes.hh>

#include "Xenon1tLXeHit.hh"

G4Allocator<Xenon1tLXeHit> Xenon1tLXeHitAllocator;

Xenon1tLXeHit::Xenon1tLXeHit() {}

Xenon1tLXeHit::~Xenon1tLXeHit()
{
	if(m_pParticleType) delete m_pParticleType;
	if(m_pParentType) delete m_pParentType;
	if(m_pCreatorProcess) delete m_pCreatorProcess;
	if(m_pDepositingProcess) delete m_pDepositingProcess;
}

Xenon1tLXeHit::Xenon1tLXeHit(const Xenon1tLXeHit &hXenon1tLXeHit):G4VHit()
{
	m_iTrackId = hXenon1tLXeHit.m_iTrackId;
	m_iParentId = hXenon1tLXeHit.m_iParentId;
	m_pParticleType = hXenon1tLXeHit.m_pParticleType;
	m_pParentType = hXenon1tLXeHit.m_pParentType ;
	m_pCreatorProcess = hXenon1tLXeHit.m_pCreatorProcess ;
	m_pDepositingProcess = hXenon1tLXeHit.m_pDepositingProcess ;
	m_hPosition = hXenon1tLXeHit.m_hPosition;
	m_dEnergyDeposited = hXenon1tLXeHit.m_dEnergyDeposited;
	m_dKineticEnergy = hXenon1tLXeHit.m_dKineticEnergy ;
	m_dPreStepEnergy = hXenon1tLXeHit.m_dPreStepEnergy ;
	m_dPostStepEnergy = hXenon1tLXeHit.m_dPostStepEnergy ;
	m_dTime = hXenon1tLXeHit.m_dTime;
}

const Xenon1tLXeHit &
Xenon1tLXeHit::operator=(const Xenon1tLXeHit &hXenon1tLXeHit)
{
	m_iTrackId = hXenon1tLXeHit.m_iTrackId;
	m_iParentId = hXenon1tLXeHit.m_iParentId;
	m_pParticleType = hXenon1tLXeHit.m_pParticleType;
	m_pParentType = hXenon1tLXeHit.m_pParentType ;
	m_pCreatorProcess = hXenon1tLXeHit.m_pCreatorProcess ;
	m_pDepositingProcess = hXenon1tLXeHit.m_pDepositingProcess ;
	m_hPosition = hXenon1tLXeHit.m_hPosition;
	m_dEnergyDeposited = hXenon1tLXeHit.m_dEnergyDeposited;
	m_dKineticEnergy = hXenon1tLXeHit.m_dKineticEnergy ;
	m_dPreStepEnergy = hXenon1tLXeHit.m_dPreStepEnergy ;
	m_dPostStepEnergy = hXenon1tLXeHit.m_dPostStepEnergy ;
	m_dTime = hXenon1tLXeHit.m_dTime;
	
	return *this;
}

G4int
Xenon1tLXeHit::operator==(const Xenon1tLXeHit &hXenon1tLXeHit) const
{
	return ((this == &hXenon1tLXeHit) ? (1) : (0));
}

void Xenon1tLXeHit::Draw()
{
	G4VVisManager* pVVisManager = G4VVisManager::GetConcreteInstance();
	
	if(pVVisManager)
	{
		G4Circle hCircle(m_hPosition);
		G4Colour hColour(1.000, 0.973, 0.184);
		G4VisAttributes hVisAttributes(hColour);
		
		hCircle.SetScreenSize(0.1);
		hCircle.SetFillStyle(G4Circle::filled);
		hCircle.SetVisAttributes(hVisAttributes);
		pVVisManager->Draw(hCircle);
	}
}

void Xenon1tLXeHit::Print()
{
	G4cout << "-------------------- LXe hit --------------------" 
		<< "Id: " << m_iTrackId
		<< " Particle: " << *m_pParticleType
		<< " ParentId: " << m_iParentId
		<< " ParentType: " << *m_pParentType << G4endl
		<< "CreatorProcess: " << *m_pCreatorProcess
		<< " DepositingProcess: " << *m_pDepositingProcess << G4endl
		<< "Position: " << m_hPosition.x()/mm
		<< " " << m_hPosition.y()/mm
		<< " " << m_hPosition.z()/mm
		<< " mm" << G4endl
		<< " EnergyDeposited: " << m_dEnergyDeposited/keV << " keV"
		<< " KineticEnergyLeft: " << m_dKineticEnergy/keV << " keV"
	  	<< " PreStepEnergy:" << m_dPreStepEnergy/keV << " keV"
		<< " PostStepEnergy: " << m_dPostStepEnergy/keV << " keV"
		<< " Time: " << m_dTime/s << " s" << G4endl;
}

