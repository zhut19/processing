#include <G4PVPlacement.hh>
#include <G4Material.hh>
#include <globals.hh>
#include <G4SDManager.hh> 

#include "Xenon1tPMTsR8520.hh"

// Class describing the 1" square PMT used in XENON100
// Cyril: 2013/10/14

Xenon1tPMTsR8520::Xenon1tPMTsR8520(Xenon1tDetectorConstruction* det): pDetectorConstrution(det)
{
  //pMaterials = pDetectorConstrution->GetMaterialInstance();

  dVetoPmtWidth = det->GetGeometryParameter("LXeVetoPmtWidth");
  dVetoPmtSpacing = det->GetGeometryParameter("LXeVetoPmtSpacing");
  dVetoPmtWindowWidth = det->GetGeometryParameter("LXeVetoPmtWindowWidth");
  dVetoPmtCasingThickness = det->GetGeometryParameter("LXeVetoPmtCasingThickness");
  dVetoPmtPhotoCathodeWidth = det->GetGeometryParameter("LXeVetoPmtPhotoCathodeWidth");
  dVetoPmtPhotoCathodeThickness = det->GetGeometryParameter("LXeVetoPmtPhotoCathodeThickness");
  dVetoPmtBaseSpacerHeight= det->GetGeometryParameter("LXeVetoPmtBaseSpacerHeight");
  
  dVetoPmtCasingHeight = det->GetGeometryParameter("LXeVetoPmtCasingHeight");
  dVetoPmtCasingWidth = det->GetGeometryParameter("LXeVetoPmtCasingWidth");
  dVetoPmtWindowThickness = det->GetGeometryParameter("LXeVetoPmtWindowThickness");
  dVetoPmtBaseThickness = det->GetGeometryParameter("LXeVetoPmtBaseThickness");
  dVetoPmtToPmtBase = det->GetGeometryParameter("LXeVetoPmtToPmtBase");

}

Xenon1tPMTsR8520::~Xenon1tPMTsR8520()
{;}

G4LogicalVolume* Xenon1tPMTsR8520::Construct()
{
  G4Material *Quartz = G4Material::GetMaterial("Quartz");
  G4Material *Vacuum = G4Material::GetMaterial("Vacuum");
  G4Material *PhotoCathodeAluminium = G4Material::GetMaterial("PhotoCathodeAluminium");
  G4Material *SS304LSteel = G4Material::GetMaterial("SS304LSteel");
  

  //==================================== pmts =====================================

  const G4double dVetoPmtHalfX = 0.5*dVetoPmtCasingWidth;
  const G4double dVetoPmtHalfZ = 0.5*(dVetoPmtWindowThickness+dVetoPmtCasingHeight);

  G4Box *pVetoPMTBox = new G4Box("VetoPMTBox",dVetoPmtHalfX,dVetoPmtHalfX,dVetoPmtHalfZ);
  m_pVetoPMTLogicalVolume = new G4LogicalVolume(pVetoPMTBox,Vacuum, "VetoPMTLogicalVolume", 0, 0, 0);
  
  
  //--------------------------------- pmt window ----------------------------------
  const G4double dPmtWindowHalfX = 0.5*dVetoPmtWindowWidth;
  const G4double dPmtWindowHalfZ = 0.5*dVetoPmtWindowThickness;
  const G4double dPmtWindowOffset = -dVetoPmtHalfZ+dPmtWindowHalfZ;
  G4Box *pPMTWindowBox = new G4Box("PMTWindowBox", dPmtWindowHalfX, dPmtWindowHalfX, dPmtWindowHalfZ);

  m_pVetoPMTWindowLogicalVolume = new G4LogicalVolume(pPMTWindowBox, Quartz, "VetoPMTWindowLogicalVolume", 0, 0, 0);
  m_pVetoPMTWindowPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., dPmtWindowOffset),						   m_pVetoPMTWindowLogicalVolume, "VetoPMTWindow", m_pVetoPMTLogicalVolume, false, 0);
  
  
  //--------------------------------- pmt casing ----------------------------------
  const G4double dPmtCasingHalfX = 0.5*dVetoPmtCasingWidth;
  const G4double dPmtCasingHalfZ = 0.5*dVetoPmtCasingHeight;
  const G4double dPmtCasingOffset = -dVetoPmtHalfZ+dVetoPmtWindowThickness+dPmtCasingHalfZ;
  
  G4Box *pPMTCasingBox = new G4Box("PMTCasingBox", dPmtCasingHalfX, dPmtCasingHalfX, dPmtCasingHalfZ);

  m_pVetoPMTCasingLogicalVolume = new G4LogicalVolume(pPMTCasingBox, SS304LSteel, "VetoPMTCasingLogicalVolume", 0, 0, 0);
  m_pVetoPMTCasingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., dPmtCasingOffset),						   m_pVetoPMTCasingLogicalVolume, "VetoPMTCasing", m_pVetoPMTLogicalVolume, false, 0);
  
 
  //-------------------------------- pmt interior ---------------------------------
  const G4double dPmtInteriorHalfX = dPmtCasingHalfX-dVetoPmtCasingThickness;
  const G4double dPmtInteriorHalfZ = dPmtCasingHalfZ-dVetoPmtCasingThickness;
  
  G4Box *pPMTInteriorBox = new G4Box("PMTInteriorBox", dPmtInteriorHalfX, dPmtInteriorHalfX, dPmtInteriorHalfZ);
  
  m_pVetoPMTInteriorLogicalVolume = new G4LogicalVolume(pPMTInteriorBox, Vacuum, "PMTInteriorLogicalVolume", 0, 0, 0);
  
  m_pVetoPMTInteriorPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
						       m_pVetoPMTInteriorLogicalVolume, "VetoPMTInterior", m_pVetoPMTCasingLogicalVolume, false, 0);
  
  
  //------------------------------ pmt photocathode -------------------------------
  const G4double dPmtPhotoCathodeHalfX = 0.5*dVetoPmtPhotoCathodeWidth;
  const G4double dPmtPhotoCathodeHalfZ = 0.5*dVetoPmtPhotoCathodeThickness;
  const G4double dPmtPhotoCathodeOffsetZ = dPmtCasingHalfZ-dPmtPhotoCathodeHalfZ;

  G4Box *pPMTPhotoCathodeBox = new G4Box("PMTPhotoCathodeBox", dPmtPhotoCathodeHalfX, dPmtPhotoCathodeHalfX, dPmtPhotoCathodeHalfZ);
  
  m_pVetoPMTPhotoCathodeLogicalVolume = new G4LogicalVolume(pPMTPhotoCathodeBox,PhotoCathodeAluminium , "PMTPhotoCathodeLogicalVolume", 0, 0, 0);

  m_pVetoPMTPhotoCathodePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., -dPmtPhotoCathodeOffsetZ),
						       m_pVetoPMTPhotoCathodeLogicalVolume, "VetoPMTPhotoCathode", m_pVetoPMTCasingLogicalVolume, false, 0);
  

  //------------------------------- PMT sensitivity -------------------------------
  G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
  Xenon1tPmtSensitiveDetector* pPmtSD;
 
  if(pSDManager->GetCollectionID("PmtHitsCollection")==-1)
    {
      // Add new sensitive det
      pPmtSD = new Xenon1tPmtSensitiveDetector("Xenon1t/PmtSD");
      pSDManager->AddNewDetector(pPmtSD);
       m_pVetoPMTPhotoCathodeLogicalVolume->SetSensitiveDetector(pPmtSD);
    }
  else 
    {
      // use old sensitive det
      G4VSensitiveDetector *pPmtSD = pSDManager->FindSensitiveDetector("Xenon1t/PmtSD", true);
       m_pVetoPMTPhotoCathodeLogicalVolume->SetSensitiveDetector(pPmtSD);
    }
  
  //---------------------------------- attributes ---------------------------------
  
  //   m_pPMTInnerVacuumLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  
  G4Colour hPMTWindowColor(1., 0.757, 0.024);
  G4VisAttributes *pPMTWindowVisAtt = new G4VisAttributes(hPMTWindowColor);
  pPMTWindowVisAtt->SetVisibility(true);
  m_pVetoPMTWindowLogicalVolume->SetVisAttributes(pPMTWindowVisAtt);

  G4Colour hPMTPhotocathodeColor(1., 0.082, 0.011);
  G4VisAttributes *pPMTPhotocathodeVisAtt = new G4VisAttributes(hPMTPhotocathodeColor);
  pPMTPhotocathodeVisAtt->SetVisibility(true);
  m_pVetoPMTPhotoCathodeLogicalVolume->SetVisAttributes(pPMTPhotocathodeVisAtt);

  G4Colour hPMTColor(1., 0.486, 0.027);
  G4VisAttributes *pPMTVisAtt = new G4VisAttributes(hPMTColor);
  pPMTVisAtt->SetVisibility(true);
  m_pVetoPMTLogicalVolume->SetVisAttributes(pPMTVisAtt);

  return m_pVetoPMTLogicalVolume;
}
