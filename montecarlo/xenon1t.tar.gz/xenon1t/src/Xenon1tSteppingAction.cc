#include "Xenon1tSteppingAction.hh"
#include "Xenon1tAnalysisManager.hh"

#include "G4SteppingManager.hh"

#include <string.h>
#include <cmath>

Xenon1tSteppingAction::Xenon1tSteppingAction(Xenon1tAnalysisManager *myAM):myAnalysisManager(myAM)
{
}

void Xenon1tSteppingAction::UserSteppingAction(const G4Step* aStep)
{
    G4int  trackID = aStep->GetTrack()->GetTrackID();
    particle = aStep->GetTrack()->GetDefinition()->GetParticleName();
    G4int particlePDGcode = aStep->GetTrack()->GetDefinition()->GetPDGEncoding();
    //G4float xP = aStep->GetPostStepPoint()->GetPosition().x();
    //G4float yP = aStep->GetPostStepPoint()->GetPosition().y();
    //G4float zP = aStep->GetPostStepPoint()->GetPosition().z();
    //G4float rP = sqrt(xP*xP+yP*yP+zP*zP);
    G4float eP = aStep->GetPostStepPoint()->GetKineticEnergy();
    G4float timeP = aStep->GetPostStepPoint()->GetGlobalTime();
    //G4float eDep = aStep->GetTotalEnergyDeposit();
    
    // Direction of the particle Pre
    //  G4ParticleMomentum *Momentum = aStep->GetPostStepPoint()->GetMomentum();
    G4float preMomModulo = sqrt( pow(aStep->GetPreStepPoint()->GetMomentum().x(),2) +
                                pow(aStep->GetPreStepPoint()->GetMomentum().y(),2) +
                                pow(aStep->GetPreStepPoint()->GetMomentum().z(),2) );
    G4ThreeVector preDirection( aStep->GetPreStepPoint()->GetMomentum().x()/preMomModulo , 
                               aStep->GetPreStepPoint()->GetMomentum().y()/preMomModulo , 
                               aStep->GetPreStepPoint()->GetMomentum().z()/preMomModulo );
    
    // Direction of the particle Post
    //  G4ParticleMomentum *Momentum = aStep->GetPostStepPoint()->GetMomentum();
    G4float MomModulo = sqrt( pow(aStep->GetPostStepPoint()->GetMomentum().x(),2) +
                             pow(aStep->GetPostStepPoint()->GetMomentum().y(),2) +
                             pow(aStep->GetPostStepPoint()->GetMomentum().z(),2) );
    G4ThreeVector direction( aStep->GetPostStepPoint()->GetMomentum().x()/MomModulo , 
                            aStep->GetPostStepPoint()->GetMomentum().y()/MomModulo , 
                            aStep->GetPostStepPoint()->GetMomentum().z()/MomModulo );
    
    
    Int_t SaveCryo = 0;
    
    if (SaveCryo){
        // MS Jun10 Get information when a particle cross the whole shield and hit the external part of the outer cryostat
        if(particle!="opticalphoton" &&
		   aStep->GetTrack()->GetVolume() &&
           aStep->GetTrack()->GetVolume()->GetName()=="Water" &&    // this is for the Water shield
           aStep->GetTrack()->GetNextVolume()->GetName()=="SS_OuterCryostat" 
           ){
            //G4cout << particle << " inside the shield at " << aStep->GetTrack()->GetNextVolume()->GetName() << " " << xP/cm << " " << yP/cm << " " << zP/cm << " with energy " << eP/MeV << " MeV" <<   G4endl;
            
            myAnalysisManager->FillParticleInSave(1, // 1==Particle inside the shield, hitting the outer cryo from outside
                                                  particlePDGcode,
                                                  aStep->GetPostStepPoint()->GetPosition(),
                                                  //					  aStep->GetPostStepPoint()->GetMomentum(),
                                                  direction,
                                                  eP,
                                                  timeP,
                                                  trackID);
            //aStep->GetTrack()->SetTrackStatus(fStopAndKill);  ///MSPORKED    
        }
    }
    
    
    
    Int_t SaveCapture = 1;
    if (SaveCapture){
        
        if(particle=="neutron" &&
		   aStep->GetTrack()->GetNextVolume() &&
           aStep->GetTrack()->GetNextVolume()->GetName()=="Water"){
            
            
            //MS 150612  neutron capture in water (or LS)
            G4String finProc = "nothing";
            if(aStep->GetPostStepPoint()->GetProcessDefinedStep())
            {finProc = aStep->GetPostStepPoint()->GetProcessDefinedStep()->GetProcessName();}
            
            // determine if it is a neutron inelastic interaction with Boron (G4 sees it as an inelastic)
            //G4SteppingManager* fpSteppingManager;    // IMPORTANT ... this is not a mistake, it must be commented, this object is defined elsewhere in G4
            G4int fNSecAtRestDoIt;
            G4int fNSecAlongStepDoIt;
            G4int fNSecPostStepDoIt;
            G4int totalSecThisStep;
            G4TrackVector*  vectorPartSec;
            G4String nameSec;
            G4float nrgSec;    
            
            fNSecAtRestDoIt = 0;
            fNSecAlongStepDoIt = 0;
            fNSecPostStepDoIt = 0;
            totalSecThisStep = 0;
            
            fNSecAtRestDoIt    = fpSteppingManager->GetfN2ndariesAtRestDoIt();
            fNSecAlongStepDoIt = fpSteppingManager->GetfN2ndariesAlongStepDoIt();
            fNSecPostStepDoIt  = fpSteppingManager->GetfN2ndariesPostStepDoIt();
            totalSecThisStep = fNSecAtRestDoIt + fNSecAlongStepDoIt + fNSecPostStepDoIt;    
            vectorPartSec = fpSteppingManager->GetfSecondary();
            G4int totalSec = vectorPartSec->size();
            
            //G4cout << "Nsec " << totalSec << " " << totalSecThisStep << G4endl ;
            
            G4int flagCaptureInBoron = 0;
            
            if(finProc == "NeutronInelastic"){    
                G4int flagAlpha = 0;
                G4int flagLitium = 0;
                for(int i=totalSec-totalSecThisStep; i<totalSec; i++)	{ // loop over secondary particles to look for alpha && Li7
                    nrgSec = (*vectorPartSec)[i]->GetKineticEnergy();                
                    nameSec = (*vectorPartSec)[i]->GetDefinition()->GetParticleName();
                    //G4cout << " Neutron Inelastic Interaction secondaries " << nameSec << " " << nrgSec << " " << nameSec.find("Li7") << G4endl;                
                    if(nameSec == "alpha") flagAlpha = 1;  
                    //&& fabs(nrgSec-1.47)<0.01
                    if (nameSec.find("Li7")==0)    flagLitium = 1;                
                }
                if(flagAlpha && flagLitium)  flagCaptureInBoron = 1;
            }
            
            
            if( finProc == "nCapture"  || flagCaptureInBoron )
            {
//                G4cout << particle << " capture in  " << aStep->GetTrack()->GetNextVolume()->GetName() << " " << xP/mm << " " << yP/mm << " " << zP/mm << " with energy " << eP/keV << " keV" <<   G4endl;
                
                myAnalysisManager->FillParticleInSave(9, // 9==neutron capture in water (or LS)
                                                      particlePDGcode,
                                                      aStep->GetPostStepPoint()->GetPosition(),
                                                      //					  aStep->GetPostStepPoint()->GetMomentum(),
                                                      direction,
                                                      eP,
                                                      timeP,
                                                      trackID);
            }
            
        }
        
    }
    


    // to follow opticalphotons
    G4String finProc = "nothing";
    if(aStep->GetPostStepPoint()->GetProcessDefinedStep())
      {finProc = aStep->GetPostStepPoint()->GetProcessDefinedStep()->GetProcessName();}

    if(particle=="opticalphoton" 
       //       aStep->GetTrack()->GetVolume() &&
       //       aStep->GetTrack()->GetVolume()->GetName()=="Water" &&    // this is for the Water shield
       //       aStep->GetTrack()->GetNextVolume()->GetName()=="SS_OuterCryostat" 
       //       finProc=="OpAbsorption"
       ){
      
      if(myAnalysisManager->PrintOpticalPhotonsStepsInfos())
	G4cout << " OPT-PHOT " << finProc << " " <<  aStep->GetPostStepPoint()->GetPhysicalVolume()->GetName() << G4endl;
      
      
    }
    
    
}



