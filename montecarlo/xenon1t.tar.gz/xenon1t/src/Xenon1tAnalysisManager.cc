#include <G4SDManager.hh>
#include <G4Run.hh>
#include <G4Event.hh>
#include <G4HCofThisEvent.hh>
#include <G4EmCalculator.hh>
#include <G4Material.hh>
#include <G4HadronicProcessStore.hh>
#include <G4ParticleTable.hh>
#include <G4NistManager.hh>
#include <G4ElementTable.hh>
#include <G4Version.hh>
//#include <G4Element.hh> 
#include <numeric>

#include <TROOT.h>
#include <TFile.h>
#include <TTree.h>
#include <TParameter.h>
#include <TDirectory.h>
#include <TH1.h>

#include "Xenon1tDetectorConstruction.hh"
#include "Xenon1tLXeHit.hh"
#include "Xenon1tPmtHit.hh"
#include "Xenon1tPrimaryGeneratorAction.hh"
#include "Xenon1tEventData.hh"

#include "Xenon1tAnalysisManager.hh"

#include "Xenon1tAnalysisMessenger.hh"

Xenon1tAnalysisManager::Xenon1tAnalysisManager(Xenon1tPrimaryGeneratorAction *pPrimaryGeneratorAction)
{
  runTime = new G4Timer();
  
  m_iLXeHitsCollectionID = -1;
  m_iPmtHitsCollectionID = -1;
  m_hDataFilename = "events.root";
  
  m_pPrimaryGeneratorAction = pPrimaryGeneratorAction;
  
  m_pEventData = new Xenon1tEventData();
  //plotPhysics      = kTRUE;
  writeEmptyEvents = kFALSE;

  m_pAnalysisMessenger = new Xenon1tAnalysisMessenger(this);

  m_pmtHitsDetails = kFALSE;
  m_optPhotStepsInfos = kFALSE;
}

Xenon1tAnalysisManager::~Xenon1tAnalysisManager()
{ 
  delete m_pAnalysisMessenger;

}

void
Xenon1tAnalysisManager::BeginOfRun(const G4Run *)
{

  // start a timer for this run....
  runTime->Start();
  // do we write empty events or not?
  writeEmptyEvents = m_pPrimaryGeneratorAction->GetWriteEmpty();
  
  m_pTreeFile = new TFile(m_hDataFilename.c_str(), "RECREATE");//, "File containing event data for Xenon1T");
  // make tree structure
  TNamed *G4version = new TNamed("G4VERSION_TAG",G4VERSION_TAG);
  G4version->Write();
    
  _events = m_pTreeFile->mkdir("events");
  _events->cd();

  G4cout <<"Xenon1tAnalysisManager:: Init data tree ..."<<G4endl;
  m_pTree = new TTree("events", "Tree containing event data for Xenon1T");

  gROOT->ProcessLine("#include <vector>");
  
  m_pTree->Branch("eventid", &m_pEventData->m_iEventId, "eventid/I");
  m_pTree->Branch("ntpmthits", &m_pEventData->m_iNbTopPmtHits, "ntpmthits/I");
  m_pTree->Branch("nbpmthits", &m_pEventData->m_iNbBottomPmtHits, "nbpmthits/I");
  m_pTree->Branch("nLSpmthits", &m_pEventData->m_iNbLSPmtHits, "nLSpmthits/I");
  m_pTree->Branch("nWaterpmthits", &m_pEventData->m_iNbWaterPmtHits, "nWaterpmthits/I");
  m_pTree->Branch("nlxevetobotpmthits", &m_pEventData->m_iNbLXeVetoBotPmtHits, "nlxevetobotpmthits/I");
  m_pTree->Branch("nlxevetotoppmthits", &m_pEventData->m_iNbLXeVetoTopPmtHits, "nlxevetotoppmthits/I");
  m_pTree->Branch("nlxevetobelowpmthits", &m_pEventData->m_iNbLXeVetoBelowPmtHits, "nlxevetobelowpmthits/I");
  m_pTree->Branch("nlxevetoabovepmthits", &m_pEventData->m_iNbLXeVetoAbovePmtHits, "nlxevetoabovepmthits/I");
  m_pTree->Branch("nlxevetocenterpmthits", &m_pEventData->m_iNbLXeVetoCenterPmtHits, "nlxevetocenterpmthits/I");
  m_pTree->Branch("pmthits", "vector<int>", &m_pEventData->m_pPmtHits);
  m_pTree->Branch("etot", &m_pEventData->m_fTotalEnergyDeposited, "etot/F");
  m_pTree->Branch("nsteps", &m_pEventData->m_iNbSteps, "nsteps/I");
  m_pTree->Branch("trackid", "vector<int>", &m_pEventData->m_pTrackId);
  m_pTree->Branch("type", "vector<string>", &m_pEventData->m_pParticleType);
  m_pTree->Branch("parentid", "vector<int>", &m_pEventData->m_pParentId);
  m_pTree->Branch("parenttype", "vector<string>", &m_pEventData->m_pParentType);
  m_pTree->Branch("creaproc", "vector<string>", &m_pEventData->m_pCreatorProcess);
  m_pTree->Branch("edproc", "vector<string>", &m_pEventData->m_pDepositingProcess);
  m_pTree->Branch("PreStepEnergy", "vector<float>", &m_pEventData->m_pPreStepEnergy);
  m_pTree->Branch("PostStepEnergy", "vector<float>", &m_pEventData->m_pPostStepEnergy);
  m_pTree->Branch("xp", "vector<float>", &m_pEventData->m_pX);
  m_pTree->Branch("yp", "vector<float>", &m_pEventData->m_pY);
  m_pTree->Branch("zp", "vector<float>", &m_pEventData->m_pZ);
  m_pTree->Branch("ed", "vector<float>", &m_pEventData->m_pEnergyDeposited);
  m_pTree->Branch("time", "vector<float>", &m_pEventData->m_pTime);

  m_pTree->Branch("type_pri", "vector<string>", &m_pEventData->m_pPrimaryParticleType);
  m_pTree->Branch("xp_pri", &m_pEventData->m_fPrimaryX, "xp_pri/F");
  m_pTree->Branch("yp_pri", &m_pEventData->m_fPrimaryY, "yp_pri/F");
  m_pTree->Branch("zp_pri", &m_pEventData->m_fPrimaryZ, "zp_pri/F");
  m_pTree->Branch("xp_fcd", &m_pEventData->m_fForcedPrimaryX, "xp_fcd/F");
  m_pTree->Branch("yp_fcd", &m_pEventData->m_fForcedPrimaryY, "yp_fcd/F");
  m_pTree->Branch("zp_fcd", &m_pEventData->m_fForcedPrimaryZ, "zp_fcd/F");
  m_pTree->Branch("e_pri",  &m_pEventData->m_fPrimaryE, "e_pri/F");
  m_pTree->Branch("w_pri",  &m_pEventData->m_fPrimaryW, "w_pri/F");

	m_pTree->Branch("NSave", &m_pEventData->m_iNSave, "NSave/I");
	m_pTree->Branch("Save_flag", "vector<int>", &m_pEventData->m_pSave_flag);
	m_pTree->Branch("Save_type", "vector<int>", &m_pEventData->m_pSave_type);
	m_pTree->Branch("Save_x", "vector<float>", &m_pEventData->m_pSave_x);
	m_pTree->Branch("Save_y", "vector<float>", &m_pEventData->m_pSave_y);
	m_pTree->Branch("Save_z", "vector<float>", &m_pEventData->m_pSave_z);
	m_pTree->Branch("Save_cx", "vector<float>", &m_pEventData->m_pSave_cx);
	m_pTree->Branch("Save_cy", "vector<float>", &m_pEventData->m_pSave_cy);
	m_pTree->Branch("Save_cz", "vector<float>", &m_pEventData->m_pSave_cz);
	m_pTree->Branch("Save_e", "vector<float>", &m_pEventData->m_pSave_e);
	m_pTree->Branch("Save_t", "vector<float>", &m_pEventData->m_pSave_t);
	m_pTree->Branch("Save_trkid", "vector<int>", &m_pEventData->m_pSave_trkid);
  
//  m_pTree->SetMaxTreeSize(G4int(10e9));
//  m_pTree->AutoSave();
  
  m_pNbEventsToSimulateParameter = new TParameter<int>("nbevents", m_iNbEventsToSimulate);
  m_pNbEventsToSimulateParameter->Write();

  m_pTreeFile->cd();

}

void
Xenon1tAnalysisManager::EndOfRun(const G4Run *)
{
  runTime->Stop();
  G4double dt = runTime->GetRealElapsed();
  // make tree structure
  TParameter<G4double> *dtPar = new TParameter<G4double>("G4RUNTIME",dt);
  dtPar->Write();

  m_pTreeFile->cd();

  m_pTreeFile->Write();
  m_pTreeFile->Close();
}

void
Xenon1tAnalysisManager::BeginOfEvent(const G4Event *)
{
  if(m_iLXeHitsCollectionID == -1)
    {
      G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
      m_iLXeHitsCollectionID = pSDManager->GetCollectionID("LXeHitsCollection");
    } 

  if(m_iPmtHitsCollectionID == -1)
    {
      G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
      m_iPmtHitsCollectionID = pSDManager->GetCollectionID("PmtHitsCollection");
    }
}

void
Xenon1tAnalysisManager::EndOfEvent(const G4Event *pEvent)
{
  _events->cd();

  G4HCofThisEvent* pHCofThisEvent = pEvent->GetHCofThisEvent();
  Xenon1tLXeHitsCollection* pLXeHitsCollection = 0;
  Xenon1tPmtHitsCollection* pPmtHitsCollection = 0;

  G4int iNbLXeHits = 0, iNbPmtHits = 0;
	
  if(pHCofThisEvent)
    {
      if(m_iLXeHitsCollectionID != -1)
	{
	  pLXeHitsCollection = (Xenon1tLXeHitsCollection *)(pHCofThisEvent->GetHC(m_iLXeHitsCollectionID));
	  iNbLXeHits = (pLXeHitsCollection)?(pLXeHitsCollection->entries()):(0);
	}

      if(m_iPmtHitsCollectionID != -1)
	{
	  pPmtHitsCollection = (Xenon1tPmtHitsCollection *)(pHCofThisEvent->GetHC(m_iPmtHitsCollectionID));
	  iNbPmtHits = (pPmtHitsCollection)?(pPmtHitsCollection->entries()):(0);
	}
    }

  // get the event ID and primary particle information
  m_pEventData->m_iEventId = pEvent->GetEventID();
  m_pEventData->m_pPrimaryParticleType->push_back(m_pPrimaryGeneratorAction->GetParticleTypeOfPrimary());
  
  m_pEventData->m_fPrimaryX = m_pPrimaryGeneratorAction->GetPositionOfPrimary().x();
  m_pEventData->m_fPrimaryY = m_pPrimaryGeneratorAction->GetPositionOfPrimary().y();
  m_pEventData->m_fPrimaryZ = m_pPrimaryGeneratorAction->GetPositionOfPrimary().z();

  m_pEventData->m_fForcedPrimaryX = m_pPrimaryGeneratorAction->GetForcedPositionOfPrimary().x();
  m_pEventData->m_fForcedPrimaryY = m_pPrimaryGeneratorAction->GetForcedPositionOfPrimary().y();
  m_pEventData->m_fForcedPrimaryZ = m_pPrimaryGeneratorAction->GetForcedPositionOfPrimary().z();

  m_pEventData->m_fPrimaryE = m_pPrimaryGeneratorAction->GetEnergyOfPrimary() / keV;
  m_pEventData->m_fPrimaryW = pEvent->GetPrimaryVertex()->GetWeight();
 
  
  G4int iNbSteps = 0;
  G4float fTotalEnergyDeposited = 0.;
  
  if(iNbLXeHits || iNbPmtHits)
    {
      // LXe hits
      for(G4int i=0; i<iNbLXeHits; i++)
	{
	  Xenon1tLXeHit *pHit = (*pLXeHitsCollection)[i];

	  if(pHit->GetParticleType() != "opticalphoton")
	  //	  if( 1 == 1 )
	    {
	      m_pEventData->m_pTrackId->push_back(pHit->GetTrackId());
	      m_pEventData->m_pParentId->push_back(pHit->GetParentId());

	      m_pEventData->m_pParticleType->push_back(pHit->GetParticleType());
	      m_pEventData->m_pParentType->push_back(pHit->GetParentType());
	      m_pEventData->m_pCreatorProcess->push_back(pHit->GetCreatorProcess());
	      m_pEventData->m_pDepositingProcess->push_back(pHit->GetDepositingProcess());

	      m_pEventData->m_pX->push_back(pHit->GetPosition().x()/mm);
	      m_pEventData->m_pY->push_back(pHit->GetPosition().y()/mm);
	      m_pEventData->m_pZ->push_back(pHit->GetPosition().z()/mm);

	      fTotalEnergyDeposited += pHit->GetEnergyDeposited()/keV;
	      m_pEventData->m_pEnergyDeposited->push_back(pHit->GetEnergyDeposited()/keV);
	      m_pEventData->m_pKineticEnergy->push_back(pHit->GetKineticEnergy()/keV);
		  m_pEventData->m_pPreStepEnergy->push_back(pHit->GetPreStepEnergy()/keV);
 		  m_pEventData->m_pPostStepEnergy->push_back(pHit->GetPostStepEnergy()/keV);
	      m_pEventData->m_pTime->push_back(pHit->GetTime()/second);

	      iNbSteps++;
	    }
	}


      //G4int iNbTopPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbTopPMTs");
      //G4int iNbBottomPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbBottomPMTs");
      G4int iNbTopPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbOfTopPMTs");
      G4int iNbBottomPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbOfBottomPMTs");
      G4int iNbLSPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbLSPMTs");
      G4int iNbWaterPmts = (G4int) Xenon1tDetectorConstruction::GetGeometryParameter("NbWaterPMTs");
 
      G4int iNbOfLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbLXeVetoPMTs");
      G4int iNbOfBottomLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbBottomLXeVetoPMTs");   
      G4int iNbOfTopLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbTopLXeVetoPMTs");
      G4int iNbOfBelowLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbBelowLXeVetoPMTs");
      G4int iNbOfAboveLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbAboveLXeVetoPMTs");  
      G4int iNbOfCenterLXeVetoPMTs = (G4int)Xenon1tDetectorConstruction::GetGeometryParameter("NbCenterLXeVetoPMTs");  

      m_pEventData->m_pPmtHits->resize(iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfLXeVetoPMTs, 0);

      // Pmt hits
      for(G4int i=0; i<iNbPmtHits; i++){
	(*(m_pEventData->m_pPmtHits))[(*pPmtHitsCollection)[i]->GetPmtNb()-1]++;
	if(m_pmtHitsDetails){
	  m_pEventData->m_pTime->push_back((*pPmtHitsCollection)[i]->GetTime()/second);
	  m_pEventData->m_pX->push_back((*pPmtHitsCollection)[i]->GetPosition().x()/mm);
	  m_pEventData->m_pY->push_back((*pPmtHitsCollection)[i]->GetPosition().y()/mm);
	  m_pEventData->m_pZ->push_back((*pPmtHitsCollection)[i]->GetPosition().z()/mm);
	  iNbSteps++;  
	}
      }


      m_pEventData->m_iNbTopPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin(), m_pEventData->m_pPmtHits->begin()+iNbTopPmts, 0);
      m_pEventData->m_iNbBottomPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts, m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts, 0);
      m_pEventData->m_iNbLSPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts, m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts, 0);

      // Cyril, 2013/10/16: commented this line to include LXe veto PMTs
      //m_pEventData->m_iNbWaterPmtHits =
      //accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts, m_pEventData->m_pPmtHits->end(), 0);

      m_pEventData->m_iNbWaterPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts,m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts , 0);
      m_pEventData->m_iNbLXeVetoBotPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts,m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs, 0);
      m_pEventData->m_iNbLXeVetoTopPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs,m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs , 0);
      m_pEventData->m_iNbLXeVetoBelowPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs,m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs+iNbOfBelowLXeVetoPMTs , 0);
      m_pEventData->m_iNbLXeVetoAbovePmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs+iNbOfBelowLXeVetoPMTs,m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs+iNbOfBelowLXeVetoPMTs+iNbOfAboveLXeVetoPMTs , 0);
     m_pEventData->m_iNbLXeVetoCenterPmtHits =
	accumulate(m_pEventData->m_pPmtHits->begin()+iNbTopPmts+iNbBottomPmts+iNbLSPmts+iNbWaterPmts+iNbOfBottomLXeVetoPMTs+iNbOfTopLXeVetoPMTs+iNbOfBelowLXeVetoPMTs+iNbOfAboveLXeVetoPMTs, m_pEventData->m_pPmtHits->end(), 0);
     


      //        if((fTotalEnergyDeposited > 0. || iNbPmtHits > 0) && !FilterEvent(m_pEventData))
      //APC		if(fTotalEnergyDeposited > 0. || iNbPmtHits > 0)
      //APC			m_pTree->Fill();

      //APC		m_pEventData->Clear();
    }
  
  // also write the header information + primary vertex of the empty events....
  m_pEventData->m_iNbSteps = iNbSteps;
  m_pEventData->m_fTotalEnergyDeposited = fTotalEnergyDeposited;
  
  // save only energy depositing events
  if(writeEmptyEvents) {
    m_pTree->Fill(); // write all events to the tree
  } else {
    if(fTotalEnergyDeposited > 0. || iNbPmtHits > 0) m_pTree->Fill(); // only events with some activity are written to the tree
  }
  
  m_pEventData->Clear(); 
  m_pTreeFile->cd();
}

void
Xenon1tAnalysisManager::Step(const G4Step *)
{

}

/*
  G4bool
  Xenon1tAnalysisManager::FilterEvent(Xenon1tEventData *pEventData)
  {
  G4double dEnergyDepositedSensitiveRegion = 0.;

  vector<float> *pX = pEventData->m_pX;
  vector<float> *pY = pEventData->m_pY;
  vector<float> *pZ = pEventData->m_pZ;
  vector<float> *pEnergyDeposited = pEventData->m_pEnergyDeposited;

  const G4double dDriftLength = Xenon1tDetectorConstruction::GetGeometryParameter("DriftLength");
  const G4double dRadius = Xenon1tDetectorConstruction::GetGeometryParameter("TeflonCylinderInnerRadius");

  for(G4int i=0; i<pEnergyDeposited->size(); i++)
  {
  if((*pZ)[i] < 0. && (*pZ)[i] > -dDriftLength && std::sqrt((*pX)[i]*(*pX)[i] + (*pY)[i]*(*pY)[i]) < dRadius)
  dEnergyDepositedSensitiveRegion += (*pEnergyDeposited)[i];
  }

  //    if(dEnergyDepositedSensitiveRegion > 0. && dEnergyDepositedSensitiveRegion < 100.)
  if(dEnergyDepositedSensitiveRegion > 0.)
  return false;
  else
  return true;
  }
*/


void
Xenon1tAnalysisManager::FillParticleInSave(G4int flag, G4int partPDGcode, G4ThreeVector pos, G4ThreeVector dir,  G4float nrg, G4float time, G4int trackID){

  m_pEventData->m_pSave_flag->push_back(flag);
  m_pEventData->m_pSave_type->push_back(partPDGcode);
  m_pEventData->m_pSave_x->push_back(pos.x()/mm);
  m_pEventData->m_pSave_y->push_back(pos.y()/mm);
  m_pEventData->m_pSave_z->push_back(pos.z()/mm);
  m_pEventData->m_pSave_cx->push_back(dir.x());
  m_pEventData->m_pSave_cy->push_back(dir.y());
  m_pEventData->m_pSave_cz->push_back(dir.z());
  m_pEventData->m_pSave_e->push_back(nrg/keV);
  m_pEventData->m_pSave_t->push_back(time/ns);
  m_pEventData->m_pSave_trkid->push_back(trackID);
  m_pEventData->m_iNSave++;

  //  G4cout <<    m_pEventData->m_iNSave << " " << partPDGcode << " " << pos << " " << nrg << G4endl;
}
