#include <G4ThreeVector.hh>
#include <G4RotationMatrix.hh>
#include <G4ParticleTable.hh>
#include <G4UIdirectory.hh>
#include <G4UIcmdWithoutParameter.hh>
#include <G4UIcmdWithAString.hh>
#include <G4UIcmdWithADoubleAndUnit.hh>
#include <G4UIcmdWith3Vector.hh>
#include <G4UIcmdWith3VectorAndUnit.hh>
#include <G4UIcmdWithAnInteger.hh>
#include <G4UIcmdWithADouble.hh>
#include <G4UIcmdWithABool.hh>
#include <G4Tokenizer.hh>
#include <G4ios.hh>
#include <fstream>
#include <iomanip>

#include "Xenon1tDetectorMessenger.hh"

#include "Xenon1tDetectorConstruction.hh"

Xenon1tDetectorMessenger::Xenon1tDetectorMessenger(Xenon1tDetectorConstruction *pXeDetector)
:m_pXeDetector(pXeDetector)
{ 
	m_pDetectorDir = new G4UIdirectory("/Xe/detector/");
	m_pDetectorDir->SetGuidance("detector control.");

	m_pTeflonReflectivityCmd = new G4UIcmdWithADouble("/Xe/detector/setTeflonReflectivity", this);
	m_pTeflonReflectivityCmd->SetGuidance("Define teflon reflectivity.");
	m_pTeflonReflectivityCmd->SetParameterName("R", false);
	m_pTeflonReflectivityCmd->SetRange("R >= 0. && R <= 1.");
  m_pTeflonReflectivityCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pLXeScintillationCmd = new G4UIcmdWithABool("/Xe/detector/setLXeScintillation", this);
	m_pLXeScintillationCmd->SetGuidance("Switch on/off LXe scintillation in the sensitive volume.");
	m_pLXeScintillationCmd->SetParameterName("LXeScint", false); 
	m_pLXeScintillationCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pLXeAbsorbtionLengthCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setLXeAbsorbtionLength", this);
	m_pLXeAbsorbtionLengthCmd->SetGuidance("Define LXe absorbtion length.");
	m_pLXeAbsorbtionLengthCmd->SetParameterName("AbsL", false);
	m_pLXeAbsorbtionLengthCmd->SetRange("AbsL >= 0.");
	m_pLXeAbsorbtionLengthCmd->SetUnitCategory("Length");
	m_pLXeAbsorbtionLengthCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pLXeRayScatterLengthCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setLXeRayScatterLength", this);
	m_pLXeRayScatterLengthCmd->SetGuidance("Define LXe Rayleigh Scattering length.");
	m_pLXeRayScatterLengthCmd->SetParameterName("ScatL", false);
	m_pLXeRayScatterLengthCmd->SetRange("ScatL >= 0.");
	m_pLXeRayScatterLengthCmd->SetUnitCategory("Length");
	m_pLXeRayScatterLengthCmd->AvailableForStates(G4State_PreInit, G4State_Idle);
	
	// Cyril, December 2013
	m_pGridMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setGridMeshTransparency", this);
	m_pGridMeshTransparencyCmd->SetGuidance("Define mesh transparency.");
	m_pGridMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pGridMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pGridMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);
	
	// Cyril, June 2014: differenciate all meshes
	m_pTopScreeningMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setTopScreeningMeshTransparency", this);
	m_pTopScreeningMeshTransparencyCmd->SetGuidance("Define top screening mesh transparency.");
	m_pTopScreeningMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pTopScreeningMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pTopScreeningMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pBottomScreeningMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setBottomScreeningMeshTransparency", this);
	m_pBottomScreeningMeshTransparencyCmd->SetGuidance("Define bottom screening mesh transparency.");
	m_pBottomScreeningMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pBottomScreeningMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pBottomScreeningMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pAnodeMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setAnodeMeshTransparency", this);
	m_pAnodeMeshTransparencyCmd->SetGuidance("Define anode mesh transparency.");
	m_pAnodeMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pAnodeMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pAnodeMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pCathodeMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setCathodeMeshTransparency", this);
	m_pCathodeMeshTransparencyCmd->SetGuidance("Define cathode mesh transparency.");
	m_pCathodeMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pCathodeMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pCathodeMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);

	m_pGateMeshTransparencyCmd = new G4UIcmdWithADouble("/Xe/detector/setGateMeshTransparency", this);
	m_pGateMeshTransparencyCmd->SetGuidance("Define gate mesh transparency.");
	m_pGateMeshTransparencyCmd->SetParameterName("Transpa", false);
	m_pGateMeshTransparencyCmd->SetRange("Transpa >= 0. && Transpa <= 1.");
	m_pGateMeshTransparencyCmd->AvailableForStates(G4State_PreInit, G4State_Idle);







	// SERENA: you need  all commands below
	//
	// Selection for the cryostat design type.
	// For now there are two types: 
	//      1. standard = what was in the Xenon1t simulations already at 25-07-2011
	//      2. Nikhef   = following the Nikhef design
	//
	// A.P.Colijn 25-07-2011
	m_pCryostatTypeCmd = new G4UIcmdWithAString("/Xe/detector/setCryostatType", this);
  m_pCryostatTypeCmd->SetGuidance("Choice of cryostat geometry");
	m_pCryostatTypeCmd->SetParameterName("cryoType", false);
	m_pCryostatTypeCmd->AvailableForStates(G4State_PreInit);
	m_pCryostatTypeCmd->SetDefaultValue("Columbia");

	
	// cryostat material selector....
	m_pCryostatMaterialCmd = new G4UIcmdWithAString("/Xe/detector/setCryostatMaterial", this);
  m_pCryostatMaterialCmd->SetGuidance("Choice of cryostat geometry");
	m_pCryostatMaterialCmd->SetParameterName("cryoMaterial", false);
  m_pCryostatMaterialCmd->AvailableForStates(G4State_PreInit);
    
    // neutron source selector Andrew Brown 22/08/10
    m_pNeutronSourceSurroundingsCmd = new G4UIcmdWithAString("/Xe/detector/setNeutronSourceSurroundings", this);
     m_pNeutronSourceSurroundingsCmd->SetGuidance("Choice of neutron source surroungings: (1) LeadBrick (2) NeutronGenerator (3) None [default]");
    m_pNeutronSourceSurroundingsCmd->SetParameterName("neutSurr", false);
    m_pNeutronSourceSurroundingsCmd->SetDefaultValue("None");
    m_pNeutronSourceSurroundingsCmd->AvailableForStates(G4State_PreInit);
    		
	// cryostat outer vessel wall thickness 
  // APC put this back, because we want to play with the cryostat diameter+thickness
	G4double dOuterDefault = 0; //  mm
	m_pCryostatOuterWallCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setCryostatOuterWallThickness", this);
  m_pCryostatOuterWallCmd->SetGuidance("Wall thickness of outer cryostat vessel");
	m_pCryostatOuterWallCmd->SetParameterName("cryoOuterWallThickness", false);
  m_pCryostatOuterWallCmd->SetDefaultValue(dOuterDefault);
	m_pCryostatOuterWallCmd->SetUnitCategory("Length");
	m_pCryostatOuterWallCmd->SetDefaultUnit("mm");
	m_pCryostatOuterWallCmd->AvailableForStates(G4State_PreInit);
	
	// cryostat inner vessel wall thickness
	G4double dInnerDefault = 0; // mm
	m_pCryostatInnerWallCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setCryostatInnerWallThickness", this);
  m_pCryostatInnerWallCmd->SetGuidance("Wall thickness of inner cryostat vessel");
	m_pCryostatInnerWallCmd->SetParameterName("cryoInnerWallThickness", false);
	m_pCryostatInnerWallCmd->SetDefaultValue(dInnerDefault);
	m_pCryostatInnerWallCmd->SetUnitCategory("Length");
	m_pCryostatInnerWallCmd->SetDefaultUnit("mm");
	m_pCryostatInnerWallCmd->AvailableForStates(G4State_PreInit);

  // outer vessel wall thickness only with ColumbiaXL cryostat
  G4double dOuterODDefault = 0; //  mm
	m_pCryostatOuterODCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setCryostatOuterOD", this);
  m_pCryostatOuterODCmd->SetGuidance("OD of outer cryostat vessel");
	m_pCryostatOuterODCmd->SetParameterName("cryoOuterOD", false);
  m_pCryostatOuterODCmd->SetDefaultValue(dOuterODDefault);
	m_pCryostatOuterODCmd->SetUnitCategory("Length");
	m_pCryostatOuterODCmd->SetDefaultUnit("mm");
	m_pCryostatOuterODCmd->AvailableForStates(G4State_PreInit);
  // inner vessel wall thickness only with ColumbiaXL cryostat
  G4double dInnerODDefault = 0; //  mm
	m_pCryostatInnerODCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setCryostatInnerOD", this);
  m_pCryostatInnerODCmd->SetGuidance("OD of inner cryostat vessel");
	m_pCryostatInnerODCmd->SetParameterName("cryoInnerrOD", false);
  m_pCryostatInnerODCmd->SetDefaultValue(dInnerODDefault);
	m_pCryostatInnerODCmd->SetUnitCategory("Length");
	m_pCryostatInnerODCmd->SetDefaultUnit("mm");
	m_pCryostatInnerODCmd->AvailableForStates(G4State_PreInit);

  // check for overlapping objetcs
  m_pCheckOverlapCmd = new G4UIcmdWithABool("/Xe/detector/setCheckOverlap", this);
  m_pCheckOverlapCmd->SetGuidance("Check for overlapping objects in the geometry.");
  m_pCheckOverlapCmd->SetParameterName("CheckOverlap", false); 
  m_pCheckOverlapCmd->AvailableForStates(G4State_PreInit);
 
  // run the simulation with / without TPC
  m_pSetTPCCmd = new G4UIcmdWithABool("/Xe/detector/setTPC", this);
  m_pSetTPCCmd->SetGuidance("Run the simulation with / without the TPC.");
  m_pSetTPCCmd->SetParameterName("TPC", true); 
  m_pSetTPCCmd->AvailableForStates(G4State_PreInit);
 
// cryostat inner vessel wall thickness
//	m_pXeDetector->SetCryostatType("standard");
	// if cryostat made following Nikhef design then material selection is relevant..... 
	// (could be extended to standard cryostat of course)
//	m_pXeDetector->SetCryostatMaterial("TiGrade1");
//	m_pXeDetector->SetInnerWallThickness(dInnerDefault);
//	m_pXeDetector->SetOuterWallThickness(dOuterDefault);
  m_pXeDetector->SetCheckOverlap(false);
  m_pXeDetector->SetTPC(true);

    // muon veto material selector....
	m_pMuonVetoMaterialCmd = new G4UIcmdWithAString("/Xe/detector/setMuonVetoMaterial", this);
    m_pMuonVetoMaterialCmd->SetGuidance("Choice of MuonVeto material: Water, LScint, Gd_LScint, B_LScint");
	m_pMuonVetoMaterialCmd->SetParameterName("muonvetoMaterial", false);
    m_pMuonVetoMaterialCmd->SetDefaultValue("Water");
    m_pMuonVetoMaterialCmd->AvailableForStates(G4State_PreInit);
    
    // fill the buffer between TPC and Cryostat with Poly ? (or leave it with LXe)
    m_pSetFillBufferCmd = new G4UIcmdWithABool("/Xe/detector/setFillBuffer", this);
    m_pSetFillBufferCmd->SetGuidance("If TRUE fill the LXe buffer (between TPC and Cryo) with Poly");
	m_pSetFillBufferCmd->SetParameterName("fillBuffer", false);
    m_pSetFillBufferCmd->SetDefaultValue(false);
    m_pSetFillBufferCmd->AvailableForStates(G4State_PreInit);

    // set the thickness of the upper and lower buffer (default 5 cm) ... the remaining part will be filled with GXe (top) and copper (bottom)
    G4double dBufferThicknessDefault = 50 * mm; //mm
    m_pSetBufferThicknessCmd = new G4UIcmdWithADoubleAndUnit("/Xe/detector/setBufferThickness", this);
    m_pSetBufferThicknessCmd->SetGuidance("set the thickness of the upper and lower buffer (between TPC and Cryo)");
	m_pSetBufferThicknessCmd->SetParameterName("bufferThickness", false);
    m_pSetBufferThicknessCmd->SetDefaultValue(dBufferThicknessDefault);
    m_pSetBufferThicknessCmd->SetUnitCategory("Length");
    m_pSetBufferThicknessCmd->SetDefaultUnit("mm");
    m_pSetBufferThicknessCmd->AvailableForStates(G4State_PreInit);
    
    // select the Tpc option : WITH (default) or WITHOUT the Bell (and LXe on top of it)
    m_pSetTpcWithBellCmd = new G4UIcmdWithABool("/Xe/detector/setTpcWithBell", this);
    m_pSetTpcWithBellCmd->SetGuidance("If TRUE (default) build the Bell and LXe on top of it");
	m_pSetTpcWithBellCmd->SetParameterName("TpcWithBell", false);
    m_pSetTpcWithBellCmd->SetDefaultValue(false);
    m_pSetTpcWithBellCmd->AvailableForStates(G4State_PreInit);

    // select the LXe Veto option: WITH (default) or WITHOUT a veto
    m_pSetLXeVetoCmd = new G4UIcmdWithABool("/Xe/detector/setLXeVeto", this);
    m_pSetLXeVetoCmd->SetGuidance("If TRUE (default) build the Bell and LXe on top of it");
    m_pSetLXeVetoCmd->SetParameterName("LXeVeto", true);
    m_pSetLXeVetoCmd->SetDefaultValue(true);
    m_pSetLXeVetoCmd->AvailableForStates(G4State_PreInit);
   

}

Xenon1tDetectorMessenger::~Xenon1tDetectorMessenger()
{
  delete m_pTeflonReflectivityCmd;
  delete m_pLXeScintillationCmd;
  delete m_pLXeAbsorbtionLengthCmd;
  delete m_pLXeRayScatterLengthCmd;
  delete m_pGridMeshTransparencyCmd;
  delete m_pTopScreeningMeshTransparencyCmd;
  delete m_pBottomScreeningMeshTransparencyCmd;
  delete m_pAnodeMeshTransparencyCmd;
  delete m_pCathodeMeshTransparencyCmd;
  delete m_pGateMeshTransparencyCmd;

  delete m_pCryostatTypeCmd;
  delete m_pCryostatMaterialCmd;
  delete m_pNeutronSourceSurroundingsCmd;
  //delete m_pCryostatOuterWallCmd;
  //delete m_pCryostatInnerWallCmd;
  delete m_pCheckOverlapCmd;
  delete m_pSetTPCCmd;
	
  delete m_pDetectorDir;
  delete m_pMuonVetoMaterialCmd;
  delete m_pSetFillBufferCmd;
  delete m_pSetBufferThicknessCmd;
  delete m_pSetTpcWithBellCmd;
  delete m_pSetLXeVetoCmd;

}

void Xenon1tDetectorMessenger::SetNewValue(G4UIcommand *pUIcommand, G4String hNewValue)
{

	if(pUIcommand == m_pLXeScintillationCmd)
		m_pXeDetector->SetLXeScintillation(m_pLXeScintillationCmd->GetNewBoolValue(hNewValue));

	if(pUIcommand == m_pTeflonReflectivityCmd)
		m_pXeDetector->SetTeflonReflectivity(m_pTeflonReflectivityCmd->GetNewDoubleValue(hNewValue));		
		
	if(pUIcommand == m_pLXeAbsorbtionLengthCmd)
		m_pXeDetector->SetLXeAbsorbtionLength(m_pLXeAbsorbtionLengthCmd->GetNewDoubleValue(hNewValue));

	if(pUIcommand == m_pLXeRayScatterLengthCmd)
		m_pXeDetector->SetLXeRayScatterLength(m_pLXeRayScatterLengthCmd->GetNewDoubleValue(hNewValue));

	// Cyril 04/12/2013
	if(pUIcommand == m_pGridMeshTransparencyCmd)
	  m_pXeDetector->SetGridMeshTransparency(m_pGridMeshTransparencyCmd->GetNewDoubleValue(hNewValue));
	
	// Cyril, June 2014
	if(pUIcommand == m_pTopScreeningMeshTransparencyCmd)
	  m_pXeDetector->SetTopScreeningMeshTransparency(m_pTopScreeningMeshTransparencyCmd->GetNewDoubleValue(hNewValue));
	
	if(pUIcommand == m_pBottomScreeningMeshTransparencyCmd)
	  m_pXeDetector->SetBottomScreeningMeshTransparency(m_pBottomScreeningMeshTransparencyCmd->GetNewDoubleValue(hNewValue));

	if(pUIcommand == m_pAnodeMeshTransparencyCmd)
	  m_pXeDetector->SetAnodeMeshTransparency(m_pAnodeMeshTransparencyCmd->GetNewDoubleValue(hNewValue));

	if(pUIcommand == m_pCathodeMeshTransparencyCmd)
	  m_pXeDetector->SetCathodeMeshTransparency(m_pCathodeMeshTransparencyCmd->GetNewDoubleValue(hNewValue));

	if(pUIcommand == m_pGateMeshTransparencyCmd)
	  m_pXeDetector->SetGateMeshTransparency(m_pGateMeshTransparencyCmd->GetNewDoubleValue(hNewValue));
	

	//Andrew 22/08/10
	if(pUIcommand == m_pNeutronSourceSurroundingsCmd)
	  m_pXeDetector->SetNeutronSourceSurroundings(hNewValue);
	
	//SERENA
	// cryostat type
	if(pUIcommand == m_pCryostatTypeCmd)
		m_pXeDetector->SetCryostatType(hNewValue);
    
	// cryostat material
	if(pUIcommand == m_pCryostatMaterialCmd)
		m_pXeDetector->SetCryostatMaterial(hNewValue);
	
	//cryostat outer wall
	if(pUIcommand == m_pCryostatOuterWallCmd)
    m_pXeDetector->SetOuterWallThickness(m_pCryostatOuterWallCmd->GetNewDoubleValue(hNewValue));
    
	// cryostat inner wall
	if (pUIcommand == m_pCryostatInnerWallCmd)
    m_pXeDetector->SetInnerWallThickness(m_pCryostatInnerWallCmd->GetNewDoubleValue(hNewValue));
    
  // OD inner vessel
  if (pUIcommand == m_pCryostatInnerODCmd)
    m_pXeDetector->SetInnerOD(m_pCryostatInnerODCmd->GetNewDoubleValue(hNewValue));
    
  // OD inner vessel
  if (pUIcommand == m_pCryostatOuterODCmd)
    m_pXeDetector->SetOuterOD(m_pCryostatOuterODCmd->GetNewDoubleValue(hNewValue));
    
  if(pUIcommand == m_pCheckOverlapCmd)
		m_pXeDetector->SetCheckOverlap(m_pCheckOverlapCmd->GetNewBoolValue(hNewValue));
    
  if(pUIcommand == m_pSetTPCCmd)
		m_pXeDetector->SetTPC(m_pSetTPCCmd->GetNewBoolValue(hNewValue));
    
  if(pUIcommand == m_pMuonVetoMaterialCmd)  
      m_pXeDetector->SetMuonVetoMaterial(hNewValue);
    
    if(pUIcommand == m_pSetFillBufferCmd)
        m_pXeDetector->SetFillBuffer(m_pSetFillBufferCmd->GetNewBoolValue(hNewValue));
    
    if(pUIcommand == m_pSetBufferThicknessCmd)  
        m_pXeDetector->SetBufferThickness(m_pSetBufferThicknessCmd->GetNewDoubleValue(hNewValue));   
    
    if(pUIcommand == m_pSetTpcWithBellCmd)
        m_pXeDetector->SetTpcWithBell(m_pSetTpcWithBellCmd->GetNewBoolValue(hNewValue));

    if(pUIcommand == m_pSetLXeVetoCmd)
      m_pXeDetector->SetLXeVeto(m_pSetLXeVetoCmd->GetNewBoolValue(hNewValue));
    
}

//G4String Xenon1tDetectorMessenger::GetCurrentValue(G4UIcommand *pUIcommand)
//{
//  G4String cv;
//
//	return cv;
//}
		
