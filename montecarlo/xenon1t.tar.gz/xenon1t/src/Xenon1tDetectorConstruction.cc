#include <G4Material.hh>
#include <G4NistManager.hh>
#include <G4Box.hh>
#include <G4Tubs.hh>
#include <G4Cons.hh>
#include <G4EllipticalCone.hh>
#include <G4Trd.hh>
#include <G4Sphere.hh>
#include <G4Torus.hh>
#include <G4Polyhedra.hh>
#include <G4Polycone.hh>
#include <G4Ellipsoid.hh>
#include <G4ExtrudedSolid.hh>  // SERENA
#include <G4UnionSolid.hh>
#include <G4GenericTrap.hh>
#include <G4SubtractionSolid.hh>
#include <G4IntersectionSolid.hh>
#include <G4LogicalVolume.hh>
#include <G4PVPlacement.hh>
#include <G4PVParameterised.hh>
#include <G4OpBoundaryProcess.hh>
#include <G4SDManager.hh>
#include <G4ThreeVector.hh>
#include <G4RotationMatrix.hh>
#include <G4VisAttributes.hh>
#include <G4Colour.hh>
#include <globals.hh>
#include <vector>
#include <numeric>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cassert>

using std::vector;
using std::stringstream;
using std::max;

#include "Xenon1tDetectorMessenger.hh"

#include "Xenon1tLXeSensitiveDetector.hh"
#include "Xenon1tDetectorConstruction.hh"
#include "Xenon1tPMTsR11410.hh"
#include "Xenon1tPMTsR8520.hh"

#include "G4PhysicalVolumeStore.hh"

#include "TFile.h"
#include "TParameter.h"

map<G4String, G4double> Xenon1tDetectorConstruction::m_hGeometryParameters;

Xenon1tDetectorConstruction::Xenon1tDetectorConstruction(G4String fName)
{
  pCryostatType     = "Columbia";
  pCryostatMaterial = "SS316Ti";//"TiGrade1";
  m_pDetectorMessenger = new Xenon1tDetectorMessenger(this);
  detRootFile = fName;
  pMuonVetoMaterial = "Water";
  pFillBuffer = false;
  pBufferThickness = 50.*mm;
  pTpcWithBell = false;
  pLXeVeto = false;//true;
  pFlagHVFT = false;
}

Xenon1tDetectorConstruction::~Xenon1tDetectorConstruction()
{
  delete m_pDetectorMessenger;
}

G4VPhysicalVolume*
Xenon1tDetectorConstruction::Construct()
{
  DefineMaterials();
  
  DefineGeometryParameters();
  
  ConstructLaboratory();
  
  G4cout << "Xenon1tDetectorConstruction::Construct() MuonVeto material    = "<<pMuonVetoMaterial <<G4endl;
  ConstructVeto(); // water buffer
	
  if(pNeutronSourceSurroundings!="None") {
    if(pNeutronSourceSurroundings=="NeutronGenerator")
      ConstructNeutronGenerator();
    else if(pNeutronSourceSurroundings=="LeadBrick")
      ConstructLeadBrick();
    else
      G4cout << "Invalid Neutron Source Surroundings choice, "
	     << "defaulting to None!" << G4endl;
  }
	
  ConstructNewSupportStructure();
  
  ConstructPipe();
	
  //// ConstructCablesPipe();
  
  G4cout << "COLUMBIA CRYOSTAT CONSTRUCTION" << G4endl;
  G4cout << "Xenon1tDetectorConstruction::Construct() Cryostat material    = "<<pCryostatMaterial<<G4endl;
  ConstructColumbiaCryostat();
  
  ConstructXenon();
	
  if(pFlagHVFT)
    ConstructHVFT();
	
  Xenon1tPMTsR11410 *pPMTR11410 = new Xenon1tPMTsR11410(this);
  m_pPmtR11410LogicalVolume = pPMTR11410->Construct();
 
  Xenon1tPMTsR8520 *pPMTR8520 = new Xenon1tPMTsR8520(this);
  m_pPmtR8520LogicalVolume = pPMTR8520->Construct();
		
  ConstructTopTPC();
	
  // // PMT sensitivity
  // /*	G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
  //   pPmtSD = new Xenon1tPmtSensitiveDetector("Xenon1t/PmtSD");
  //   pSDManager->AddNewDetector(pPmtSD);
  //   // Comment by Paolo
  //   // */

    if (pTPC) {
      G4cout << "Xenon1tDetectorConstruction::Construct() TPC "<<G4endl;
      ConstructTPC();
      ConstructGrids();
    } else {
      G4cout << "Xenon1tDetectorConstruction::Construct() WARNING:: no TPC in simulation "<<G4endl;
    }
	
    
    if(pLXeVeto)
      ConstructLXeVetoPMTArrays();
    
    ConstructVetoPMTArrays();
    ////CheckOverlapping();
  
    if(pCheckOverlap)
       SecondOverlapCheck();
  
    PrintGeometryInformation();
  
    MakeDetectorPlots();
  
    return m_pLabPhysicalVolume;
}

void
Xenon1tDetectorConstruction::DefineMaterials()
{
  G4NistManager* pNistManager = G4NistManager::Instance();
  
  //================================== elements ===================================
  pNistManager->FindOrBuildElement("U");
  G4Element *Xe = new G4Element("Xenon",     "Xe", 54., 131.293*g/mole);
  G4Element *H  = new G4Element("Hydrogen",  "H",  1.,  1.0079*g/mole);
  G4Element *C  = new G4Element("Carbon",    "C",  6.,  12.011*g/mole);
  G4Element *N  = new G4Element("Nitrogen",  "N",  7.,  14.007*g/mole);
  G4Element *O  = new G4Element("Oxygen",    "O",  8.,  15.999*g/mole);
  G4Element *F  = new G4Element("Fluorine",  "F",  9.,  18.998*g/mole);
  G4Element *Al = new G4Element("Aluminium", "Al", 13., 26.982*g/mole);
  G4Element *Si = new G4Element("Silicon",   "Si", 14., 28.086*g/mole);
  G4Element *Cr = new G4Element("Chromium",  "Cr", 24., 51.996*g/mole);
  G4Element *Mn = new G4Element("Manganese", "Mn", 25., 54.938*g/mole);
  G4Element *Fe = new G4Element("Iron",      "Fe", 26., 55.85*g/mole);
  G4Element *Ni = new G4Element("Nickel",    "Ni", 28., 58.693*g/mole);
  G4Element *Cu = new G4Element("Copper",    "Cu", 29., 63.546*g/mole);
  //G4Element *Pb = new G4Element("Lead",      "Pb", 82., 207.2*g/mole);
  G4Element *B  = pNistManager->FindOrBuildElement("B");
  G4Element *Gd = pNistManager->FindOrBuildElement("Gd");
  
  G4Element *Co = pNistManager->FindOrBuildElement("Co");
  G4Element *Ti = pNistManager->FindOrBuildElement("Ti");
  G4Element *Mo = pNistManager->FindOrBuildElement("Mo");
  //G4Element *Pb = pNistManager->FindOrBuildElement("Pb");
  
	
  //================================== materials ================================== 
  
  //------------------------------------- air -------------------------------------
  pNistManager->FindOrBuildMaterial("G4_AIR");
  G4Material *Air = G4Material::GetMaterial("G4_AIR"); // moved here by Serena
  
  
  //----------------------------------- vacuum ------------------------------------
  G4Material *Vacuum = new G4Material("Vacuum", 1.e-20*g/cm3, 2, kStateGas);
  Vacuum->AddElement(N, 0.755);
  Vacuum->AddElement(O, 0.245);
  
  //------------------------------------ water ------------------------
  G4Material *Water = new G4Material("Water", 1.*g/cm3, 2, kStateLiquid);
  Water->AddElement(H, 2);
  Water->AddElement(O, 1);
    
  //------------------------------------- lead -------------------------------------
  pNistManager->FindOrBuildMaterial("G4_Pb");
    
  //------------------------------------- steel -------------------------------------
    
  G4String name;
  G4int ncomponents;
  G4double density;
  G4Material *Steel =
    new G4Material(name = "Steel", density = 7.7 *g/cm3, ncomponents = 3);
  Steel->AddElement(C,  0.04);
  Steel->AddElement(Fe, 0.88);
  Steel->AddElement(Co, 0.08);
    

  
  //------------------------------------ liquid scintillator (Borexino)------------------------
  G4Material* PC = new G4Material("PC", 0.882*g/cm3, 2, kStateLiquid);
  PC->AddElement(C, 9);
  PC->AddElement(H, 12);
  
  G4Material* PPO = new G4Material("PPO", 0.882*g/cm3, 4, kStateSolid);
  PPO->AddElement(C, 15);
  PPO->AddElement(H, 11);
  PPO->AddElement(N, 1);
  PPO->AddElement(O, 1);
  
  G4Material* LScint = new G4Material("LScint", 0.882*g/cm3, 2, kStateLiquid);
  LScint->AddMaterial(PC, 0.9983);
  LScint->AddMaterial(PPO, 0.0017);
  
  G4Material *Gd_LScint = new G4Material("Gd_LScint", 0.882*g/cm3, 2, kStateLiquid);// Gd-doped
  Gd_LScint->AddMaterial(LScint, 0.999);
  Gd_LScint->AddElement(Gd, 0.001);
  
  G4Material *B_LScint = new G4Material("B_LScint", 0.882*g/cm3, 2, kStateLiquid);// B-doped
  B_LScint->AddMaterial(LScint, 0.999);
  B_LScint->AddElement(B, 0.001);
  
  /// implement scintillation properties
  
    //-------------------------------- liquid xenon ---------------------------------
    //	G4Material *LXe = new G4Material("LXe", 2.9172*g/cm3, 1, kStateLiquid, 168.15*kelvin, 1.5*atmosphere);
    G4Material *LXe = new G4Material("LXe", 2.85*g/cm3, 1, kStateLiquid, 168.15*kelvin, 1.5*atmosphere);
    LXe->AddElement(Xe, 1);
  
    const G4int iNbEntries = 3;
  
    G4double pdLXePhotonMomentum[iNbEntries]   = {6.91*eV, 6.98*eV, 7.05*eV};
    G4double pdLXeScintillation[iNbEntries]    = {0.1,     1.0,     0.1};
    G4double pdLXeRefractiveIndex[iNbEntries]  = {1.63,    1.61,    1.58};
    //G4double pdLXeRefractiveIndex[iNbEntries]  = {1.56,    1.56,    1.56};
    //G4double pdLXeRefractiveIndex[iNbEntries]  = {1.69,    1.69,    1.69};
    G4double pdLXeAbsorbtionLength[iNbEntries] = {100.*cm, 100.*cm, 100.*cm};
    G4double pdLXeScatteringLength[iNbEntries] = {30.*cm,  30.*cm,  30.*cm};
  
    G4MaterialPropertiesTable *pLXePropertiesTable = new G4MaterialPropertiesTable();
	
    pLXePropertiesTable->AddProperty("FASTCOMPONENT", pdLXePhotonMomentum, pdLXeScintillation, iNbEntries);
    pLXePropertiesTable->AddProperty("SLOWCOMPONENT", pdLXePhotonMomentum, pdLXeScintillation, iNbEntries);
    pLXePropertiesTable->AddProperty("RINDEX", pdLXePhotonMomentum, pdLXeRefractiveIndex, iNbEntries);
    pLXePropertiesTable->AddProperty("ABSLENGTH", pdLXePhotonMomentum, pdLXeAbsorbtionLength, iNbEntries);
    pLXePropertiesTable->AddProperty("RAYLEIGH", pdLXePhotonMomentum, pdLXeScatteringLength, iNbEntries);
	
    pLXePropertiesTable->AddConstProperty("SCINTILLATIONYIELD", 0./keV);
    pLXePropertiesTable->AddConstProperty("RESOLUTIONSCALE", 0);
    pLXePropertiesTable->AddConstProperty("FASTTIMECONSTANT", 3.*ns);
    pLXePropertiesTable->AddConstProperty("SLOWTIMECONSTANT", 27.*ns);
    pLXePropertiesTable->AddConstProperty("YIELDRATIO", 1.0);
	

    pLXePropertiesTable->AddConstProperty("TOTALNUM_INT_SITES", -1);//// initialize the number of interaction sites

    //______________________________________________________________________________//
	
    LXe->SetMaterialPropertiesTable(pLXePropertiesTable);
  
    //-------------------------------- gaseous xenon --------------------------------
    G4Material *GXe = new G4Material("GXe", 0.005887*g/cm3, 1, kStateGas, 173.15*kelvin, 1.5*atmosphere);
    GXe->AddElement(Xe, 1);
  
    G4double pdGXePhotonMomentum[iNbEntries]   = {6.91*eV, 6.98*eV, 7.05*eV};
    G4double pdGXeScintillation[iNbEntries]    = {0.1,     1.0,     0.1};
    G4double pdGXeRefractiveIndex[iNbEntries]  = {1.00,    1.00,    1.00};
    G4double pdGXeAbsorbtionLength[iNbEntries] = {100*m,   100*m,   100*m};
    G4double pdGXeScatteringLength[iNbEntries] = {100*m,   100*m,   100*m};
  
    G4MaterialPropertiesTable *pGXePropertiesTable = new G4MaterialPropertiesTable();
  
    pGXePropertiesTable->AddProperty("FASTCOMPONENT", pdGXePhotonMomentum, pdGXeScintillation, iNbEntries);
    pGXePropertiesTable->AddProperty("SLOWCOMPONENT", pdGXePhotonMomentum, pdGXeScintillation, iNbEntries);
    pGXePropertiesTable->AddProperty("RINDEX", pdGXePhotonMomentum, pdGXeRefractiveIndex, iNbEntries);
    pGXePropertiesTable->AddProperty("ABSLENGTH", pdGXePhotonMomentum, pdGXeAbsorbtionLength, iNbEntries);
    pGXePropertiesTable->AddProperty("RAYLEIGH", pdGXePhotonMomentum, pdGXeScatteringLength, iNbEntries);
  
    pGXePropertiesTable->AddConstProperty("SCINTILLATIONYIELD", 0./(keV));
    pGXePropertiesTable->AddConstProperty("RESOLUTIONSCALE", 0);
    pGXePropertiesTable->AddConstProperty("FASTTIMECONSTANT", 3.*ns);
    pGXePropertiesTable->AddConstProperty("SLOWTIMECONSTANT", 27.*ns);
    pGXePropertiesTable->AddConstProperty("YIELDRATIO", 1.0);
	
	
    GXe->SetMaterialPropertiesTable(pGXePropertiesTable);	
  
    //----------------------------------- quartz ------------------------------------
    // ref: http://www.sciner.com/Opticsland/FS.htm
    G4Material *Quartz = new G4Material("Quartz", 2.201*g/cm3, 2, kStateSolid, 168.15*kelvin, 1.5*atmosphere);
    Quartz->AddElement(Si, 1);
    Quartz->AddElement(O, 2);
  
    const 	G4int iNbEntriesMatch = 5;
    //	G4double pdQuartzPhotonMomentum[iNbEntriesMatch]   = {2.*eV, 6.9*eV, 6.91*eV, 6.98*eV, 7.05*eV}; // Serena's comment!!!
    G4double pdQuartzPhotonMomentum[iNbEntriesMatch]   = {1.*eV, 6.9*eV, 6.91*eV, 6.98*eV, 7.05*eV};  // SERENA: changed  2.*eV to 1.*eV otherwise it gets stuck "Out of Range - Attempt to retrieve information below range!"
    G4double pdQuartzRefractiveIndex[iNbEntriesMatch]  = { 1.50,   1.50,    1.50,    1.56,    1.60};
    //G4double pdQuartzRefractiveIndex[iNbEntriesMatch]  = { 1.59,   1.59,    1.59,    1.59,    1.59};
    G4double pdQuartzAbsorbtionLength[iNbEntriesMatch] = {30*m,    30*m,    30*m,    30*m,    30*m};
  
    G4MaterialPropertiesTable *pQuartzPropertiesTable = new G4MaterialPropertiesTable();
  
    pQuartzPropertiesTable->AddProperty("RINDEX", pdQuartzPhotonMomentum, pdQuartzRefractiveIndex, iNbEntriesMatch);
    pQuartzPropertiesTable->AddProperty("ABSLENGTH", pdQuartzPhotonMomentum, pdQuartzAbsorbtionLength, iNbEntriesMatch);
  
    Quartz->SetMaterialPropertiesTable(pQuartzPropertiesTable);
  
  
    //------------------------------------ Kovar -----------------------------------  ( added by RINO  6 June 2012)
    G4Material *Kovar = new G4Material("Kovar", 8.33*g/cm3, 6, kStateSolid);
    Kovar->AddElement(Fe,0.5358);
    Kovar->AddElement(Ni,0.29);
    Kovar->AddElement(Co,0.17);
    Kovar->AddElement(C,0.0002);
    Kovar->AddElement(Si,0.001);
    Kovar->AddElement(Mn,0.003);
  
    //   G4MaterialPropertiesTable *pKovarPropertiesTable = new G4MaterialPropertiesTable();
  
    //   G4double pdKovarPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
    //   G4double pdKovarReflectivity[iNbEntries]   = {0.15,    0.2,     0.15};/// check
  
    //   pKovarPropertiesTable->AddProperty("REFLECTIVITY", pdKovarPhotonMomentum, pdKovarReflectivity, iNbEntries);
  
    //   Kovar->SetMaterialPropertiesTable(pKovarPropertiesTable);
  
  
    //------------------------- cirlex ------------------------   ( added by RINO  6 June 2012)
    // imported from Xe100 code
  
    G4Material *Cirlex = new G4Material("Cirlex", 1.43*g/cm3, 4, kStateSolid);
    Cirlex->AddElement(C, 22);
    Cirlex->AddElement(H, 10);
    Cirlex->AddElement(N, 2);
    Cirlex->AddElement(O, 5);
  
    //   G4double pdCirlexPhotonMomentum[]  = {6.91*eV, 6.98*eV, 7.05*eV};
    //   G4double pdCirlexReflectivity[]   = {0.5,    0.5,     0.5};
  
    //   G4MaterialPropertiesTable *pCirlexPropertiesTable = new G4MaterialPropertiesTable();
  
    //   pCirlexPropertiesTable->AddProperty("REFLECTIVITY", pdCirlexPhotonMomentum, pdCirlexReflectivity, iNbEntries);
    //   Cirlex->SetMaterialPropertiesTable(pCirlexPropertiesTable);
  
    //------------------------------- stainless steel -------------------------------
    G4Material *SS304LSteel = new G4Material("SS304LSteel", 8.00*g/cm3, 5, kStateSolid);
    SS304LSteel->AddElement(Fe, 0.65);
    SS304LSteel->AddElement(Cr, 0.20);
    SS304LSteel->AddElement(Ni, 0.12);
    SS304LSteel->AddElement(Mn, 0.02);
    SS304LSteel->AddElement(Si, 0.01);
    /*
      G4double pdSteelPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdSteelReflectivity[]   = {0.15,    0.2,     0.15};
      G4MaterialPropertiesTable *pSteelPropertiesTable = new G4MaterialPropertiesTable();
   
      pSteelPropertiesTable->AddProperty("REFLECTIVITY", pdSteelPhotonMomentum, pdSteelReflectivity, iNbEntries);
      SS304LSteel->SetMaterialPropertiesTable(pSteelPropertiesTable);
    */
  
  
  
  
    // ****** BY AUKE-PC ****** --------------------------------------------------------
  
    //
    // AISI 316Ti steel / UNS S 31635
    //
    // 1. Take the maximum specified fraction of each component.
    //    See http://www.atimetals.com/ludlum/Documents/316ti.pdf
    // 2. Leave out tracer elements <0.05% of Phosphor and Sulphur (justifiable?)
    //
    // A.P. Colijn 26-07-2011
    //
    G4double fractionmass;
    G4int    ncomponent;
    G4Material *SS316Ti = new G4Material("SS316Ti", 8.00*g/cm3, ncomponent=8, kStateSolid);
    SS316Ti->AddElement(Cr, fractionmass=18.00*perCent);
    SS316Ti->AddElement(Ni, fractionmass=14.00*perCent);
    SS316Ti->AddElement(Mo, fractionmass= 3.00*perCent);  
    SS316Ti->AddElement(Mn, fractionmass= 2.00*perCent);
    SS316Ti->AddElement(C , fractionmass= 0.80*perCent);
    SS316Ti->AddElement(Si, fractionmass= 0.75*perCent);
    SS316Ti->AddElement(Ti, fractionmass= 0.70*perCent);
    SS316Ti->AddElement(Fe, fractionmass=60.75*perCent);
  
    //------------------------------- titanium alloys -------------------------------
  
    // 1. Titanium grade1: UNS R50250; ASTM Grade 1
    //    See http://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MTU010
    // 2. Maximum specified fraction for each component
    // 
    // A.P. Colijn 26-07-2011
    //
    G4Material *TiGrade1 = new G4Material("TiGrade1", 4.51*g/cm3, ncomponent=6, kStateSolid);
    TiGrade1->AddElement(C , fractionmass= 0.10*perCent);
    TiGrade1->AddElement(Fe, fractionmass= 0.20*perCent);
    TiGrade1->AddElement(H , fractionmass= 0.015*perCent);
    TiGrade1->AddElement(N , fractionmass= 0.03*perCent);
    TiGrade1->AddElement(O , fractionmass= 0.18*perCent);
    TiGrade1->AddElement(Ti, fractionmass= 99.475*perCent);
  
    // As far as Geant4 is concerned grade1 and grade2 identical I would think.....
  
    // 1. Titanium grade2: UNS R50400; ASTM Grade 2
    //    See http://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MTU020
    // 2. Maximum specified fraction for each component
    // 
    // A.P. Colijn 26-07-2011
    //
    G4Material *TiGrade2 = new G4Material("TiGrade2", 4.51*g/cm3, ncomponent=6, kStateSolid);
    TiGrade2->AddElement(C , fractionmass= 0.10*perCent);
    TiGrade2->AddElement(Fe, fractionmass= 0.30*perCent); 
    TiGrade2->AddElement(H , fractionmass= 0.015*perCent);
    TiGrade2->AddElement(N , fractionmass= 0.03*perCent);
    TiGrade2->AddElement(O , fractionmass= 0.25*perCent);
    TiGrade2->AddElement(Ti, fractionmass= 99.305*perCent);
  
    // ****** END AUKE-PC PIECE ****** --------------------------------------------------------
  
  //------------------------------------ Torlon -----------------------------------
    
    G4Material *Torlon = new G4Material("Torlon", 1.41*g/cm3, 4, kStateSolid);
    Torlon->AddElement(N, 0.07862);
    Torlon->AddElement(C, 0.70784);
    Torlon->AddElement(O, 0.17960);
    Torlon->AddElement(H, 0.03394);

  
    //---------------------------- photocathode aluminium ---------------------------
    G4Material *PhotoCathodeAluminium = new G4Material("PhotoCathodeAluminium", 8.00*g/cm3, 1, kStateSolid);
    PhotoCathodeAluminium->AddElement(Al, 1);
  
    //G4double pdPhotoCathodePhotonMomentum[]   = {2.*eV, 6.9*eV, 6.91*eV, 6.98*eV, 7.05*eV};	// Serena's comment!!!
    G4double pdPhotoCathodePhotonMomentum[]   = {1.*eV, 6.9*eV, 6.91*eV, 6.98*eV, 7.05*eV};	// SERENA: changed  2.*eV to 1.*eV otherwise it gets stuck "Out of Range - Attempt to retrieve information below range!"
    G4double pdPhotoCathodeRefractiveIndex[]  = {1.50,  1.50,   1.50,    1.56,    1.60};
    G4double pdPhotoCathodeAbsorbtionLength[] = {1.*nm, 1*nm,   1.*nm,   1.*nm,   1.*nm};
    G4MaterialPropertiesTable *pPhotoCathodePropertiesTable = new G4MaterialPropertiesTable();
  
    pPhotoCathodePropertiesTable->AddProperty("RINDEX", pdPhotoCathodePhotonMomentum, pdPhotoCathodeRefractiveIndex, iNbEntriesMatch);
    pPhotoCathodePropertiesTable->AddProperty("ABSLENGTH", pdPhotoCathodePhotonMomentum, pdPhotoCathodeAbsorbtionLength, iNbEntriesMatch);
  
    PhotoCathodeAluminium->SetMaterialPropertiesTable(pPhotoCathodePropertiesTable);
  
    //---------------------------- QUPID aluminium coating---------------------------
    G4Material *CoatingAluminium = new G4Material("CoatingAluminium", 2.7*g/cm3, 1, kStateSolid);
    CoatingAluminium->AddElement(Al, 1);
  
    G4double pdCoatingAluminiumPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
    G4double pdCoatingAluminiumReflectivity[iNbEntries]   = {0.15,    0.2,     0.15};/// check
      G4MaterialPropertiesTable *pCoatingAluminiumPropertiesTable = new G4MaterialPropertiesTable();
  
      pCoatingAluminiumPropertiesTable->AddProperty("REFLECTIVITY", pdCoatingAluminiumPhotonMomentum, pdCoatingAluminiumReflectivity, iNbEntries);
      CoatingAluminium->SetMaterialPropertiesTable(pCoatingAluminiumPropertiesTable);
  
      //----------------------------- grid mesh aluminium------------------------------
      G4Material *GridMeshAluminium = new G4Material("GridMeshAluminium", 0.174*g/cm3, 1, kStateSolid);
      GridMeshAluminium->AddElement(Al, 1);
	
      G4double pdGridMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdGridMeshRefractiveIndex = pdLXeRefractiveIndex;
      //G4double dAbsortionLength = 2.10*mm; // exp(-GridMeshThickness/2.10) = 0.94 : works with thickness 0f 0.13 mm
      G4double dAbsortionLength = 3.2323021424*mm; // exp(-GridMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      //G4double dAbsortionLength = 6.5661590*mm; // exp(-GridMeshThickness/dAbsortionLength) = 0.97, with thickness of 0.2mm
      G4double pdGridMeshAbsortionLength[] = {dAbsortionLength, dAbsortionLength, dAbsortionLength};
	
      G4MaterialPropertiesTable *pGridMeshPropertiesTable = new G4MaterialPropertiesTable();
  
      pGridMeshPropertiesTable->AddProperty("RINDEX", pdGridMeshPhotonMomentum, pdGridMeshRefractiveIndex, iNbEntries);
      pGridMeshPropertiesTable->AddProperty("ABSLENGTH", pdGridMeshPhotonMomentum, pdGridMeshAbsortionLength, iNbEntries);
      GridMeshAluminium->SetMaterialPropertiesTable(pGridMeshPropertiesTable);

      
      //
      // Treating every grid with different transparency. Cyril, June 2014
      //

      //----------------------------- top screening mesh ------------------------------
      G4Material *TopScreeningMesh = new G4Material("TopScreeningMesh", 0.48*g/cm3, 1, kStateSolid);
      TopScreeningMesh->AddMaterial(SS316Ti,1); // density is (100.-94.)/100. * 8.g/cm3
      G4double pdTopScreeningMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdTopScreeningMeshRefractiveIndex = pdLXeRefractiveIndex;     
      G4double dTopScreeningMeshAbsortionLength = 3.2323021424*mm; // exp(-TopScreeningMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      G4double pdTopScreeningMeshAbsortionLength[] = {dTopScreeningMeshAbsortionLength, dTopScreeningMeshAbsortionLength, dTopScreeningMeshAbsortionLength};
      G4MaterialPropertiesTable *pTopScreeningMeshPropertiesTable = new G4MaterialPropertiesTable();
      pTopScreeningMeshPropertiesTable->AddProperty("RINDEX", pdTopScreeningMeshPhotonMomentum, pdTopScreeningMeshRefractiveIndex, iNbEntries);
      pTopScreeningMeshPropertiesTable->AddProperty("ABSLENGTH", pdTopScreeningMeshPhotonMomentum, pdTopScreeningMeshAbsortionLength, iNbEntries);
      TopScreeningMesh->SetMaterialPropertiesTable(pTopScreeningMeshPropertiesTable);
  
      //----------------------------- bottom screening mesh ------------------------------
      G4Material *BottomScreeningMesh = new G4Material("BottomScreeningMesh", 0.48*g/cm3, 1, kStateSolid);
      BottomScreeningMesh->AddMaterial(SS316Ti,1);
      G4double pdBottomScreeningMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdBottomScreeningMeshRefractiveIndex = pdLXeRefractiveIndex;
      G4double dBottomScreeningMeshAbsortionLength = 3.2323021424*mm; // exp(-BottomScreeningMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      G4double pdBottomScreeningMeshAbsortionLength[] = {dBottomScreeningMeshAbsortionLength, dBottomScreeningMeshAbsortionLength, dBottomScreeningMeshAbsortionLength};
      G4MaterialPropertiesTable *pBottomScreeningMeshPropertiesTable = new G4MaterialPropertiesTable();
      pBottomScreeningMeshPropertiesTable->AddProperty("RINDEX", pdBottomScreeningMeshPhotonMomentum, pdBottomScreeningMeshRefractiveIndex, iNbEntries);
      pBottomScreeningMeshPropertiesTable->AddProperty("ABSLENGTH", pdBottomScreeningMeshPhotonMomentum, pdBottomScreeningMeshAbsortionLength, iNbEntries);
      BottomScreeningMesh->SetMaterialPropertiesTable(pBottomScreeningMeshPropertiesTable);
  
      //----------------------------- cathode mesh ------------------------------
      G4Material *CathodeMesh = new G4Material("CathodeMesh", 0.48*g/cm3, 1, kStateSolid);
      CathodeMesh->AddMaterial(SS316Ti,1);
      G4double pdCathodeMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdCathodeMeshRefractiveIndex = pdLXeRefractiveIndex;
      G4double dCathodeMeshAbsortionLength = 3.2323021424*mm; // exp(-CathodeMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      G4double pdCathodeMeshAbsortionLength[] = {dCathodeMeshAbsortionLength, dCathodeMeshAbsortionLength, dCathodeMeshAbsortionLength};
      G4MaterialPropertiesTable *pCathodeMeshPropertiesTable = new G4MaterialPropertiesTable();
      pCathodeMeshPropertiesTable->AddProperty("RINDEX", pdCathodeMeshPhotonMomentum, pdCathodeMeshRefractiveIndex, iNbEntries);
      pCathodeMeshPropertiesTable->AddProperty("ABSLENGTH", pdCathodeMeshPhotonMomentum, pdCathodeMeshAbsortionLength, iNbEntries);
      CathodeMesh->SetMaterialPropertiesTable(pCathodeMeshPropertiesTable);
      
      //----------------------------- anode mesh ------------------------------
      G4Material *AnodeMesh = new G4Material("AnodeMesh", 0.48*g/cm3, 1, kStateSolid);
      AnodeMesh->AddMaterial(SS316Ti,1);	
      G4double pdAnodeMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdAnodeMeshRefractiveIndex = pdLXeRefractiveIndex;
      G4double dAnodeMeshAbsortionLength = 3.2323021424*mm; // exp(-AnodeMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      G4double pdAnodeMeshAbsortionLength[] = {dAnodeMeshAbsortionLength, dAnodeMeshAbsortionLength, dAnodeMeshAbsortionLength};
      G4MaterialPropertiesTable *pAnodeMeshPropertiesTable = new G4MaterialPropertiesTable();
      pAnodeMeshPropertiesTable->AddProperty("RINDEX", pdAnodeMeshPhotonMomentum, pdAnodeMeshRefractiveIndex, iNbEntries);
      pAnodeMeshPropertiesTable->AddProperty("ABSLENGTH", pdAnodeMeshPhotonMomentum, pdAnodeMeshAbsortionLength, iNbEntries);
      AnodeMesh->SetMaterialPropertiesTable(pAnodeMeshPropertiesTable);
  
      //----------------------------- gate mesh ------------------------------
      G4Material *GateMesh = new G4Material("GateMesh", 0.48*g/cm3, 1, kStateSolid);
      GateMesh->AddMaterial(SS316Ti,1);	
      G4double pdGateMeshPhotonMomentum[] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double *pdGateMeshRefractiveIndex = pdLXeRefractiveIndex;
      G4double dGateMeshAbsortionLength = 3.2323021424*mm; // exp(-GateMeshThickness/dAbsortionLength) = 0.94, with thickness of 0.2mm
      G4double pdGateMeshAbsortionLength[] = {dGateMeshAbsortionLength, dGateMeshAbsortionLength, dGateMeshAbsortionLength};
      G4MaterialPropertiesTable *pGateMeshPropertiesTable = new G4MaterialPropertiesTable();
      pGateMeshPropertiesTable->AddProperty("RINDEX", pdGateMeshPhotonMomentum, pdGateMeshRefractiveIndex, iNbEntries);
      pGateMeshPropertiesTable->AddProperty("ABSLENGTH", pdGateMeshPhotonMomentum, pdGateMeshAbsortionLength, iNbEntries);
      GateMesh->SetMaterialPropertiesTable(pGateMeshPropertiesTable);
  


      //------------------------------------ teflon -----------------------------------
      G4Material* Teflon = new G4Material("Teflon", 2.2*g/cm3, 2, kStateSolid);
      Teflon->AddElement(C, 0.240183);
      Teflon->AddElement(F, 0.759817);
  
      G4double pdTeflonPhotonMomentum[iNbEntries]  = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdTeflonRefractiveIndex[iNbEntries] = {1.63,    1.61,    1.58};
      G4double pdTeflonReflectivity[iNbEntries]    = {0.95,    0.95,    0.95};
      G4double pdTeflonSpecularLobe[iNbEntries]    = {0.01,    0.01,    0.01};
      G4double pdTeflonSpecularSpike[iNbEntries]   = {0.01,    0.01,    0.01};
      G4double pdTeflonBackscatter[iNbEntries]     = {0.01,    0.01,    0.01};
      G4double pdTeflonEfficiency[iNbEntries]      = {1.0,     1.0,     1.0};
      
       G4MaterialPropertiesTable *pTeflonPropertiesTable = new G4MaterialPropertiesTable();
  
      pTeflonPropertiesTable->AddProperty("RINDEX", pdTeflonPhotonMomentum, pdTeflonRefractiveIndex, iNbEntries);
      pTeflonPropertiesTable->AddProperty("REFLECTIVITY", pdTeflonPhotonMomentum, pdTeflonReflectivity, iNbEntries);
      pTeflonPropertiesTable->AddProperty("SPECULARLOBECONSTANT", pdTeflonPhotonMomentum, pdTeflonSpecularLobe, iNbEntries);
      pTeflonPropertiesTable->AddProperty("SPECULARSPIKECONSTANT", pdTeflonPhotonMomentum, pdTeflonSpecularSpike, iNbEntries);
      pTeflonPropertiesTable->AddProperty("BACKSCATTERCONSTANT", pdTeflonPhotonMomentum, pdTeflonBackscatter, iNbEntries);
      pTeflonPropertiesTable->AddProperty("EFFICIENCY", pdTeflonPhotonMomentum, pdTeflonEfficiency, iNbEntries);
      Teflon->SetMaterialPropertiesTable(pTeflonPropertiesTable);
  
      //------------------------------------ copper -----------------------------------
      G4Material *Copper = new G4Material("Copper", 8.92*g/cm3, 1);
      Copper->AddElement(Cu, 1); 
  
      G4double pdCopperPhotonMomentum[iNbEntries] = {1.91*eV, 6.98*eV, 7.05*eV};//{6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdCopperReflectivity[iNbEntries]   = {0.15,    0.2,     0.15};
      G4MaterialPropertiesTable *pCopperPropertiesTable = new G4MaterialPropertiesTable();
  
      pCopperPropertiesTable->AddProperty("REFLECTIVITY", pdCopperPhotonMomentum, pdCopperReflectivity, iNbEntries);
      Copper->SetMaterialPropertiesTable(pCopperPropertiesTable);

      //------------------------------------ PMT ceramic -----------------------------------
      G4Material *Ceramic = new G4Material("Ceramic", 4.*g/cm3, 2, kStateSolid, 168.15*kelvin, 1.5*atmosphere);
      Ceramic->AddElement(Al, 2); 
      Ceramic->AddElement(O,  3); 
  
      //---------------------------------- titanium ----------------------------------
      //  G4Material *Titanium = pNistManager->FindOrBuildMaterial("G4_Ti");
      G4Material *Titanium = new G4Material("Titanium", 4.506*g/cm3, 1, kStateSolid);
      Titanium->AddElement(Ti, 1);
  
      //------------------------------------ acrylic -----------------------------------
      G4Material *Acrylic = new G4Material("Acrylic", 1.18*g/cm3, 3, kStateSolid, 168.15*kelvin, 1.5*atmosphere);
      Acrylic->AddElement(C,5);
      Acrylic->AddElement(H,8);
      Acrylic->AddElement(O,2);
  
  
  
      //------------------------------------ polyethilene -----------------------------------
      G4Material *  poly = new G4Material("poly", 0.95*g/cm3, 2);
      poly->AddElement(C, 1);
      poly->AddElement(H, 2);  

      G4Material * B_poly = new G4Material("B_poly", 0.93*g/cm3, 4, kStateSolid);// B-doped, from http://lss.fnal.gov/archive/2000/fn/FN-697.pdf
      B_poly->AddElement(H, fractionmass=0.116);
      B_poly->AddElement(C, fractionmass=0.612);
      B_poly->AddElement(B, fractionmass=0.05);
      B_poly->AddElement(O, fractionmass=0.222);
      G4cout << "B_poly " << B_poly << G4endl;

  
      // ----------- optical properties of water --------------------
      const G4int nEntries = 32;
  
      G4double PhotonEnergy[nEntries] =
	{ 2.034*eV, 2.068*eV, 2.103*eV, 2.139*eV,
	  2.177*eV, 2.216*eV, 2.256*eV, 2.298*eV,
	  2.341*eV, 2.386*eV, 2.433*eV, 2.481*eV,
	  2.532*eV, 2.585*eV, 2.640*eV, 2.697*eV,
	  2.757*eV, 2.820*eV, 2.885*eV, 2.954*eV,
	  3.026*eV, 3.102*eV, 3.181*eV, 3.265*eV,
	  3.353*eV, 3.446*eV, 3.545*eV, 3.649*eV,
	  3.760*eV, 3.877*eV, 4.002*eV, 4.136*eV };
      //
      // Water
      //	      
      G4double RefractiveIndex1[nEntries] =
	{ 1.3435, 1.344,  1.3445, 1.345,  1.3455,
	  1.346,  1.3465, 1.347,  1.3475, 1.348,
	  1.3485, 1.3492, 1.35,   1.3505, 1.351,
	  1.3518, 1.3522, 1.3530, 1.3535, 1.354,
	  1.3545, 1.355,  1.3555, 1.356,  1.3568,
	  1.3572, 1.358,  1.3585, 1.359,  1.3595,
	  1.36,   1.3608};
  
      G4double Absorption1[nEntries] =
	{3.448*m,  4.082*m,  6.329*m,  9.174*m, 12.346*m, 13.889*m,
	 15.152*m, 17.241*m, 18.868*m, 20.000*m, 26.316*m, 35.714*m,
	 45.455*m, 47.619*m, 52.632*m, 52.632*m, 55.556*m, 52.632*m,
	 52.632*m, 47.619*m, 45.455*m, 41.667*m, 37.037*m, 33.333*m,
	 30.000*m, 28.500*m, 27.000*m, 24.500*m, 22.000*m, 19.500*m,
	 17.500*m, 14.500*m };
  
      G4MaterialPropertiesTable* myMPT1 = new G4MaterialPropertiesTable();
      myMPT1->AddProperty("RINDEX",       PhotonEnergy, RefractiveIndex1,nEntries);
      myMPT1->AddProperty("ABSLENGTH",    PhotonEnergy, Absorption1,     nEntries);
  
      Water->SetMaterialPropertiesTable(myMPT1);
  
  
  
      // ************************* SERENA (through ExN06) *************************
      //
      // Air
      //
      G4double RefractiveIndex2[nEntries] =
	{ 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00,
	  1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00,
	  1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00,
	  1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00,
	  1.00, 1.00, 1.00, 1.00 };
  
      G4MaterialPropertiesTable* myMPT2 = new G4MaterialPropertiesTable();
      myMPT2->AddProperty("RINDEX", PhotonEnergy, RefractiveIndex2, nEntries);
  
      Air->SetMaterialPropertiesTable(myMPT2);
      // ***************************************************************************
  
}

void
Xenon1tDetectorConstruction::DefineGeometryParameters()
{
  //================================== Laboratory =================================
  m_hGeometryParameters["LabHeight"]			= 13.*m;
  m_hGeometryParameters["LabRadius"]			= 6.*m;
  //================================== Water tank =================================
  m_hGeometryParameters["WaterTankHeight"]			= 10.5*m;
  m_hGeometryParameters["WaterHeight"]				= 10.2*m;
  m_hGeometryParameters["WaterTankOuterRadius"]		= 4.8*m;
  m_hGeometryParameters["WaterTankThickness"]			= 2.*mm;
  m_hGeometryParameters["TankConsR1"]					= GetGeometryParameter("WaterTankOuterRadius");	// base
  //	m_hGeometryParameters["TankConsR2"]					= 4.0*m;	// top
  //	m_hGeometryParameters["TankConsHeight"]				= 2.0*m;	// height
  //	m_hGeometryParameters["WaterLineBase"]				= 4.12*m;	// waterlevel	
  m_hGeometryParameters["TankConsR2"]					= 1.20282*m;	// top			// TO BE CHANGED T1 <--> T2
  m_hGeometryParameters["TankConsHeight"]				= 1.490*m;	// height			// TO BE CHANGED T1 <--> T2
  m_hGeometryParameters["WaterLineBase"]				= 1.923*m;	// waterlevel	// TO BE CHANGED T1 <--> T2	
  
  m_hGeometryParameters["WaterTankCylinderHeight"]	= GetGeometryParameter("WaterTankHeight") - GetGeometryParameter("TankConsHeight");
  m_hGeometryParameters["WaterTankCylinderInnerHeight"]	= GetGeometryParameter("WaterTankCylinderHeight") - GetGeometryParameter("WaterTankThickness");
  m_hGeometryParameters["WaterTankInnerRadius"]		= GetGeometryParameter("WaterTankOuterRadius") - GetGeometryParameter("WaterTankThickness");
	
  m_hGeometryParameters["TankOffset"]					= GetGeometryParameter("WaterHeight") - GetGeometryParameter("WaterTankCylinderHeight");
	
  m_hGeometryParameters["WaterConsR1"] =  GetGeometryParameter("TankConsR1") - GetGeometryParameter("WaterTankThickness");	// base
  m_hGeometryParameters["WaterConsR2"] =  GetGeometryParameter("TankConsR2") - GetGeometryParameter("WaterTankThickness");	// top
  m_hGeometryParameters["WaterConsHeight"] =  GetGeometryParameter("TankConsHeight") - GetGeometryParameter("WaterTankThickness");	// height
	
  m_hGeometryParameters["AirConsR1"] = GetGeometryParameter("WaterLineBase") - GetGeometryParameter("WaterTankThickness");	// base
  m_hGeometryParameters["AirConsR2"] = GetGeometryParameter("TankConsR2") - GetGeometryParameter("WaterTankThickness");	// top
  m_hGeometryParameters["AirConsHeight"] = GetGeometryParameter("WaterTankHeight") - GetGeometryParameter("WaterHeight") - GetGeometryParameter("WaterTankThickness");	// height
  m_hGeometryParameters["AirConsOffset"] = GetGeometryParameter("WaterHeight") - GetGeometryParameter("WaterTankCylinderHeight");
	
  //================================== HEXAPOD  ========================================SERENA
  //----------TOP PLATFORM----------
  m_hGeometryParameters["l_Astruso"]						= (1000. + 12.68)*mm;
  m_hGeometryParameters["L_Astruso"]						= (1950. + 11.84)*mm;
  m_hGeometryParameters["H_Astruso"]						= 2576.*mm;
  m_hGeometryParameters["h_Astruso"]						= 1425.*mm;
  m_hGeometryParameters["ds_Astruso"]						= 110.*mm;
  m_hGeometryParameters["alfa_Astruso"]					= (60./2)*deg;
  m_hGeometryParameters["half_dz_Astruso"]				= 100.0*mm;
  m_hGeometryParameters["top_rotation_angle"]				= 60.*deg;
  m_hGeometryParameters["TopPlatformBaseline"]			= 7986.*mm;
  m_hGeometryParameters["zTopPlatform"]					=  -GetGeometryParameter("WaterTankCylinderInnerHeight")*0.5*mm + GetGeometryParameter("TopPlatformBaseline") + GetGeometryParameter("half_dz_Astruso"); 
  
  //----------HOLLOW LEGS----------
  m_hGeometryParameters["HexapodLegLength"]				= 8566.*mm; //8486.*mm;
  m_hGeometryParameters["HexapodLegOuterRadius"]			= 163.115*mm;
  m_hGeometryParameters["HexapodLegThickness"]			= 6.35*mm;
  m_hGeometryParameters["HexapodLegInnerRadius"]			= GetGeometryParameter("HexapodLegOuterRadius") - GetGeometryParameter("HexapodLegThickness");
  m_hGeometryParameters["R_LegsBottomBases"]				= 4150.*mm; //4100.*mm;
  m_hGeometryParameters["y_FirstLegsCouple"]				= 300.*mm; //360.*mm;
  m_hGeometryParameters["tilt_angle"]						= 22.3*deg; //20.3*deg;
  m_hGeometryParameters["open_angle"]						= (7.77/2)*deg; //6.6418*deg;
  m_hGeometryParameters["rotation_angle"]					= 120.*deg;
  //======================================================================================= SERENA

  //=============================New Support Structure================ANDREA T.
  
  m_hGeometryParameters["x_outer"]                               = 75.*mm;
  m_hGeometryParameters["y_outer"]                               = 75.*mm;
  m_hGeometryParameters["z_outer"]                               = 1582.5*mm;
  m_hGeometryParameters["x_inner"]                               = 69.*mm;
  m_hGeometryParameters["y_inner"]                               = 69.*mm;
  m_hGeometryParameters["z_inner"]                               = 1582.5*mm;
  m_hGeometryParameters["z_horizontal_outer"]                    = 2175.*mm;
  m_hGeometryParameters["z_horizontal_inner"]                    = 2175.*mm;
  m_hGeometryParameters["z_medium_outer"]                               = 1532.5*mm;
  m_hGeometryParameters["z_medium_inner"]                               = 1532.5*mm;
  m_hGeometryParameters["x_pos_floor_leg1"]                              = 2250.*mm;
  m_hGeometryParameters["y_pos_floor_leg1"]                              = 2250.*mm;
  m_hGeometryParameters["z_pos_floor_leg1"]                              =-(GetGeometryParameter("WaterTankCylinderInnerHeight")/2.  - GetGeometryParameter("z_outer"));
  m_hGeometryParameters["x_pos_floor_leg2"]                              = 2250.*mm;
  m_hGeometryParameters["y_pos_floor_leg2"]                              = -2250.*mm;
  m_hGeometryParameters["z_pos_floor_leg2"]                              = -(GetGeometryParameter("WaterTankCylinderInnerHeight")/2.  - GetGeometryParameter("z_outer"));
  m_hGeometryParameters["x_pos_floor_leg3"]                              = -2250.*mm;
  m_hGeometryParameters["y_pos_floor_leg3"]                              = 2250.*mm;
  m_hGeometryParameters["z_pos_floor_leg3"]                              = -(GetGeometryParameter("WaterTankCylinderInnerHeight")/2.  - GetGeometryParameter("z_outer"));
  m_hGeometryParameters["x_pos_floor_leg4"]                              = -2250.*mm;
  m_hGeometryParameters["y_pos_floor_leg4"]                              = -2250.*mm;
  m_hGeometryParameters["z_pos_floor_leg4"]                              =-(GetGeometryParameter("WaterTankCylinderInnerHeight")/2.  - GetGeometryParameter("z_outer"));
  m_hGeometryParameters["z_tilt_leg"]                                   = 2069.5*mm;

  m_hGeometryParameters["z_platform"]                                   = 745.*mm;
  m_hGeometryParameters["x_platform"]                                   = (1280.+75.+75.)*mm;
  m_hGeometryParameters["x_platform1"]                                   =(1280.+75.+150.+1490.+75.)*mm;
  m_hGeometryParameters["R_brace_rods"]                                   = 7.*mm;
  m_hGeometryParameters["R_tie_rods"]                                   =10.*mm;
    
  
    m_hGeometryParameters["y_spreader"]                                   =60.*mm;
    m_hGeometryParameters["x_spreader"]                                   =40.*mm;
    m_hGeometryParameters["z_spreader"]                                   =450.*mm;
    m_hGeometryParameters["z_pos_spreader"]                               =(8310.*mm -GetGeometryParameter("WaterTankCylinderInnerHeight")/2.  );
    m_hGeometryParameters["y_inner_spreader"]                                   =54.*mm;
    m_hGeometryParameters["x_inner_spreader"]                                   =34.*mm;



 //===========================================PIPES======================================== ANDREA TISENI

  //Central Pipe
    
  // thickness central pipes
m_hGeometryParameters["Wall_thickness_central_external_pipe"] = 3.2*mm;
  m_hGeometryParameters["Wall_thickness_central_internal_big_pipe"] = 2.*mm;
  m_hGeometryParameters["Wall_thickness_central_internal_pipe_1"] = 2.*mm;
  m_hGeometryParameters["Wall_thickness_central_internal_pipe_2"] = 3.*mm;
 m_hGeometryParameters["Wall_thickness_central_internal_pipe_3"] = 0.5*mm;
 m_hGeometryParameters["Wall_thickness_central_internal_pipe_4"] = 1.*mm;
m_hGeometryParameters["Wall_thickness_central_internal_pipe_5"] = 1.*mm;
 
    //radius central pipes
    
    m_hGeometryParameters["Rmax_cylinder_external_central_pipe"] = 0.5*406.6*mm;
  m_hGeometryParameters["Rmin_cylinder_external_central_pipe"] = GetGeometryParameter("Rmax_cylinder_external_central_pipe") -         GetGeometryParameter("Wall_thickness_central_external_pipe");
  m_hGeometryParameters["Rmax_cylinder_internal_central_big_pipe"] = 0.5*254.*mm;
  m_hGeometryParameters["Rmin_cylinder_internal_central_big_pipe"] = GetGeometryParameter("Rmax_cylinder_internal_central_big_pipe") -         GetGeometryParameter("Wall_thickness_central_internal_big_pipe");
  m_hGeometryParameters["Rmax_cylinder_internal_central_pipe_1"] = 0.5*104.*mm;
  m_hGeometryParameters["Rmin_cylinder_internal_central_pipe_1"] = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_1") -         GetGeometryParameter("Wall_thickness_central_internal_pipe_1");
  m_hGeometryParameters["Rmax_cylinder_internal_central_pipe_2"] = 0.5*48.3*mm;
  m_hGeometryParameters["Rmin_cylinder_internal_central_pipe_2"] = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_2") -         GetGeometryParameter("Wall_thickness_central_internal_pipe_2");
    m_hGeometryParameters["Rmax_cylinder_internal_central_pipe_3"] = 0.5*18.*mm;
    m_hGeometryParameters["Rmin_cylinder_internal_central_pipe_3"] = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_3") -         GetGeometryParameter("Wall_thickness_central_internal_pipe_3");
    m_hGeometryParameters["Rmax_cylinder_internal_central_pipe_4"] = 0.5*12.7*mm;
    m_hGeometryParameters["Rmin_cylinder_internal_central_pipe_4"] = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_4") -         GetGeometryParameter("Wall_thickness_central_internal_pipe_4");
    m_hGeometryParameters["Rmax_cylinder_internal_central_pipe_5"] = 0.5*6.35*mm;
    m_hGeometryParameters["Rmin_cylinder_internal_central_pipe_5"] = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_5") -         GetGeometryParameter("Wall_thickness_central_internal_pipe_5");
    m_hGeometryParameters["R_small_stain"] = GetGeometryParameter("Rmax_cylinder_external_central_pipe")+2.*mm;
    m_hGeometryParameters["height_small_stain"] = 30.*mm;
    m_hGeometryParameters["R_plate"] = 0.5*480.0*mm;
    m_hGeometryParameters["h_plate"] = 0.5*6.*mm;
    m_hGeometryParameters["h_plate_low"] = 0.5*17.*mm;
    m_hGeometryParameters["y_pipe_box"] = 0.5*80.*mm;
    m_hGeometryParameters["z_pipe_box"] = 0.5*155.*mm;
    
    

    m_hGeometryParameters["y_pipe_box_1"] = 0.5*48.*mm;
    m_hGeometryParameters["z_pipe_box_1"] = 0.5*60*mm;
    m_hGeometryParameters["R_cyl_screw_1"] = 0.5*47.*mm;
    m_hGeometryParameters["height_cyl_screw_1"] = 0.5*10.*mm;
    m_hGeometryParameters["R_cyl_screw_2"] = 0.5*26.*mm;
    m_hGeometryParameters["height_cyl_screw_2"] = 0.5*16.*mm;
    m_hGeometryParameters["R_min_tolon"] = 0.5*258.*mm;
    m_hGeometryParameters["R_max_tolon"] = 0.5*310.*mm;
    m_hGeometryParameters["h_tolon"] = 10.*mm;

    


    
    
    
    
    
    m_hGeometryParameters["x_offset_internal_1"]= -45.*mm;
    m_hGeometryParameters["y_offset_internal_1"]= 0.*mm;
    m_hGeometryParameters["x_offset_internal_2"] = 78.*mm;
    m_hGeometryParameters["y_offset_internal_2"] = 0.*mm;
    m_hGeometryParameters["x_offset_internal_3"] = 35.*mm;
    m_hGeometryParameters["y_offset_internal_3"] = -70.*mm;
    m_hGeometryParameters["x_offset_internal_4"] = -10.*mm;
    m_hGeometryParameters["y_offset_internal_4"] = -95.*mm;
    m_hGeometryParameters["x_offset_internal_5"] = 35.*mm;
    m_hGeometryParameters["y_offset_internal_5"] = 70.*mm;
    
    //flange central pipes
    
  m_hGeometryParameters["flange_height"] = 0.5*80.*mm;
  m_hGeometryParameters["flange_height_internal"] = 0.5*5.*mm;
  m_hGeometryParameters["cylinder_height_central_pipe"] = 0.5*(435.+GetGeometryParameter("flange_height"))*mm;//0.5*(490.2*mm+2.*GetGeometryParameter("flange_height"));
    m_hGeometryParameters["cylinder_height_low"] = 0.5*184.*mm;//0.5*(490.2*mm+2.*GetGeometryParameter("flange_height"));
    
  //m_hGeometryParameters["torus_height"] = 534.25*mm;
  m_hGeometryParameters["torus_spanned_angle"]=85.*deg;
  m_hGeometryParameters["torus_radius"] = 373.*mm;
 m_hGeometryParameters["torus_radius_internal_5"] = 443.*mm;
    m_hGeometryParameters["torus_radius_internal_3"] = 303.*mm;
    m_hGeometryParameters["torus_radius_internal_4"] = 278.*mm;
    
    
  //m_hGeometryParameters["cylinder_tilted_height_central_pipe"] = 0.5*(640.2*mm+2.*GetGeometryParameter("flange_height"));
 // m_hGeometryParameters["cylinder_tilted_height_central_pipe"] = 0.5*505.*mm;
  m_hGeometryParameters["cylinder_tilted_long_height_central_pipe"] = 0.5*4400.*mm;
  m_hGeometryParameters["flange_radius"] = 0.5*560.*mm;
  m_hGeometryParameters["internal_big_flange_radius"] = 0.5*305.*mm;
    m_hGeometryParameters["internal_flange_radius_1"] = 0.5*134.*mm;
    m_hGeometryParameters["internal_flange_radius_2"] = 0.5*72.*mm;
    m_hGeometryParameters["internal_flange_radius_3"] = 0.5*44.*mm;
    m_hGeometryParameters["internal_flange_radius_4"] = 0.5*40.*mm;
    m_hGeometryParameters["internal_flange_radius_5"] = 0.5*34.*mm;
    
    
    // Small Pipes
    
    m_hGeometryParameters["Wall_thickness_small_pipe"] = 1.5*mm;
    m_hGeometryParameters["Rmax_cylinder_small_pipe"] = 0.5*38.1*mm;
    m_hGeometryParameters["Rmin_cylinder_small_pipe"] = GetGeometryParameter("Rmax_cylinder_small_pipe") -         GetGeometryParameter("Wall_thickness_small_pipe");
    
    m_hGeometryParameters["flange_height_small_pipe"] = 0.5*27.*mm;
    m_hGeometryParameters["flange_radius_small_pipe"] = 0.5*125.6*mm;
    m_hGeometryParameters["cylinder_height_small_pipe"] = 0.5*(435.+GetGeometryParameter("flange_height_small_pipe"))*mm;
    m_hGeometryParameters["cylinder_long_height_small_pipe"] = 0.5*(4600.)*mm;
    m_hGeometryParameters["torus_radius_small_pipe"] = 373.*mm;



  //================================== CABLES PIPE ========================================SERENA 
  m_hGeometryParameters["CablesPipeBaseThickness"] = 5.*mm;
  m_hGeometryParameters["CablesPipeBaseOuterRadius"] = (400. /2.)*mm;
  m_hGeometryParameters["CablesPipeBaseInnerRadius"] = GetGeometryParameter("CablesPipeBaseOuterRadius") - GetGeometryParameter("CablesPipeBaseThickness");
  m_hGeometryParameters["CablesPipeBaseHeight"] = (1514. / 2.)*mm ;
	
  m_hGeometryParameters["CablePipe_tilt_angle"] = 95.*deg;
  m_hGeometryParameters["CablesPipeThickness"] = 5.*mm;
  m_hGeometryParameters["CablesPipeOuterRadius"] = (400. /2.)*mm;
  m_hGeometryParameters["CablesPipeInnerRadius"] =  GetGeometryParameter("CablesPipeOuterRadius") - GetGeometryParameter("CablesPipeThickness");
  //	m_hGeometryParameters["CablesPipeHeight"] =  GetGeometryParameter("WaterTankInnerRadius") - GetGeometryParameter("CablesPipeBaseOuterRadius") -1.67*cm;
  m_hGeometryParameters["CablesPipeHeight"] =  (GetGeometryParameter("WaterTankInnerRadius") - GetGeometryParameter("CablesPipeBaseOuterRadius") 
                                                - 2.*GetGeometryParameter("CablesPipeOuterRadius")*sin(GetGeometryParameter("CablePipe_tilt_angle") -90.*deg))/cos(GetGeometryParameter("CablePipe_tilt_angle") -90.*deg);
  
  //======================================================================================= SERENA
  
  //================================== Internal Reflector ================================= SERENA
  m_hGeometryParameters["InternalReflectorThickness"]		= 2.*mm;
  m_hGeometryParameters["InternalReflectorDistance"]		= 1.5*m;
  m_hGeometryParameters["InternalReflectorOuterHeight"]	= GetGeometryParameter("WaterTankCylinderInnerHeight") - 2*GetGeometryParameter("InternalReflectorDistance");
  m_hGeometryParameters["InternalReflectorInnerHeight"]	= GetGeometryParameter("InternalReflectorOuterHeight") - GetGeometryParameter("InternalReflectorThickness");
  m_hGeometryParameters["InternalReflectorOuterRadius"]	= GetGeometryParameter("WaterTankInnerRadius") - GetGeometryParameter("InternalReflectorDistance");
  m_hGeometryParameters["InternalReflectorInnerRadius"]	= GetGeometryParameter("InternalReflectorOuterRadius") - GetGeometryParameter("WaterTankThickness");
	
  m_hGeometryParameters["InternalReflectorInsideThickness"]	= 2.*mm;
  m_hGeometryParameters["InternalReflectorInsideDistance"]	= GetGeometryParameter("InternalReflectorThickness") + 1.0*um;
  m_hGeometryParameters["InternalReflectorInsideOuterHeight"]	= GetGeometryParameter("InternalReflectorOuterHeight") - 2*GetGeometryParameter("InternalReflectorInsideDistance");
  m_hGeometryParameters["InternalReflectorInsideInnerHeight"]	= GetGeometryParameter("InternalReflectorInsideOuterHeight") - GetGeometryParameter("InternalReflectorInsideThickness");
  m_hGeometryParameters["InternalReflectorInsideOuterRadius"]	= GetGeometryParameter("InternalReflectorOuterRadius") - GetGeometryParameter("InternalReflectorInsideDistance");
  m_hGeometryParameters["InternalReflectorInsideInnerRadius"]	= GetGeometryParameter("InternalReflectorInsideOuterRadius") - GetGeometryParameter("InternalReflectorInsideThickness");
  //======================================================================================= SERENA
  
  // choose between the standard and the Nikhef geometry for the cryostat
  if (pCryostatType == "standard") {
    G4Exception("XenonDetectorConstruction::DefineGeometryParameters()","DetectorConstruction",FatalException,"standard geometry obsolete");
  } else if (pCryostatType == "Nikhef") { 
    G4Exception("XenonDetectorConstruction::DefineGeometryParameters()","DetectorConstruction",FatalException,"Nikhef geometry for cryo vessel obsolete");
  } else if (pCryostatType == "Columbia") { 
    // APC 08-03-2012
    
    //
    // Define the parameters for the CU cryostat
    //
    
    //================================== cryostat =================================
  
    if (pCryostatMaterial != "SS316Ti")
      G4Exception("XenonDetectorConstruction::DefineGeometryParameters()","DetectorConstruction",FatalException,"Bad Cryostat material: it must be SS316Ti");

    // dimensions from Donato CAD - February '14    
    // Shell Thickness
    
    m_hGeometryParameters["OuterCryostatThickness"]        = 5.00*mm; //ok
    m_hGeometryParameters["OuterCryostatThicknessTop"]     = 5.00*mm; //ok
    m_hGeometryParameters["OuterCryostatThicknessBot"]     = 5.00*mm; //ok
    
    m_hGeometryParameters["InnerCryostatThickness"]        = 5.00*mm; //ok
    m_hGeometryParameters["InnerCryostatThicknessTop"]     = 5.00*mm; //ok
    m_hGeometryParameters["InnerCryostatThicknessBot"]     = 5.00*mm; //ok
   

    // outer vessel geometry
    m_hGeometryParameters["OuterCryostatOuterDiameter"]    = 1630.*mm; //ok
    m_hGeometryParameters["OuterCryostatCylinderHeight"]   = 1687.*mm; //ok
    m_hGeometryParameters["OuterCryostatR0top"]            = 1309.*mm; //ok
    m_hGeometryParameters["OuterCryostatR1top"]            = 256.*mm;  //ok
    m_hGeometryParameters["OuterCryostatR0bot"]            = 1309.*mm; //ok
    m_hGeometryParameters["OuterCryostatR1bot"]            = 256.*mm;  //ok
      
    // flange between top and bottom of outer vessel
    m_hGeometryParameters["OuterCryostatFlangeHeight"]     =  90.*mm; //ok
    m_hGeometryParameters["OuterCryostatFlangeZ"]          = 781.*mm; //ok
    m_hGeometryParameters["OuterCryostatFlangeThickness"]  = 100.*mm; //ok
    m_hGeometryParameters["OuterCryostatOffsetZ"]          = 530.*mm; //ok, taken from an email by A.Tiseni and Rob, 20 Feb 2014 (platform and Outer Cryo separated by 533 mm along Z)
      
    // inner vessel geometry
    m_hGeometryParameters["InnerCryostatOuterDiameter"]    = 1110.*mm; //ok
    m_hGeometryParameters["InnerCryostatCylinderHeight"]   = 1420.*mm; //ok 
    m_hGeometryParameters["InnerCryostatR0top"]            = 893.*mm;  //ok
    m_hGeometryParameters["InnerCryostatR1top"]            = 176.*mm;  //ok
    m_hGeometryParameters["InnerCryostatR0bot"]            = 893.*mm;  //ok
    m_hGeometryParameters["InnerCryostatR1bot"]            = 176.*mm;  //ok

    // flange between top and bottom of inner vessel
    m_hGeometryParameters["InnerCryostatFlangeHeight"]     =  90.*mm; //ok
    m_hGeometryParameters["InnerCryostatFlangeZ"]          = 614.*mm; //ok
    m_hGeometryParameters["InnerCryostatFlangeThickness"]  = 62.5*mm; //ok 
    m_hGeometryParameters["InnerCryostatOffsetZ"]          = 96.*mm; //ok 
    
  } 
  
  //================================== HVFT ==================================================
  
  m_hGeometryParameters["HVFT_angular_Offset"]    = 4.80587*radian;
  
  m_hGeometryParameters["HVFT_OuterSS_Radius"]    = 12.7*mm;
  m_hGeometryParameters["HVFT_InnerPoly_Radius"]  = 11.049*mm;
  m_hGeometryParameters["HVFT_InnerPoly_Height"]  = 92.964*mm;
  m_hGeometryParameters["HVFT_BottInnSS_Radius"]  = 6.*mm;
  m_hGeometryParameters["HVFT_lastBottSS_Radius"] = 6.35*mm;
  m_hGeometryParameters["lastSShvft_height"]      = 16.97*mm;
  
  m_hGeometryParameters["HVFTdistanceFromInnerCryostat"] = 5.*mm;

  //================================== Liquid xenon =================================
  m_hGeometryParameters["NbPolyhedraSides"]    = 12;
  m_hGeometryParameters["XenonCylinderHeight"]    = GetGeometryParameter("InnerCryostatCylinderHeight");
  m_hGeometryParameters["LXeDomeHeight"]          = GetGeometryParameter("InnerCryostatDomeInnerHeight");
  m_hGeometryParameters["LXeRadius"]              = GetGeometryParameter("InnerCryostatInnerRadius");
  
  m_hGeometryParameters["LXeOffsetZ"]      = 0*cm;// -2.252*cm;
  
  
  // ****** END OF CODE BY AUKE-PC ****** --------------------------------------------------------	
  
  //================================== Lead Brick ========================================Andrew 22/08/12
  m_hGeometryParameters["LeadBrick_len_x"] = 10.0 *cm;
  m_hGeometryParameters["LeadBrick_len_y"] = 14.7 *cm;
  m_hGeometryParameters["LeadBrick_len_z"] = 10.0 *cm;
  
  //Position
  m_hGeometryParameters["LeadBrick_pos_y"] = 650 *mm+GetGeometryParameter("LeadBrick_len_y")/2;
  m_hGeometryParameters["LeadBrick_pos_x"] = 0 *mm;
  m_hGeometryParameters["LeadBrick_pos_z"] = 0 *mm;
  //================================== Generator ========================================Andrew 22/08/12
  m_hGeometryParameters["GeneratorContainer_oD"] = 134 *mm;
    
  //Positions
  m_hGeometryParameters["GeneratorContainer_x"] = 0 *mm;
  //Outside diameter of cryostat plus radius of neutron generator
  m_hGeometryParameters["GeneratorContainer_y"] = GetGeometryParameter("OuterCryostatOuterDiameter")/2
    + GetGeometryParameter("GeneratorContainer_oD")/2;
  m_hGeometryParameters["GeneratorContainer_z"] = -119. *mm;
    
  m_hGeometryParameters["PmtBasesDiameter"]       =  52.5*mm;
  m_hGeometryParameters["PmtBasesHeight"]         =  7.0*mm;
 
  // PMTs
  m_hGeometryParameters["NbOfTopPMTsRow"]        =   7;
  m_hGeometryParameters["NbOfTopPMTs"]           = 127;
  m_hGeometryParameters["NbOfBottomPMTs"]        = 121;
  m_hGeometryParameters["NbOfPMTs"]              = 248;
  m_hGeometryParameters["PMTDistance_TPCtop"]           =  79.5*mm;
  m_hGeometryParameters["PMTDistance_TPCbottom"]           =  80.*mm;
  
  m_hGeometryParameters["PMTHeight"]             = 114.*mm;
  
  m_hGeometryParameters["TopTeflonThickness"]    =   5.*mm;
  m_hGeometryParameters["BottomTeflonThickness"] =   5.*mm;
  
  // Filler (bottom & lateral)

  m_hGeometryParameters["LXeBelowTPC"]           =  pBufferThickness; // 100.*mm;//5.*mm;//



  //================================== Gas xenon =================================
  m_hGeometryParameters["LiquidLevelZ"]			= 48.5*cm; // 698.315*mm; //
  m_hGeometryParameters["GXeTopZ"]			= 0.5*GetGeometryParameter("InnerCryostatCylinderHeight")-GetGeometryParameter("LXeOffsetZ");
  m_hGeometryParameters["GXeBottomZ"]			= 47.5*cm;
  m_hGeometryParameters["GXeRadius"]			= GetGeometryParameter("InnerCryostatInnerRadius");
  m_hGeometryParameters["GXeCutTopZ"]			= GetGeometryParameter("LiquidLevelZ");
  m_hGeometryParameters["GXeCutBottomZ"]			= GetGeometryParameter("GXeBottomZ");
  m_hGeometryParameters["GXeCutRadius"]			= 50.*cm;
 
 
  //==================================== QUPIDs =====================================
  m_hGeometryParameters["QUPIDWindowOuterRadius"]    = 37.*mm;
  m_hGeometryParameters["PmtOuterRadius"]            = 38.*mm;
  m_hGeometryParameters["QUPIDPhotocathodeOuterRadius"]  = 36.6*mm;
  m_hGeometryParameters["QUPIDPhotocathodeInnerRadius"]  = 36.5*mm;
  m_hGeometryParameters["QUPIDWindowOuterHeight"]    = 26.57*mm;
  m_hGeometryParameters["QUPIDPhotocathodeOuterHeight"]  = 26.17*mm;
  m_hGeometryParameters["QUPIDPhotocathodeInnerHeight"]  = 26.07*mm;
  m_hGeometryParameters["QUPIDBodyOuterRadius"]    = 35.5*mm;
  m_hGeometryParameters["QUPIDBodyInnerRadius"]    = 35.*mm;
  m_hGeometryParameters["QUPIDBodyHeight"]    = 44.93*mm;
  m_hGeometryParameters["QUPIDBodyAluminiumCoatingHeight"]= 15.*mm;
  m_hGeometryParameters["QUPIDAluminiumCoatingThickness"]  = 0.1*mm;
  m_hGeometryParameters["QUPIDAPDRadius"]      = 5.*mm;
  m_hGeometryParameters["QUPIDAPDHeight"]      = 23.*mm;
  m_hGeometryParameters["QUPIDBaseRadius"]    = 36.*mm;
  m_hGeometryParameters["QUPIDBaseThickness"]    = 5.*mm;
  
  
  //==================================== 8" PMTs ===================================== (Hamamatsu R7081MOD-ASSY)	// SERENA
  m_hGeometryParameters["PMTWindowOuterRadius"]			= 101.0*mm;
  m_hGeometryParameters["PMTWindowOuterHalfZ"]			= 67.5*mm;
  m_hGeometryParameters["PMTWindowTopZ"]					= 65.*mm;
  m_hGeometryParameters["PMTPhotocathodeOuterRadius"]		= 99.5*mm;
  m_hGeometryParameters["PMTPhotocathodeOuterHalfZ"]		= 66.5*mm;
  m_hGeometryParameters["PMTPhotocathodeTopZ"]			= -33.*mm;
  m_hGeometryParameters["PMTPhotocathodeInnerRadius"]		= 99.0*mm;
  m_hGeometryParameters["PMTPhotocathodeInnerHalfZ"]		= 66.*mm;
  m_hGeometryParameters["PMTBodyOuterRadius"]				= 42.*mm;
  m_hGeometryParameters["PMTBodyInnerRadius"]				= 41.*mm;
  m_hGeometryParameters["PMTBodyHeight"]					= 85.*mm;
  m_hGeometryParameters["PMTBaseOuterRadius"]				= 42.*mm;
  m_hGeometryParameters["PMTBaseInnerRadius"]				= 41.*mm;
  m_hGeometryParameters["PMTBaseHeight"]					= 55.*mm;
  m_hGeometryParameters["PMTBaseInteriorHeight"]			= 53.*mm;
  																																			   
  //==================================== Number of PMTs =====================================
  m_hGeometryParameters["NbPMTs"]					= 121+121+0+84; // Top + Bottom + LS + Water  
  m_hGeometryParameters["NbTopPMTs"]				= 121;
  m_hGeometryParameters["NbBottomPMTs"]			= 121;
  m_hGeometryParameters["NbLSPMTs"]				= 0;  
  m_hGeometryParameters["NbLSTopPMTs"]			= 0;
  m_hGeometryParameters["NbLSBottomPMTs"]			= 0;
  m_hGeometryParameters["NbLSSidePMTs"]			= 0;
  m_hGeometryParameters["NbLSSidePMTColumns"]		= 0;
  m_hGeometryParameters["NbLSSidePMTRows"]		= 0;
  m_hGeometryParameters["NbWaterPMTs"]			= 84;			// SERENA
  m_hGeometryParameters["NbWaterTopPMTs"]			= 24;			// SERENA
  m_hGeometryParameters["NbWaterBottomPMTs"]		= 24;			// SERENA
  m_hGeometryParameters["NbWaterSidePMTs"]		= 36;			// SERENA
  m_hGeometryParameters["NbWaterSidePMTColumns"]	= 12;			// SERENA
  m_hGeometryParameters["NbWaterSidePMTRows"]		= 3;			// SERENA
  
  
  
  //==================================== PMT positions =====================================
  m_hGeometryParameters["TopQUPIDWindowZ"]		= 58.2*cm;
  m_hGeometryParameters["BottomQUPIDWindowZ"]		= -54.2*cm;
  m_hGeometryParameters["QUPIDDistance"]			= 8.*cm;
  m_hGeometryParameters["LSTopPMTWindowZ"]		= 195.*cm;
  m_hGeometryParameters["LSBottomPMTWindowZ"]		= -195.*cm;
  m_hGeometryParameters["LSSidePMTWindowR"]		= 170.*cm;
  m_hGeometryParameters["LSTopPMTDistance"]		= 80.*cm;
  m_hGeometryParameters["LSBottomPMTDistance"]		= 80.*cm;
  m_hGeometryParameters["LSSidePMTRowDistance"]		= 75.*cm;
  //m_hGeometryParameters["WaterTopPMTWindowZ"]		= 49.25*cm;	// Serena's comment
  m_hGeometryParameters["WaterTopPMTWindowZ"]		= 429.75*cm;	// Serena's comment// TO BE CHANGED T1 <--> T2 tc
  m_hGeometryParameters["WaterBottomPMTWindowZ"]		= -429.75*cm;
  //m_hGeometryParameters["WaterSidePMTWindowR"]		= 470.*cm;	//  for Water Tank radius r = 5.0 m (470 = 500 - 30) with 30cm height of the PMT
  m_hGeometryParameters["WaterSidePMTWindowR"]		= 450.*cm;  // SERENA for Water Tank radius r = 5.5 m (520 = 550 - 30) with 30cm height of the PMT
  //	m_hGeometryParameters["WaterTopPMTDistance"]		= 182.*cm; //330	//unused variable
  //	m_hGeometryParameters["WaterBottomPMTDistance"]		= 212.*cm; //300	//unused variable
  //	m_hGeometryParameters["WaterSidePMTRowDistance"]	= 195.*cm;	// Serena's comment
  m_hGeometryParameters["WaterSidePMTRowDistance"]	= 214.875*cm;	// SERENA // TO BE CHANGED T1 <--> T2 tc
  
  // verifications
  //assert(GetGeometryParameter("OuterCryostatOffsetZ") + GetGeometryParameter("InnerCryostatOffsetZ") + GetGeometryParameter("LXeOffsetZ") == 0);// this way the tpc is centered at 0
  
	
  //================================== XENON1T new design ==============================================//Fabio Valerio
  
  m_hGeometryParameters["Teflon_shrink"] = 0.015; // 1.5% shrinkage at LXe temperature 
  m_hGeometryParameters["cutRadius"]     = 38.73*mm;
  
  //_______ distance between plates (from the bottom face of the upper plate to the upper face of the lower plate) _____________
  
  m_hGeometryParameters["DistanceTopPlateFromTopPmtHolder"]           = 104.8*mm;//30.*mm;
  m_hGeometryParameters["DistanceTopPmtHolderFromTopPMTCopper"]       = 0.;//85.*mm;
  m_hGeometryParameters["DistanceTopPMTCopperFromTopPTFE"]            = 33.3*mm;
  m_hGeometryParameters["DistanceTopPTFEFromTopElectrodePTFE"]        = 3.*mm;
  m_hGeometryParameters["DistanceBottomRingFromBottomReflector"]      = 5.*mm;
  m_hGeometryParameters["DistanceBottomReflectorFromBottomPTFE"]      = 34.*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["DistanceBottomPTFEFromBottomPMTHolder"]      = 20.2*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["DistancePmtFromPmtBase"]                     = 14.*mm;
  m_hGeometryParameters["DistanceBottomHolderPlateFromBottomFiller"]  = (227. -87.3 -38. + 0.5 + 59.2)*mm; //cMSdec13
  
  //____________________________________________________________________________________________________________________________

  //================================== TPC =============================================================
  
  m_hGeometryParameters["TPCheight"]            = 982.25*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["TPCinnRadius"]         = 479.25*mm;
  m_hGeometryParameters["TPCthikness"]          = 5.*mm;
  m_hGeometryParameters["BelowTPCringHeight"]   = 73.19*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["BelowTPCringThikness"] = 5*mm;
  
  //================================== Top plate =============================================================
  
  m_hGeometryParameters["TopPlateRad"]     = 523.5*mm;
  m_hGeometryParameters["TopPlateHeight"]  = 5.*mm; // MS it was 12mm Copper, now (Feb14) it's 5mm SS
  m_hGeometryParameters["TopPlateOffsetZ"] = 627.*mm; // Offset from Andreas ... in this way it is 26 mm below the level of the upper "face" of the Flange of the Inner Cryostat
  
  //================================== Top PMTs Holder (PTFE) =============================================================
  
  m_hGeometryParameters["TopPmtHolderRad"]    = 522.*mm;
  m_hGeometryParameters["TopPmtHolderHeight"] = 12.5*mm;
  
  //================================== Top Copper (before was Acrylic) =============================================================
  
  m_hGeometryParameters["TopPMTCopperRad"]    = 522.*mm;
  m_hGeometryParameters["TopPMTCopperHeight"] = 20.*mm;
  
  //================================== Top PTFE reflector =============================================================
  
  m_hGeometryParameters["TopPTFERad"]    = 522.*mm;
  m_hGeometryParameters["TopPTFEHeight"] = 11.2*mm;
  m_hGeometryParameters["TopPTFERadiusHoleCut"] = 33.*mm;
  
  //================================== Top PTFE around electrode rings =============================================================
  
  m_hGeometryParameters["TopElectrodePTFEInnRad"]   = 481.25*mm;
  m_hGeometryParameters["TopElectrodePTFEThikness"] = 39.*mm;
  m_hGeometryParameters["TopElectrodePTFEHeight"]   = 64.7*mm - 2.5*mm;
  m_hGeometryParameters["Height_TopElectrodePTFEbelowAnode"]   = 5.*mm;
  
  //==================================  meshes  =============================================================
  
  m_hGeometryParameters["GridMeshThickness"]   = 0.2*mm;

  m_hGeometryParameters["TopScreeningMeshThickness"]   = 0.2*mm;
  m_hGeometryParameters["BottomScreeningMeshThickness"]   = 0.2*mm;
  m_hGeometryParameters["CathodeMeshThickness"]   = 0.2*mm;
  m_hGeometryParameters["AnodeMeshThickness"]   = 0.2*mm;
  m_hGeometryParameters["GateMeshThickness"]   = 0.2*mm;



  //==================================  Top mesh electrode ring =============================================================
  
  m_hGeometryParameters["TopMeshRingInnRad"]   = 508.*mm;
  m_hGeometryParameters["TopMeshRingThikness"] = 13.5*mm;
  m_hGeometryParameters["TopMeshRingHeight"]   = 3.*mm;

  //==================================  Anode electrode ring =============================================================
  
  m_hGeometryParameters["AnodeRingInnRad_1"]    = 484.*mm;
  m_hGeometryParameters["AnodeRingHeight_1"]    = 4.*mm;
  m_hGeometryParameters["AnodeRingThickness_1"] = 20.*mm;
  m_hGeometryParameters["AnodeRingInnRad_2"]    = 498.*mm;
  m_hGeometryParameters["AnodeRingHeight_2"]    = 14.*mm;
  m_hGeometryParameters["AnodeRingThickness_2"] = 6.*mm;
  
  //==================================  Gate electrode ring =============================================================
  
  m_hGeometryParameters["GateRingInnRad"]    = 487.35*mm;
  m_hGeometryParameters["GateRingHeight"]    = 5.*mm;
  m_hGeometryParameters["GateRingThickness"] = 15.*mm;
  
  //================================== SS Plate + SS ring =============================================================
  
  m_hGeometryParameters["SSPlateInnRad"]    =  487.35*mm;
  m_hGeometryParameters["SSPlateThickness"] =  34.15*mm;
  m_hGeometryParameters["SSPlateHeight"]    =  10.*mm;
  
  m_hGeometryParameters["SSRingThickness"]  = 6.*mm;
  m_hGeometryParameters["SSRingHeight_LXe"] = 32.25*mm;
  
  //================================== Field shaping rings & PTFE supports ======================================
  
  m_hGeometryParameters["FieldShaperRingsHeight"]    = 5.*mm;
  m_hGeometryParameters["FieldShaperRingsTotNum"]    = 74;
  m_hGeometryParameters["FieldShaperRingsThickness"] = 5.00*mm;
  m_hGeometryParameters["FieldShaperRingsStep"]      = 13.00*mm * (1.- GetGeometryParameter("Teflon_shrink") );

  m_hGeometryParameters["Cutbase_y"] = 7.0*mm;
  m_hGeometryParameters["Cutbase_z"] = 10.1*mm;
  
  //============================== Copper ring below pillars =======================================================
  
  m_hGeometryParameters["CopperRingInnRad"]    = 494.*mm;
  m_hGeometryParameters["CopperRingThickness"] = 20.*mm;
  m_hGeometryParameters["CopperRingHeight"]    = 5.*mm;

  //================================= PTFE pillars ===============================================================
 
  m_hGeometryParameters["NbofPTFEpillar"]        = 24;
  m_hGeometryParameters["deltaTheta"]            = 15.*deg;
  
  m_hGeometryParameters["BottomBoxBase_x"]       = 15.*mm;
  m_hGeometryParameters["BottomBoxBase_y"]       = 19.*mm;
  m_hGeometryParameters["BottomBox_height"]      = 160.8*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  
  m_hGeometryParameters["TopBoxBase_y"]          = 14.*mm;
  m_hGeometryParameters["TopBox_height"]         = (965.06*mm - GetGeometryParameter("CopperRingHeight")) * (1.- GetGeometryParameter("Teflon_shrink") );
  
  m_hGeometryParameters["TrapezoidBase_y1"]      = 19.*mm;
  m_hGeometryParameters["TrapezoidBase_y2"]      = 10.*mm;
  m_hGeometryParameters["Trapezoid_height"]      = 12.9*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  
  //========================= Bottom PTFE  Reflector ===========================================================
  
  m_hGeometryParameters["BottomReflectorRadius"] = 497.5*mm;
  m_hGeometryParameters["ReflectorHeight"]       = 10.*mm;  
  
  //========================= Bottom PMTs PTFE (before was Acrylic) =====================
  
  m_hGeometryParameters["BottomPTFErad"]    = 497.5*mm;
  m_hGeometryParameters["BottomPTFEHeight"] = 9.5*mm;
  
  //========================= Bottom PMTs holder plate (copper) =====================

  m_hGeometryParameters["BottomHolderPlateRad"]    = 515.*mm;
  m_hGeometryParameters["BottomHolderPlateHeight"] = 19.*mm;
  
  //=================================== Cathode ring ==================================================
  
  m_hGeometryParameters["CathodeRing_inn_Radius"]   = 480.35*mm;
  m_hGeometryParameters["CathodeRing_thikness"]     = 11.*mm;
  m_hGeometryParameters["CathodeRingHeight"]        = 13.35*mm;
  
  m_hGeometryParameters["CathodeRing_2_inn_Radius"] = 485.*mm;
  m_hGeometryParameters["CathodeRing_2_thikness"]   = 6.35*mm;
  m_hGeometryParameters["CathodeRing_2_Height"]     = 8.65*mm;
  
  //=================================== Bottom mesh ring ==================================================
  
  m_hGeometryParameters["BottomRing_inn_Radius"]  = 465.*mm;
  m_hGeometryParameters["BottomRing_out_Radius"]  = 481.75*mm;
  m_hGeometryParameters["BottomRingHeight"]       = 3.*mm;
  
  //=================================== Cathode support (PTFE)============================================
  
  m_hGeometryParameters["cathodeSupport_x"]       = 20.*mm;//44.5*mm;
  m_hGeometryParameters["cathodeSupport_y"]       = 20.*mm;
  m_hGeometryParameters["cathodeSupport_height"]  = (165.*mm - GetGeometryParameter("CopperRingHeight")) * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["cathodeSuppDeltaTheta"]  = 60.*deg;
  m_hGeometryParameters["NbofCathodeSupp"]        = 6;
  
  //=================================== Bottom filler ==================================================
  
  m_hGeometryParameters["BottomFillerThickness"] = 5.*mm;
  m_hGeometryParameters["BottomFiller_PlateRad"] = 437.*mm;		  
  m_hGeometryParameters["BottomFillerHeight"]    = 6.*mm;
  m_hGeometryParameters["BottomFillerCoverThickness"]    = 10.*mm;


  //=================================== General parameters used to place LXe veto PMTs =============================== // Cyril, 2013 Nov
 
  m_hGeometryParameters["DistanceTopPlateFromTopPmtHolder"]           = 104.8*mm;//30.*mm;
  m_hGeometryParameters["DistanceTopPmtHolderFromTopPMTCopper"]       = 0.;//85.*mm;
  m_hGeometryParameters["DistanceTopPMTCopperFromTopPTFE"]            = 33.3*mm;
  m_hGeometryParameters["DistanceTopPTFEFromTopElectrodePTFE"]        = 3.*mm;
  m_hGeometryParameters["DistanceBottomRingFromBottomReflector"]      = 5.*mm;
  m_hGeometryParameters["DistanceBottomReflectorFromBottomPTFE"]      = 34.*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["DistanceBottomPTFEFromBottomPMTHolder"]      = 20.2*mm * (1.- GetGeometryParameter("Teflon_shrink") );
  m_hGeometryParameters["DistancePmtFromPmtBase"]                     = 14.*mm;
  m_hGeometryParameters["DistanceBottomHolderPlateFromBottomFiller"]  = (227. -87.3 -38. + 0.5 + 59.2 -43.3)*mm; //cMSdec13
 

  
// m_hGeometryParameters["TpcOffsetZ"]  = GetGeometryParameter("TopPlateOffsetZ") - GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight")*0.5 - GetGeometryParameter("TopPmtHolderHeight")*0.5 - GetGeometryParameter("DistanceTopPmtHolderFromTopAcrylic") - GetGeometryParameter("TopAcrylicHeight")*0.5 - GetGeometryParameter("TopAcrylicHeight")*0.5 - GetGeometryParameter("DistanceTopAcrylicFromdTopPTFE") - GetGeometryParameter("TopPTFEHeight")*0.5- GetGeometryParameter("TopPTFEHeight")*0.5 - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight")*0.5- 0.5*GetGeometryParameter("TopElectrodePTFEHeight") - 0.5*GetGeometryParameter("TPCheight");

  // m_hGeometryParameters["CopperPlateOffsetZ"]  = GetGeometryParameter("TopPlateOffsetZ")- GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight")*0.5- GetGeometryParameter("TopPmtHolderHeight")*0.5 - GetGeometryParameter("DistanceTopPmtHolderFromTopAcrylic") - GetGeometryParameter("TopAcrylicHeight")*0.5 - GetGeometryParameter("TopAcrylicHeight")*0.5 - GetGeometryParameter("DistanceTopAcrylicFromdTopPTFE") - GetGeometryParameter("TopPTFEHeight")*0.5- GetGeometryParameter("TopPTFEHeight")*0.5 - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 - GetGeometryParameter("CopperPlateHeight")*0.5;
 
   // m_hGeometryParameters["BottomPTFEOffsetZ"]   = GetGeometryParameter("TpcOffsetZ") - GetGeometryParameter("TPCheight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("PTFEheight")*0.5; 
  
   // m_hGeometryParameters["BottomHolderPlateOffsetZ"]  = GetGeometryParameter("BottomPTFEOffsetZ") - GetGeometryParameter("BottomPTFEHeight")*0.5 - GetGeometryParameter("BottomHolderPlateHeight")*0.5;
  
  m_hGeometryParameters["BottomAcrylicOffsetZ"]     = GetGeometryParameter("BottomPTFEOffsetZ") - GetGeometryParameter("PTFEheight")*0.5 - GetGeometryParameter("DistanceBottomPTFEFromBottomAcrylic") - GetGeometryParameter("BottomPTFEHeight")*0.5;
  
  m_hGeometryParameters["TpcOffsetZ"]  = GetGeometryParameter("TopPlateOffsetZ") - 15.75*mm - GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight") - GetGeometryParameter("TopPMTCopperHeight") - GetGeometryParameter("DistanceTopPMTCopperFromTopPTFE") - GetGeometryParameter("TopPTFEHeight") - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight") - 2.5*mm - GetGeometryParameter("TPCheight")*0.5;
  
  m_hGeometryParameters["SSPlateOffsetZ"]  = GetGeometryParameter("TpcOffsetZ") + GetGeometryParameter("TPCheight")*0.5 + GetGeometryParameter("SSPlateHeight")*0.5;
  //bottom ptfe reflector offsetZ
  m_hGeometryParameters["BottomPTFEOffsetZ"]  =  GetGeometryParameter("TpcOffsetZ") - GetGeometryParameter("TPCheight")*0.5 -  GetGeometryParameter("ReflectorHeight")*0.5;
  
  m_hGeometryParameters["BottomHolderPlateOffsetZ"] = GetGeometryParameter("BottomPTFEOffsetZ") - GetGeometryParameter("ReflectorHeight")*0.5 - GetGeometryParameter("DistanceBottomReflectorFromBottomPTFE") - GetGeometryParameter("BottomPTFEHeight")  -  GetGeometryParameter("DistanceBottomPTFEFromBottomPMTHolder") - GetGeometryParameter("BottomHolderPlateHeight")*0.5;

  m_hGeometryParameters["TopBottomFillerOffsetZ"]  =  GetGeometryParameter("BottomHolderPlateOffsetZ")- GetGeometryParameter("BottomHolderPlateHeight")*0.5 - GetGeometryParameter("DistanceBottomHolderPlateFromBottomFiller") - GetGeometryParameter("BottomFillerHeight")*0.5;
   
  //==================================== LXe Veto PTFE Layer ==================================== // Cyril, 2013 Nov
  m_hGeometryParameters["TeflonOuterLayerRadius"]         = 548.5*mm;
  m_hGeometryParameters["TeflonOuterLayerThickness"]      = 1*mm;
  m_hGeometryParameters["TeflonOuterLayerHeight"]         = GetGeometryParameter("TPCheight") + GetGeometryParameter("BelowTPCringHeight"); // +12 for v5, +6 for v2 

  m_hGeometryParameters["TeflonInnerLayerThickness"]      = 1*mm;
  m_hGeometryParameters["TeflonInnerLayerAngularOffset"]  = 7.5*deg ;
  m_hGeometryParameters["TeflonInnerLayerHeight"]         = 957.*mm * (1.- GetGeometryParameter("Teflon_shrink") );
//(GetGeometryParameter("TPCheight") + GetGeometryParameter("BelowTPCringHeight"))-((GetGeometryParameter("TPCheight") + GetGeometryParameter("BelowTPCringHeight"))*GetGeometryParameter("Teflon_shrink")); // v5, -1 cm for v2

  m_hGeometryParameters["TeflonPlateAboveTPCThickness"]   = 1*mm;

  m_hGeometryParameters["LXeTopHeight"] = 50.*mm ;
  m_hGeometryParameters["LXeTopRadius"] = 520.*mm;



 //==================================== LXe Veto PMTs (R8520)  ==================================== // Cyril, 2013 Oct
  m_hGeometryParameters["LXeVetoPmtWindowThickness"]       = 1.50*mm;
  m_hGeometryParameters["LXeVetoPmtCasingWidth"]           = 25.40*mm;
  m_hGeometryParameters["LXeVetoPmtCasingHeight"]          = 27.00*mm;
  m_hGeometryParameters["LXeVetoPmtBaseThickness"]         = 1.50*mm;
  m_hGeometryParameters["LXeVetoPmtToPmtBase"]             = 3.00*mm;
  m_hGeometryParameters["LXeVetoPmtWidth"]                 = 25.4*mm;
  m_hGeometryParameters["LXeVetoPmtSpacing"]               = 2.03*mm;
  m_hGeometryParameters["LXeVetoPmtWindowWidth"]           = 25.00*mm;
  m_hGeometryParameters["LXeVetoPmtCasingThickness"]       = 0.50*mm;
  m_hGeometryParameters["LXeVetoPmtPhotoCathodeWidth"]     = 22.00*mm;
  m_hGeometryParameters["LXeVetoPmtPhotoCathodeThickness"] = 0.50*mm;
  m_hGeometryParameters["LXeVetoPmtBaseSpacerHeight"]      = 6.00*mm;
  
  
  // version 3 of LXe veto, using Andreas drawing, Cyril, 2013/11/05
  m_hGeometryParameters["NbBottomLXeVetoPMTs"]				= 48;  
  m_hGeometryParameters["NbTopLXeVetoPMTs"]				= 48;  
  m_hGeometryParameters["NbBelowLXeVetoPMTs"]				= 32;  
  m_hGeometryParameters["NbAboveLXeVetoPMTs"]				= 32;  
  m_hGeometryParameters["NbCenterLXeVetoPMTs"]				= 0;  
  m_hGeometryParameters["NbLXeVetoPMTs"]				= GetGeometryParameter("NbBottomLXeVetoPMTs")+GetGeometryParameter("NbTopLXeVetoPMTs")+GetGeometryParameter("NbBelowLXeVetoPMTs")+GetGeometryParameter("NbAboveLXeVetoPMTs")+GetGeometryParameter("NbCenterLXeVetoPMTs");  

  m_hGeometryParameters["LXeVetoNumberPMTsBunchTop"]       = 2;  // 24*2 = 48 PMTs on top and bottom

  m_hGeometryParameters["LXeVetoAbovePmtRadius"]           = 455.0*mm+0.5*(GetGeometryParameter("LXeVetoPmtWindowThickness")+GetGeometryParameter("LXeVetoPmtCasingHeight"));
  m_hGeometryParameters["LXeVetoTopPmtRadius"]             = 510.0*mm;
  m_hGeometryParameters["LXeVetoBottomPmtRadius"]          = 510.0*mm;
  m_hGeometryParameters["LXeVetoBelowPmtRadius"]           = (426.0-6.0)*mm+0.5*(GetGeometryParameter("LXeVetoPmtWindowThickness")+GetGeometryParameter("LXeVetoPmtCasingHeight"));

  m_hGeometryParameters["LXeVetoAngularOffsetBunch"]       = 7.5*deg; // with 2 PMTs in bottom and top
  m_hGeometryParameters["LXeVetoAngularStepPMTs"]          = 3.75*deg; // with 2 PMTs in bottom and top

  m_hGeometryParameters["LXeVetoAboveAngularStep"]         = 11.25*deg;
  m_hGeometryParameters["LXeVetoBelowAngularStepPMTs"]         = 11.25*deg;
  
  m_hGeometryParameters["LXeVetoAbovePmtZOffset"]          = -0.5*GetGeometryParameter("LXeTopHeight") + 0.5*GetGeometryParameter("LXeVetoPmtWidth") + 4.3*mm; // in LXeTop

  m_hGeometryParameters["LXeVetoTopPmtZOffset"]         = GetGeometryParameter("SSPlateOffsetZ") - GetGeometryParameter("SSPlateHeight")*0.5 - GetGeometryParameter("SSRingHeight_LXe") - 0.5*GetGeometryParameter("LXeVetoPmtWindowThickness") - 0.5*GetGeometryParameter("LXeVetoPmtCasingHeight") -17.*mm;

  m_hGeometryParameters["LXeVetoCenterPmtZOffset"]      = -61.25*mm;

  m_hGeometryParameters["LXeVetoBottomPmtZOffset"]       = GetGeometryParameter("TpcOffsetZ") - GetGeometryParameter("TPCheight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("ReflectorHeight") - GetGeometryParameter("DistanceBottomReflectorFromBottomPTFE") - GetGeometryParameter("BottomPTFEHeight") - GetGeometryParameter("DistanceBottomPTFEFromBottomPMTHolder") + GetGeometryParameter("CopperRingHeight") + 0.5*GetGeometryParameter("LXeVetoPmtWindowThickness") + 0.5*GetGeometryParameter("LXeVetoPmtCasingHeight") + 5.*mm;
  
  m_hGeometryParameters["LXeVetoThicknessBottomVeto"] = 50.*mm; //cMSdec13

  // m_hGeometryParameters["LXeVetoBelowPmtZOffset"]      = GetGeometryParameter("BottomPTFEOffsetZ") - 136.75*mm -0.5*GetGeometryParameter("LXeVetoPmtWidth")-20*mm; // to get away from the base of TPC PMTs //cMSdec13
  //notUsed  m_hGeometryParameters["LXeVetoDistanceBottomPtfeFromBase"] = 20.*mm; //cMSdec13
  
  
  // LXeVetoBelowPmtZOffset new version
  
  m_hGeometryParameters["BottomCopperPlateOffsetZ"] = GetGeometryParameter("TopPlateOffsetZ") - 15.75*mm - GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight") - GetGeometryParameter("DistanceTopPmtHolderFromTopPMTCopper") - GetGeometryParameter("TopPMTCopperHeight") - GetGeometryParameter("DistanceTopPMTCopperFromTopPTFE") - GetGeometryParameter("TopPTFEHeight") - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight") - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5 - GetGeometryParameter("TPCheight") - GetGeometryParameter("BelowTPCringHeight") - GetGeometryParameter("ReflectorHeight") - GetGeometryParameter("DistanceBottomReflectorFromBottomPTFE")  - GetGeometryParameter("BottomPTFEHeight") - GetGeometryParameter("DistanceBottomPTFEFromBottomPMTHolder") - GetGeometryParameter("BottomHolderPlateHeight")*0.5;
    
  m_hGeometryParameters["LXeVetoBelowPmtZOffset"] = GetGeometryParameter("BottomCopperPlateOffsetZ") - GetGeometryParameter("BottomHolderPlateHeight")*0.5 - 161.*mm + GetGeometryParameter("LXeVetoThicknessBottomVeto")*0.5;
    
}

G4double
Xenon1tDetectorConstruction::GetGeometryParameter(const char *szParameter)
{
  return m_hGeometryParameters[szParameter];
}

void
Xenon1tDetectorConstruction::ConstructLaboratory()
{
  //================================== Laboratory =================================
  const G4double dLabHalfZ = 0.5*GetGeometryParameter("LabHeight");
  const G4double dLabRadius = GetGeometryParameter("LabRadius");
  
  G4Material *Air = G4Material::GetMaterial("G4_AIR");
  
  G4Tubs *pLabTubs = new G4Tubs("LabTubs", 0.*cm, dLabRadius, dLabHalfZ, 0.*deg, 360.*deg);
  
  m_pLabLogicalVolume = new G4LogicalVolume(pLabTubs, Air, "LabVolume", 0, 0, 0);
  
  m_pLabPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(), m_pLabLogicalVolume, "Lab", 0, false, 0);
  
  m_pMotherLogicalVolume = m_pLabLogicalVolume;
  
  m_pLabLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
}

void
Xenon1tDetectorConstruction::ConstructVeto()
{
  //================================== Water tank =================================
  const G4double dWaterTankCylinderHalfZ = 0.5*GetGeometryParameter("WaterTankCylinderHeight");
  const G4double dWaterTankRadius = GetGeometryParameter("WaterTankOuterRadius");
  
  const G4double dTankConsR1 = GetGeometryParameter("TankConsR1");
  const G4double dTankConsR2 = GetGeometryParameter("TankConsR2");
  const G4double dTankConsZ = 0.5*GetGeometryParameter("TankConsHeight");

  const G4double dWaterTankOffsetZ = -1.* GetGeometryParameter("OuterCryostatOffsetZ");
  const G4double dWaterConeOffsetZ = dWaterTankOffsetZ + dWaterTankCylinderHalfZ + 0.5*GetGeometryParameter("TankConsHeight");
  
  
  G4Material *SS304LSteel = G4Material::GetMaterial("SS304LSteel");
  
  G4Tubs *pWaterTankTubs = new G4Tubs("WaterTankTubs", 0.*cm, dWaterTankRadius, dWaterTankCylinderHalfZ, 0.*deg, 360.*deg);
  
  G4Cons *pTankCons = new G4Cons("TankCons", 0., dTankConsR1, 0., dTankConsR2, dTankConsZ, 0.*deg, 360.*deg);
  
  
  //****************************************************SERENA****************************************************
      // Piazzamento logico e fisico del cilindro della tank
      m_pWaterTankTubLogicalVolume = new G4LogicalVolume(pWaterTankTubs, SS304LSteel, "WaterTankTubeVolume", 0, 0, 0);
  
  m_pWaterTankTubePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dWaterTankOffsetZ),
                                                     m_pWaterTankTubLogicalVolume, "WaterTankTube", m_pMotherLogicalVolume, false, 0);
  
  
  // Piazzamento logico e fisico del cono della tank
  m_pTankConsLogicalVolume = new G4LogicalVolume(pTankCons, SS304LSteel, "TankConsLogical", 0, 0, 0);
  
  m_pTankConsPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dWaterConeOffsetZ),
                                                m_pTankConsLogicalVolume, "TankConsPhysical", m_pMotherLogicalVolume, false, 0);
  
  //***************************************************************************************************************
  
  
      //================================== Water =================================
      const G4double dWaterCylinderHalfZ = 0.5*GetGeometryParameter("WaterTankCylinderInnerHeight");
  const G4double dWaterRadius = GetGeometryParameter("WaterTankInnerRadius");
  const G4double dWaterOffsetZ = 0.5* GetGeometryParameter("WaterTankThickness");
	
	
  const G4double dWaterConsR1 = GetGeometryParameter("WaterConsR1");
  const G4double dWaterConsR2 = GetGeometryParameter("WaterConsR2");
  const G4double dWaterConsZ = 0.5*GetGeometryParameter("WaterConsHeight");
	
  const G4double dAirConsR1 = GetGeometryParameter("AirConsR1");
  const G4double dAirConsR2 = GetGeometryParameter("AirConsR2");
  const G4double dAirConsZ = 0.5*GetGeometryParameter("AirConsHeight");
  
	
  const G4double dAirConeOffsetZ = 0.5*GetGeometryParameter("AirConsOffset");
  
  
  
  G4Material *Water = G4Material::GetMaterial("Water");
  G4Material *Air = G4Material::GetMaterial("G4_AIR");	// SERENA
  //G4Material *LScint = G4Material::GetMaterial("LScint");
  //G4Material *Gd_LScint = G4Material::GetMaterial("Gd_LScint");
  //G4Material *B_LScint = G4Material::GetMaterial("B_LScint");

  G4Material *muonvetoMaterial;
  // check input material, is it a valid one ?
  if (pMuonVetoMaterial) {
    if (pMuonVetoMaterial=="Water" || pMuonVetoMaterial=="LScint" || pMuonVetoMaterial=="Gd_LScint" || pMuonVetoMaterial=="B_LScint" || pMuonVetoMaterial=="G4_AIR") {
      muonvetoMaterial = G4Material::GetMaterial(pMuonVetoMaterial);
    }
    else{
      G4Exception("XenonDetectorConstruction::ConstructVeto()","DetectorConstruction",FatalException,"Not allowed Material for the Muon Veto, good ones are: Water, LScint, Gd_LScint, B_LScint, G4_AIR");
    }
  }

    
  G4Tubs *pWaterTubs = new G4Tubs("WaterTubs", 0.*cm, dWaterRadius, dWaterCylinderHalfZ, 0.*deg, 360.*deg);
  
  G4Cons *pWaterCons = new G4Cons("WaterCons", 0., dWaterConsR1, 0., dWaterConsR2, dWaterConsZ, 0.*deg, 360.*deg);
  G4Cons *pAirCons = new G4Cons("AirCons", 0., dAirConsR1, 0., dAirConsR2, dAirConsZ, 0.*deg, 360.*deg);
  
  
  //****************************************************SERENA****************************************************
      // Piazzamento logico e fisico del cilindro di acqua
      m_pWaterLogicalVolume = new G4LogicalVolume(pWaterTubs, muonvetoMaterial, "WaterVolume", 0, 0, 0);
  //  	m_pWaterLogicalVolume = new G4LogicalVolume(pWaterTubs, Water, "WaterVolume", 0, 0, 0);
    
  m_pWaterPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dWaterOffsetZ), 
                                             m_pWaterLogicalVolume, "Water", m_pWaterTankTubLogicalVolume, false, 0);
  
  
  // Piazzamento logico e fisico del cono grande di acqua e poi piccolo di aria (azoto)
  m_pWaterConsLogicalVolume = new G4LogicalVolume(pWaterCons, Water, "WaterConsLogical", 0, 0, 0);
  m_pWaterConsPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, -dWaterOffsetZ),				
                                                 m_pWaterConsLogicalVolume, "WaterConsPhysical", m_pTankConsLogicalVolume, false, 0);		// SERENA*
  
  m_pAirConsLogicalVolume = new G4LogicalVolume(pAirCons, Air, "AirConsLogical", 0, 0, 0);
  m_pAirConsPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dAirConeOffsetZ),				
                                               m_pAirConsLogicalVolume, "AirConsPhysical", m_pWaterConsLogicalVolume, false, 0);		// SERENA*
  
  //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  
  // --------------------------------- Optical surface --------------------------------------------
  G4OpticalSurface* OpWaterSurface = new G4OpticalSurface("WaterSurface");
  OpWaterSurface->SetType(dielectric_metal); //(dielectric_LUT)
  OpWaterSurface->SetModel(unified);  //(LUT);	
  OpWaterSurface->SetFinish(polished); //(polishedvm2000air);  // Specular Reflector
	
  //	OpWaterSurface->SetFinish(ground);  // Diffusive reflector
  //	G4double polish = 0.0;				// Diffusive reflector
  //	OpWaterSurface->SetPolish(polish);	// Diffusive reflector
	
  // Serena //////////////////////////////////////////////////////////
  const G4int NUM = 2; 
  G4double pp[NUM] = {1.*eV, 5.*eV}; 
  G4double reflectivity_W[NUM] = {0.95, 0.95}; 
  
  G4MaterialPropertiesTable* SMPT_W = new G4MaterialPropertiesTable(); 
  
  SMPT_W->AddProperty("REFLECTIVITY",pp,reflectivity_W,NUM); 
  
  OpWaterSurface -> SetMaterialPropertiesTable(SMPT_W); 
  ///////////////////////////////////////////////////////////////////
	
    G4LogicalBorderSurface* OuterWaterSurface = 
      new G4LogicalBorderSurface("OuterWaterSurface",
				 m_pWaterPhysicalVolume,m_pWaterTankTubePhysicalVolume,OpWaterSurface);  // SERENA REPLACEMENT
	
    if(OuterWaterSurface->GetVolume1() == m_pWaterPhysicalVolume) G4cout << "Outer Vol 1 equal to Water" << G4endl;
    if(OuterWaterSurface->GetVolume2() == m_pWaterTankTubePhysicalVolume  ) G4cout << "Outer Vol 2 equal to Tank" << G4endl;  // SERENA REPLACEMENT
	
	
    ////////////////////////////////////////// SERENA //////////////////////////////////////////
    // ==> Rimettiamo la riflettivita' sul soffitto mantenendo la "Water/Gas interface"
    // ----------------------------------- Optical surface -----------------------------------
    G4OpticalSurface* OpWater2Surface = new G4OpticalSurface("Water2Surface");
    OpWater2Surface->SetType(dielectric_metal); //(dielectric_LUT)
    OpWater2Surface->SetModel(unified);  //(LUT);	
    OpWater2Surface->SetFinish(polished); //(polishedvm2000air);
	
    G4double reflectivity_W2[NUM] = {0.90, 0.90}; 
    G4MaterialPropertiesTable* SMPT_W2 = new G4MaterialPropertiesTable(); 
    SMPT_W2->AddProperty("REFLECTIVITY",pp,reflectivity_W2,NUM); 
    OpWater2Surface->SetMaterialPropertiesTable(SMPT_W2); 
  
	
    G4LogicalBorderSurface* OuterWater2Surface = 
      new G4LogicalBorderSurface("OuterWater2Surface",m_pWaterConsPhysicalVolume, m_pTankConsPhysicalVolume,OpWater2Surface);  // SERENA REPLACEMENT
	
    if(OuterWater2Surface->GetVolume1() == m_pWaterConsPhysicalVolume) G4cout << "Outer Vol 1 equal to Water Cons" << G4endl;
    if(OuterWater2Surface->GetVolume2() == m_pTankConsPhysicalVolume  ) G4cout << "Outer Vol 2 equal to Tank Cons" << G4endl;  // SERENA REPLACEMENT
	
    G4OpticalSurface* OpAirSurface = new G4OpticalSurface("AirSurface");
    OpAirSurface->SetType(dielectric_metal); //(dielectric_LUT)
    OpAirSurface->SetModel(unified);  //(LUT);	
    OpAirSurface->SetFinish(polished); //(polishedvm2000air);
	
    G4double reflectivity_A[NUM] = {0.90, 0.90}; 
    G4MaterialPropertiesTable* SMPT_A = new G4MaterialPropertiesTable(); 
    SMPT_A->AddProperty("REFLECTIVITY",pp,reflectivity_A,NUM); 
    OpAirSurface->SetMaterialPropertiesTable(SMPT_A); 
  
	
    G4LogicalBorderSurface* OuterAirSurface = 
      new G4LogicalBorderSurface("OuterAirSurface",m_pAirConsPhysicalVolume, m_pTankConsPhysicalVolume,OpAirSurface);  // SERENA REPLACEMENT
	
    if(OuterAirSurface->GetVolume1() == m_pAirConsPhysicalVolume) G4cout << "Outer Vol 1 equal to Air Cons" << G4endl;
    if(OuterAirSurface->GetVolume2() == m_pTankConsPhysicalVolume  ) G4cout << "Outer Vol 2 equal to Tank Celling" << G4endl;  // SERENA REPLACEMENT
	
	
  
    m_pMotherLogicalVolume = m_pWaterLogicalVolume;// m_pLSLogicalVolume;
  
    //================================== attributes =================================
    G4Colour hWaterTankColor(0.500, 0.500, 0.500, 0.1);
    //G4Colour hWaterTankColor(1.0, 0.0, 0.0);
    G4VisAttributes *pWaterTankVisAtt = new G4VisAttributes(hWaterTankColor);
    pWaterTankVisAtt->SetVisibility(false);
    m_pWaterTankTubLogicalVolume->SetVisAttributes(pWaterTankVisAtt); // SERENA REPLACEMENTs
    m_pTankConsLogicalVolume->SetVisAttributes(pWaterTankVisAtt); // SERENA REPLACEMENTs
  
    G4Colour hWaterColor(0, 0, 1.);
    G4VisAttributes *pWaterVisAtt = new G4VisAttributes(hWaterColor);
    pWaterVisAtt->SetVisibility(false);
    m_pWaterLogicalVolume->SetVisAttributes(pWaterVisAtt);
    m_pWaterConsLogicalVolume->SetVisAttributes(pWaterVisAtt);
	
    // SERENA******************************************************
    G4Colour hAirColor(0, 1., 1.);
    G4VisAttributes *pAirVisAtt = new G4VisAttributes(hAirColor);
    pAirVisAtt->SetVisibility(false);
    m_pAirConsLogicalVolume->SetVisAttributes(pAirVisAtt);
    // ************************************************************
	
  
    G4Colour hLSVesselColor(0.500, 0.500, 0.500, 0.1);
    G4VisAttributes *pLSVesselVisAtt = new G4VisAttributes(hLSVesselColor);
    pLSVesselVisAtt->SetVisibility(false);
    //ms	m_pLSVesselLogicalVolume->SetVisAttributes(pLSVesselVisAtt);
  
    G4Colour hLSColor(0, 0, 0.75);
    G4VisAttributes *pLSVisAtt = new G4VisAttributes(hLSColor);
    pLSVisAtt->SetVisibility(false);
    //ms	m_pLSLogicalVolume->SetVisAttributes(pLSVisAtt);
}



//function used to construct a beam
G4UnionSolid *Xenon1tDetectorConstruction::ConstructBeam(G4double x_outer, G4double y_outer, G4double z_outer, G4double x_inner, G4double y_inner, G4double z_inner)
{
  //Andrea Tiseni 21-12-2012

  G4Box *outer_box = new G4Box ("outer_box", x_outer, y_outer, z_outer);
  G4Box *inner_box = new G4Box ("inner_box", x_inner, y_inner, z_inner);
  G4SubtractionSolid *leg = new G4SubtractionSolid("leg1", outer_box, inner_box);
  G4UnionSolid *real_leg;
  real_leg = (G4UnionSolid*) leg;
  return real_leg;
}

void Xenon1tDetectorConstruction::ConstructNewSupportStructure()
{
// Andrea Tiseni 21-12-2012

//material used to construct the beams
G4Material *SS304LSteel = G4Material::GetMaterial("SS304LSteel");
G4Material *Air = G4Material::GetMaterial("G4_AIR");
    
     G4double cryo_offset = m_hGeometryParameters["OuterCryostatOffsetZ"];

m_pMotherLogicalVolume = m_pWaterLogicalVolume;

//some constants 
G4double dWaterCylinderZ = GetGeometryParameter("WaterTankCylinderInnerHeight");
G4double dWaterConsZed = GetGeometryParameter("WaterConsHeight");


G4double x_outer         = GetGeometryParameter("x_outer");
G4double y_outer         = GetGeometryParameter("y_outer");
G4double z_outer         = GetGeometryParameter("z_outer");
G4double x_inner         = GetGeometryParameter("x_inner");
G4double y_inner         = GetGeometryParameter("y_inner");
G4double z_inner         = GetGeometryParameter("z_inner");
G4double z_medium_outer         = GetGeometryParameter("z_medium_outer");
G4double z_medium_inner         = GetGeometryParameter("z_medium_inner");
G4double x_pos_floor_leg1           = GetGeometryParameter("x_pos_floor_leg1");
G4double y_pos_floor_leg1           = GetGeometryParameter("y_pos_floor_leg1");
G4double z_pos_floor_leg1           = GetGeometryParameter("z_pos_floor_leg1");
G4double x_pos_floor_leg2           = GetGeometryParameter("x_pos_floor_leg2");
G4double y_pos_floor_leg2           = GetGeometryParameter("y_pos_floor_leg2");
G4double z_pos_floor_leg2           = GetGeometryParameter("z_pos_floor_leg2");
G4double x_pos_floor_leg3           = GetGeometryParameter("x_pos_floor_leg3");
G4double y_pos_floor_leg3           = GetGeometryParameter("y_pos_floor_leg3");
G4double z_pos_floor_leg3           = GetGeometryParameter("z_pos_floor_leg3");
G4double x_pos_floor_leg4           = GetGeometryParameter("x_pos_floor_leg4");
G4double y_pos_floor_leg4           = GetGeometryParameter("y_pos_floor_leg4");
G4double z_pos_floor_leg4           = GetGeometryParameter("z_pos_floor_leg4");
G4double z_horizontal_outer         = GetGeometryParameter("z_horizontal_outer");
G4double z_horizontal_inner         = GetGeometryParameter("z_horizontal_inner");
G4double z_tilt_beam                = GetGeometryParameter("z_tilt_leg");
 

G4double z_platform                 = GetGeometryParameter("z_platform");
G4double x_platform                 = GetGeometryParameter("x_platform");
G4double x_platform1                = GetGeometryParameter("x_platform1");
    G4double pi_g = 3.141592653589793;

    
    G4double x_spreader                = GetGeometryParameter("x_spreader");
    G4double y_spreader                = GetGeometryParameter("y_spreader");
    G4double z_spreader                = GetGeometryParameter("z_spreader");
    G4double x_inner_spreader                = GetGeometryParameter("x_inner_spreader");
    G4double y_inner_spreader                = GetGeometryParameter("y_inner_spreader");
    G4double z_pos_spreader                = GetGeometryParameter("z_pos_spreader")-cryo_offset;
    
    
//angles for the tilted beams
G4double tilt_angle = 28.*deg;
G4double costilt = cos(tilt_angle);
G4double sintilt = sin(tilt_angle);
G4double rotation_angle =45.*deg;
G4double cosrot = cos(rotation_angle);
G4double sinrot = sin(rotation_angle);

//zed measure of the tilt leg in the cylinder
G4double z_tilt_low_beam = (dWaterCylinderZ-z_outer*2.-z_medium_outer*2.-x_outer-2*x_outer*sintilt)/(2.*costilt);

//zed measure of the tilt leg in the cons
G4double z_tilt_cons_beam = z_tilt_beam - z_tilt_low_beam-(x_outer/costilt)*sintilt;

z_tilt_beam = z_tilt_low_beam;

//zed measure of the connection between vertical beam and the tilted beams
G4double z_connection =x_outer/2.;

//construction of the legs
G4UnionSolid *pLegFloor1Volume = ConstructBeam(x_outer, y_outer, z_outer, x_inner, y_inner, z_inner);
G4UnionSolid *pLegMediumVolume = ConstructBeam(x_outer, y_outer, z_medium_outer, x_inner, y_inner, z_medium_inner);
G4UnionSolid *pLegHorizontalVolume = ConstructBeam(x_outer, y_outer, z_horizontal_outer, x_inner, y_inner, z_horizontal_inner);
G4UnionSolid *pLegTiltedVolume = ConstructBeam(x_outer, y_outer, z_tilt_beam, x_inner, y_inner, z_tilt_beam);
G4UnionSolid *pLegTiltedConsVolume = ConstructBeam(x_outer, y_outer, z_tilt_cons_beam, x_inner, y_inner, z_tilt_cons_beam);
G4UnionSolid *pLegTiltedCons1Volume = ConstructBeam(x_outer, y_outer, z_tilt_cons_beam, x_inner, y_inner, z_tilt_cons_beam);

G4UnionSolid *pLegConnection = ConstructBeam(x_outer, y_outer, z_connection, x_inner, y_inner, z_connection);
G4UnionSolid *pLegPlatformVolume = ConstructBeam(x_outer, y_outer, z_platform, x_inner, y_inner, z_platform);
    G4UnionSolid *pLegSpreader = ConstructBeam(x_spreader, y_spreader, z_spreader, x_inner_spreader, y_inner_spreader, z_spreader);

G4double x_center_tilt_beam = -z_tilt_beam*sintilt*cosrot;
G4double y_center_tilt_beam = -z_tilt_beam*sintilt*sinrot;

G4double x_air =GetGeometryParameter("x_inner");
G4double y_air = GetGeometryParameter("y_inner");

G4Box *air_beam_floor= new G4Box ("box_1",x_air,y_air,z_outer);
G4Box *air_beam_medium= new G4Box ("box_2",x_air,y_air,z_medium_outer);
G4Box *air_beam_connection= new G4Box ("box_3",x_air,y_air,z_connection);
G4Box *air_beam_horizontal= new G4Box ("box_4",x_air,y_air,z_horizontal_outer);
G4Box *air_beam_tilted= new G4Box ("box_5",x_air,y_air,z_tilt_beam);
G4Box *air_beam_tilted_cons= new G4Box ("box_6",x_air,y_air,z_tilt_cons_beam);
G4Box *air_beam_platform= new G4Box ("box_7",x_air,y_air,z_platform);

    G4Box *air_beam_spreader= new G4Box ("box_7",x_inner_spreader,y_inner_spreader,z_spreader);
    
    
    
    G4double z_triangle = 112.5*mm;
    
    
    G4int nCVtx = 8;
    std::vector<G4TwoVector> cvtx(nCVtx);
    cvtx[0] = G4TwoVector( -130,  -5);
    cvtx[1] = G4TwoVector( -130, 5);
    cvtx[2] = G4TwoVector( 130, 5);
    cvtx[3] = G4TwoVector( 130, -5);
    cvtx[4] = G4TwoVector(-5, -5);
    cvtx[5] = G4TwoVector(-5, 5);
    cvtx[6] = G4TwoVector(5, 5);
    cvtx[7] = G4TwoVector(5,-5);
    
    G4GenericTrap *pand = new G4GenericTrap("lsl", z_triangle, cvtx);



//rotation matrix
G4RotationMatrix *Rot = new G4RotationMatrix;
Rot->rotateZ(90.*deg);
Rot->rotateX(90.*deg);
Rot->rotateY(90.*deg);
G4RotationMatrix *Rot1 = new G4RotationMatrix;
Rot1->rotateX(90.*deg);
Rot1->rotateY(90.*deg);
G4RotationMatrix *Rot2 = new G4RotationMatrix;
Rot2->rotateZ(-rotation_angle);
Rot2->rotateY(tilt_angle);
G4RotationMatrix *Rot3 = new G4RotationMatrix;
Rot3->rotateZ(rotation_angle);
Rot3->rotateY(tilt_angle);
G4RotationMatrix *Rot4 = new G4RotationMatrix;
Rot4->rotateZ(rotation_angle);
Rot4->rotateY(360.*deg-tilt_angle);
G4RotationMatrix *Rot5 = new G4RotationMatrix;
Rot5->rotateZ(-rotation_angle);
Rot5->rotateY(360.*deg-tilt_angle);


G4RotationMatrix *Rot6 = new G4RotationMatrix;
Rot6->rotateZ(-rotation_angle);
Rot6->rotateY(tilt_angle);

//placement of the floor leg and connection between vertical and tilted beams

m_pLegFloor1LogicalVolume = new G4LogicalVolume(pLegFloor1Volume, SS304LSteel, "leg1Logical");
m_pLegFloor1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1), m_pLegFloor1LogicalVolume, "support_leg1floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnection1LogicalVolume = new G4LogicalVolume(pLegConnection, SS304LSteel, "leg1_connection_Logical");
m_pLegConnection1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnection1LogicalVolume, "support_legconnection1_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnection2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnection1LogicalVolume, "support_legconnection2_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnection3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnection1LogicalVolume, "support_legconncection3_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnection4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnection1LogicalVolume, "support_legconnection4_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloor2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg2), m_pLegFloor1LogicalVolume, "support_leg2floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloor3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg3), m_pLegFloor1LogicalVolume, "support_leg3floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloor4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg4), m_pLegFloor1LogicalVolume, "support_leg4floor_physical", m_pMotherLogicalVolume,false,0);

//Placement of Air leg floor

m_pLegFloorAir1LogicalVolume = new G4LogicalVolume(air_beam_floor,Air,"air_leg1logical");
m_pLegFloorAir1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1), m_pLegFloorAir1LogicalVolume, "Air_support_leg1floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloorAir2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg2), m_pLegFloorAir1LogicalVolume, "Air_support_leg2floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloorAir3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg3), m_pLegFloorAir1LogicalVolume, "Air_support_leg3floor_physical", m_pMotherLogicalVolume,false,0);
m_pLegFloorAir4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg4), m_pLegFloorAir1LogicalVolume, "Air_support_leg4floor_physical", m_pMotherLogicalVolume,false,0);

//Placement of Air leg connection
m_pLegConnectionAir1LogicalVolume = new G4LogicalVolume(air_beam_connection, Air, "air_leg1_connection_Logical");
m_pLegConnectionAir1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnectionAir1LogicalVolume, "Air_support_legconnection1_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnectionAir2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnectionAir1LogicalVolume, "Air_support_legconnection2_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnectionAir3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnectionAir1LogicalVolume, "Air_support_legconncection3_physical", m_pMotherLogicalVolume,false,0);
m_pLegConnectionAir4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_connection), m_pLegConnectionAir1LogicalVolume, "Air_support_legconnection4_physical", m_pMotherLogicalVolume,false,0);

//placement of tilted legs

G4double x_pos_tilt_beam = x_pos_floor_leg1-z_tilt_beam*sintilt*cosrot;
G4double y_pos_tilt_beam = y_pos_floor_leg1-z_tilt_beam*sintilt*sinrot;
G4double z_pos_tilt_beam = z_pos_floor_leg1+z_outer+z_medium_outer*2.+z_tilt_beam*costilt+x_outer+x_outer*sintilt;

m_pLegTiltedLogicalVolume = new G4LogicalVolume(pLegTiltedVolume, SS304LSteel, "leg1Logical");
m_pLegTilted1PhysicalVolume = new G4PVPlacement(Rot6, G4ThreeVector(x_pos_tilt_beam,y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedLogicalVolume, "support_leg1_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTilted2PhysicalVolume = new G4PVPlacement(Rot4, G4ThreeVector(-x_pos_tilt_beam,y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedLogicalVolume, "support_leg2_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTilted3PhysicalVolume = new G4PVPlacement(Rot3, G4ThreeVector(x_pos_tilt_beam,-y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedLogicalVolume, "support_leg3_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTilted4PhysicalVolume = new G4PVPlacement(Rot5, G4ThreeVector(-x_pos_tilt_beam,-y_pos_tilt_beam,z_pos_tilt_beam), m_pLegTiltedLogicalVolume, "support_leg4_tilted_physical", m_pMotherLogicalVolume,false,0);

//Placement of Tilted Legs Air
m_pLegTiltedAirLogicalVolume = new G4LogicalVolume(air_beam_tilted, Air, "air_leg1Logical");
m_pLegTiltedAir1PhysicalVolume = new G4PVPlacement(Rot6, G4ThreeVector(x_pos_tilt_beam,y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedAirLogicalVolume, "Air_support_leg1_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTiltedAir2PhysicalVolume = new G4PVPlacement(Rot4, G4ThreeVector(-x_pos_tilt_beam,y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedAirLogicalVolume, "Air_support_leg2_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTiltedAir3PhysicalVolume = new G4PVPlacement(Rot3, G4ThreeVector(x_pos_tilt_beam,-y_pos_tilt_beam, z_pos_tilt_beam), m_pLegTiltedAirLogicalVolume, "Air_support_leg3_tilted_physical", m_pMotherLogicalVolume,false,0);
m_pLegTiltedAir4PhysicalVolume = new G4PVPlacement(Rot5, G4ThreeVector(-x_pos_tilt_beam,-y_pos_tilt_beam,z_pos_tilt_beam), m_pLegTiltedAirLogicalVolume, "Air_support_leg4_tilted_physical", m_pMotherLogicalVolume,false,0);

//Placement of Medium Vertical Volume

m_pLegMedium1LogicalVolume = new G4LogicalVolume(pLegMediumVolume, SS304LSteel, "legMedium1Logical");
m_pLegMedium1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMedium1LogicalVolume, "support_leg1_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMedium2LogicalVolume = new G4LogicalVolume(pLegMediumVolume, SS304LSteel, "legMedium2Logical");
m_pLegMedium2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMedium2LogicalVolume, "support_leg2_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMedium3LogicalVolume = new G4LogicalVolume(pLegMediumVolume, SS304LSteel, "legmedium3Logical");
m_pLegMedium3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMedium3LogicalVolume, "support_leg3_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMedium4LogicalVolume = new G4LogicalVolume(pLegMediumVolume, SS304LSteel, "legMedium4Logical");
m_pLegMedium4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMedium4LogicalVolume, "support_leg4_medium_physical", m_pMotherLogicalVolume,false,0);

//medium volume air
m_pLegMediumAir1LogicalVolume = new G4LogicalVolume(air_beam_medium, Air, "Air_legMedium1Logical");
m_pLegMediumAir1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMediumAir1LogicalVolume, "Air_support_leg1_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMediumAir2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg2, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMediumAir1LogicalVolume, "Air_support_leg2_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMediumAir3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMediumAir1LogicalVolume, "Air_support_leg3_medium_physical", m_pMotherLogicalVolume,false,0);
m_pLegMediumAir4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_pos_floor_leg4, y_pos_floor_leg4, z_pos_floor_leg1+z_outer+z_medium_outer), m_pLegMediumAir1LogicalVolume, "Air_support_leg4_medium_physical", m_pMotherLogicalVolume,false,0);

//Placement of horizontal volume

m_pLegHorizontal1LogicalVolume = new G4LogicalVolume(pLegHorizontalVolume, SS304LSteel, "leg1horizontalLogical");
m_pLegHorizontal1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "support_leg1_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal2PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg2-x_outer-z_horizontal_outer, y_pos_floor_leg2, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "support_leg2_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal3PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "support_leg3_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal4PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg1-x_outer-z_horizontal_outer, y_pos_floor_leg1, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "support_leg4_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal5PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontal1LogicalVolume, "support_leg5_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal6PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg2-x_outer-z_horizontal_outer, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontal1LogicalVolume, "support_leg6_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal7PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontal1LogicalVolume, "support_leg7_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontal8PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg1-x_outer-z_horizontal_outer, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontal1LogicalVolume, "support_leg8_horizontal_physical", m_pMotherLogicalVolume,false,0);

//Air horizontal


m_pLegHorizontalAir1LogicalVolume = new G4LogicalVolume(air_beam_horizontal, Air, "air_leg1horizontalLogical");

m_pLegHorizontalAir1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg1_horizontal_physical", m_pMotherLogicalVolume,false,0);


m_pLegHorizontalAir2PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg2-x_outer-z_horizontal_outer, y_pos_floor_leg2, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg2_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir3PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg3_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir4PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg1-x_outer-z_horizontal_outer, y_pos_floor_leg1, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg4_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir5PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg5_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir6PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg2-x_outer-z_horizontal_outer, y_pos_floor_leg2, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg6_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir7PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg3, y_pos_floor_leg3-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg7_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalAir8PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(x_pos_floor_leg1-x_outer-z_horizontal_outer, y_pos_floor_leg1, z_pos_floor_leg1+z_outer+z_medium_outer*2.), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg8_horizontal_physical", m_pMotherLogicalVolume,false,0);

//Placement of floor 1 beam

m_pLegPlatformLogicalVolume = new G4LogicalVolume(pLegPlatformVolume, SS304LSteel, "leg1platformLogical");
m_pLegPlatformAirLogicalVolume = new G4LogicalVolume(air_beam_platform, Air, "leg1platformLogical");

m_pLegHorizontalPlatformPhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1-x_platform, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "plat_support_platform_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalPlatformAirPhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1-x_platform, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg_platform_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalPlatform1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1-x_platform1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontal1LogicalVolume, "plat_support_platform1_horizontal_physical", m_pMotherLogicalVolume,false,0);

m_pLegHorizontalPlatformAir1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(x_pos_floor_leg1-x_platform1, y_pos_floor_leg1-x_outer-z_horizontal_outer, z_pos_floor_leg1+z_outer), m_pLegHorizontalAir1LogicalVolume, "Air_support_leg1_platform_horizontal_physical", m_pMotherLogicalVolume,false,0);


m_pLegPlatformSmallPhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(0, y_pos_floor_leg2+x_platform, z_pos_floor_leg1+z_outer), m_pLegPlatformLogicalVolume, "plat_support_platform_small_leg1", m_pMotherLogicalVolume,false,0);


m_pLegPlatformSmallAirPhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(0, y_pos_floor_leg2+x_platform, z_pos_floor_leg1+z_outer), m_pLegPlatformAirLogicalVolume, "Air_support_platform_small_leg1", m_pMotherLogicalVolume,false,0);

m_pLegPlatformSmall1PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(0, y_pos_floor_leg2+x_platform1, z_pos_floor_leg1+z_outer), m_pLegPlatformLogicalVolume, "plat_support_platform_small_leg2", m_pMotherLogicalVolume,false,0);

m_pLegPlatformSmallAir1PhysicalVolume = new G4PVPlacement(Rot1, G4ThreeVector(0, y_pos_floor_leg2+x_platform1, z_pos_floor_leg1+z_outer), m_pLegPlatformAirLogicalVolume, "Air_support_platform_small_leg2", m_pMotherLogicalVolume,false,0);
    
    //Spreader
    G4RotationMatrix *RotSpreader = new G4RotationMatrix;
    RotSpreader->rotateZ(120.*deg);
    RotSpreader->rotateX(90.*deg);
    //RotSpreader->rotateY(120.*deg);
    
    G4RotationMatrix *RotSpreader1 = new G4RotationMatrix;
    RotSpreader1->rotateZ(240.*deg);
    RotSpreader1->rotateX(90.*deg);
    
    m_pLegSpreaderPlatLogicalVolume = new G4LogicalVolume(pand, SS304LSteel, "leg1Logical");
    m_pLegSpreaderLogicalVolume = new G4LogicalVolume(pLegSpreader, SS304LSteel, "leg1Logical");
    m_pLegSpreaderAirLogicalVolume = new G4LogicalVolume(air_beam_spreader, Air, "leg1Logical");
    m_pLegSpreader1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(0,+z_spreader,z_pos_spreader), m_pLegSpreaderLogicalVolume, "spreader_1_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreader2PhysicalVolume = new G4PVPlacement(RotSpreader, G4ThreeVector(+z_spreader*cos(30.*deg)+x_spreader*cos(30.*deg),-z_spreader*sin(30.*deg)-x_spreader*sin(30.*deg),z_pos_spreader), m_pLegSpreaderLogicalVolume, "spreader_2_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreader3PhysicalVolume = new G4PVPlacement(RotSpreader1, G4ThreeVector(-z_spreader*cos(30.*deg)-x_spreader*cos(30.*deg),-z_spreader*sin(30.*deg)-x_spreader*sin(30.*deg),z_pos_spreader), m_pLegSpreaderLogicalVolume, "spreader_3_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreader1AirPhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(0,+z_spreader,z_pos_spreader), m_pLegSpreaderAirLogicalVolume, "Air_support_leg1_spreader_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreader2AirPhysicalVolume = new G4PVPlacement(RotSpreader, G4ThreeVector(+z_spreader*cos(30.*deg)+x_spreader*cos(30.*deg),-z_spreader*sin(30.*deg)-x_spreader*sin(30.*deg),z_pos_spreader), m_pLegSpreaderAirLogicalVolume, "Air_support_leg2_spreader_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreader3AirPhysicalVolume = new G4PVPlacement(RotSpreader1, G4ThreeVector(-z_spreader*cos(30.*deg)-x_spreader*cos(30.*deg),-z_spreader*sin(30.*deg)-x_spreader*sin(30.*deg),z_pos_spreader), m_pLegSpreaderAirLogicalVolume, "Air_support_leg3_spreader_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreaderPlat1PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(0.,0.,z_pos_spreader+y_spreader+5.2), m_pLegSpreaderPlatLogicalVolume, "spreader_plat_1_physical", m_pMotherLogicalVolume,false,0);
    m_pLegSpreaderPlat2PhysicalVolume = new G4PVPlacement(Rot, G4ThreeVector(0.,0.,z_pos_spreader-y_spreader-5.2), m_pLegSpreaderPlatLogicalVolume, "spreader_plat_2_physical", m_pMotherLogicalVolume,false,0);
    //+5 is coming from the +10. in the trapdefinition
    



//Brace Rods

G4double z_calc = 3090.*mm; //from Cad
G4double y_calc = z_horizontal_outer*2.;
G4double tilt_angle_brace = 90.*deg - 180.*deg*atan(z_calc/y_calc)/pi_g; ///54.61211*deg, from calculation.
G4double R_brace_rods = GetGeometryParameter("R_brace_rods");
G4double cylinder_height_brace= sqrt(z_calc*z_calc+y_calc*y_calc)/2.-(R_brace_rods/cos(tilt_angle_brace))*sin(tilt_angle_brace)-0.1*mm;//2667.89242*mm 

G4Tubs *pcylinderbracerods= new G4Tubs("Cylinder_brace_rods",0., R_brace_rods,cylinder_height_brace, 0.*deg, 360.*deg);

m_pBraceRodLogicalVolume = new G4LogicalVolume(pcylinderbracerods, SS304LSteel, "Cylinder_tie rods");

G4RotationMatrix *RotBrace = new G4RotationMatrix;
RotBrace->rotateY(tilt_angle_brace);

G4double z_offset_brace = z_outer - cylinder_height_brace*cos(tilt_angle_brace);
G4double zbrace =z_pos_floor_leg2-37.5*mm;//offset in the z placement (z_offset_brace)
m_pBraceRodLow1PhysicalVolume = new G4PVPlacement(RotBrace, G4ThreeVector(0.,2250.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_1_support", m_pMotherLogicalVolume,false,0);//2250 I choose a y plane




G4RotationMatrix *RotBrace2 = new G4RotationMatrix;
RotBrace2->rotateX(tilt_angle_brace);


G4RotationMatrix *RotBrace1 = new G4RotationMatrix;
RotBrace1->rotateY(90.*deg+(90.*deg-tilt_angle_brace));

G4RotationMatrix *RotBrace3 = new G4RotationMatrix;
RotBrace3->rotateX(90.*deg+(90.*deg-tilt_angle_brace));

m_pBraceRodLow2PhysicalVolume = new G4PVPlacement(RotBrace1, G4ThreeVector(0.,2200.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_2_support", m_pMotherLogicalVolume,false,0);


m_pBraceRodLow3PhysicalVolume = new G4PVPlacement(RotBrace, G4ThreeVector(0.,-2250.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_3_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodLow4PhysicalVolume = new G4PVPlacement(RotBrace1, G4ThreeVector(0.,-2200.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_4_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodLow5PhysicalVolume = new G4PVPlacement(RotBrace2, G4ThreeVector(2250,0.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_5_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodLow6PhysicalVolume = new G4PVPlacement(RotBrace3, G4ThreeVector(2200,0.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_6_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodLow7PhysicalVolume = new G4PVPlacement(RotBrace2, G4ThreeVector(-2250,0.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_7_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodLow8PhysicalVolume = new G4PVPlacement(RotBrace3, G4ThreeVector(-2200,0.,zbrace), m_pBraceRodLogicalVolume, "Brace_Rod_8_support", m_pMotherLogicalVolume,false,0);




G4double z_calc_2 = 2915.*mm;

G4double tilt_angle_brace_medium = 90.*deg - 180.*deg*atan(z_calc_2/y_calc)/pi_g;//56.173369

G4double cylinder_height_brace_medium =sqrt(z_calc_2*z_calc_2+y_calc*y_calc)/2. -(R_brace_rods/cos(tilt_angle_brace_medium))*sin(tilt_angle_brace_medium)-0.1*mm; //2616.801482*mm
G4Tubs *pcylinderbracerods_medium= new G4Tubs("Cylinder_brace_rods",0., R_brace_rods,cylinder_height_brace_medium, 0.*deg, 360.*deg);
m_pBraceRodMediumLogicalVolume = new G4LogicalVolume(pcylinderbracerods_medium, SS304LSteel, "Cylinder_tie rods");

G4double zbrace_medium =z_pos_floor_leg2+z_outer+z_medium_outer;

G4RotationMatrix *RotBracemedium = new G4RotationMatrix;
RotBracemedium->rotateY(tilt_angle_brace_medium);

G4RotationMatrix *RotBracemedium1 = new G4RotationMatrix;
RotBracemedium1->rotateY(90.*deg+(90.*deg-tilt_angle_brace_medium));

G4RotationMatrix *RotBracemedium2 = new G4RotationMatrix;
RotBracemedium2->rotateX(tilt_angle_brace_medium);

G4RotationMatrix *RotBracemedium3 = new G4RotationMatrix;
RotBracemedium3->rotateX(90.*deg+(90.*deg-tilt_angle_brace_medium));

m_pBraceRodMedium1PhysicalVolume = new G4PVPlacement(RotBracemedium, G4ThreeVector(0.,2250.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_1_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium1PhysicalVolume = new G4PVPlacement(RotBracemedium1, G4ThreeVector(0.,2200.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_2_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium3PhysicalVolume = new G4PVPlacement(RotBracemedium, G4ThreeVector(0.,-2250.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_3_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium4PhysicalVolume = new G4PVPlacement(RotBracemedium1, G4ThreeVector(0.,-2200.,zbrace_medium), m_pBraceRodMediumLogicalVolume, 
"Brace_Rod_Medium_4_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium5PhysicalVolume = new G4PVPlacement(RotBracemedium2, G4ThreeVector(2250.,0.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_5_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium6PhysicalVolume = new G4PVPlacement(RotBracemedium3, G4ThreeVector(2200.,0.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_6_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium7PhysicalVolume = new G4PVPlacement(RotBracemedium2, G4ThreeVector(-2250.,0.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_7_support", m_pMotherLogicalVolume,false,0);

m_pBraceRodMedium8PhysicalVolume = new G4PVPlacement(RotBracemedium3, G4ThreeVector(-2200.,0.,zbrace_medium), m_pBraceRodMediumLogicalVolume, "Brace_Rod_Medium_8_support", m_pMotherLogicalVolume,false,0);

    //Tie Rods
    
    
   G4double R_tie_rods = GetGeometryParameter("R_tie_rods");
    
    G4double y_tie_rod1=z_spreader*2.; //
    
    
    G4double y_tie_rod2=-(z_spreader*2.*sin(30.*deg)+x_spreader*sin(30.*deg)-50.*sin(30.*deg));//220.
    G4double x_tie_rod2=z_spreader*2.*cos(30.*deg)+x_spreader*cos(30.*deg)*cos(30.*deg)-50.*cos(30.*deg);//-50 position tie rod
    G4double y_2_tie_rod2=-(z_spreader*2.*sin(30.*deg)+x_spreader*sin(30.*deg)-225.*sin(30.*deg)); // 225 position tie rod
    G4double x_2_tie_rod2=z_spreader*2.*cos(30.*deg)+x_spreader*cos(30.*deg)*cos(30.*deg)-225.*cos(30.*deg);//
    G4double cylinder_height_tie=929.*mm; //from geantino simulation
    G4double cylinder_height_tie_2=583.*mm; //from geantino
    G4double z_tie_rod=827.+cryo_offset+cylinder_height_tie; //from geantino simulation
    G4double z_2_tie_rod=827.+cryo_offset+2.*930.+y_spreader*2.+cylinder_height_tie_2;//geantino sim
    
    
    G4Tubs *pcylindertierods= new G4Tubs("Cylinder_tie_rods",0., R_tie_rods,cylinder_height_tie, 0.*deg, 360.*deg);
    G4Tubs *pcylindertierods2= new G4Tubs("Cylinder_tie_rods",0., R_tie_rods,cylinder_height_tie_2, 0.*deg, 360.*deg);
    
    m_pTieRodLogicalVolume = new G4LogicalVolume(pcylindertierods, SS304LSteel, "Cylinder_tie rods");
    m_pTie2RodLogicalVolume = new G4LogicalVolume(pcylindertierods2, SS304LSteel, "Cylinder_tie rods");
    
    
    
    m_pTieRod1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,y_tie_rod1-30.,z_tie_rod), m_pTieRodLogicalVolume, "Tie_Rod_1_support", m_pMotherLogicalVolume,false,0);//-30 position tie rod
    m_pTieRod2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_tie_rod2,y_tie_rod2,z_tie_rod), m_pTieRodLogicalVolume, "Tie_Rod_2_support", m_pMotherLogicalVolume,false,0);
    m_pTieRod3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(-x_tie_rod2,y_tie_rod2,z_tie_rod), m_pTieRodLogicalVolume, "Tie_Rod_3_support", m_pMotherLogicalVolume,false,0);
    
    m_pTie2Rod1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,y_tie_rod1-200.,z_2_tie_rod), m_pTie2RodLogicalVolume, "Tie_Rod_2half_1_support", m_pMotherLogicalVolume,false,0);//-200 position tie rod
    m_pTie2Rod2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_2_tie_rod2,y_2_tie_rod2,z_2_tie_rod), m_pTie2RodLogicalVolume, "Tie_Rod__2half_2_support", m_pMotherLogicalVolume,false,0);
    m_pTie2Rod3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(-x_2_tie_rod2,y_2_tie_rod2,z_2_tie_rod), m_pTie2RodLogicalVolume, "Tie_Rod_2half_3_support", m_pMotherLogicalVolume,false,0);
    


//change of the mother volume (cons)
m_pMotherLogicalVolume = m_pWaterConsLogicalVolume;

//position of the tilt legs in the cons

G4double x_cons_leg1= x_pos_floor_leg1 + 2.*x_center_tilt_beam - z_tilt_cons_beam*sintilt*cosrot- 2.*(x_outer/costilt)*sintilt*sintilt*cosrot;
G4double y_cons_leg1= y_pos_floor_leg1 + 2.*y_center_tilt_beam - z_tilt_cons_beam*sintilt*cosrot- 2.*(x_outer/costilt)*sintilt*sintilt*cosrot;
G4double z_cons_leg1= -(dWaterConsZed/2. - z_tilt_cons_beam*costilt) + x_outer*sintilt;

//placement of the tilt legs in the cons

m_pLegTiltedCons1LogicalVolume = new G4LogicalVolume(pLegTiltedConsVolume, SS304LSteel, "legtilted1cons");
m_pLegTiltedCons1PhysicalVolume = new G4PVPlacement(Rot6, G4ThreeVector(x_cons_leg1,y_cons_leg1, z_cons_leg1), m_pLegTiltedCons1LogicalVolume, "support_legcons_tilted_physical_1", m_pMotherLogicalVolume,false,0);
m_pLegTiltedCons2LogicalVolume = new G4LogicalVolume(pLegTiltedCons1Volume, SS304LSteel, "legtilted2cons");
m_pLegTiltedCons2PhysicalVolume = new G4PVPlacement(Rot4, G4ThreeVector(-x_cons_leg1,y_cons_leg1, z_cons_leg1), m_pLegTiltedCons2LogicalVolume, "support_legcons_tilted_physical_2", m_pMotherLogicalVolume,false,0);
m_pLegTiltedCons3LogicalVolume = new G4LogicalVolume(pLegTiltedConsVolume, SS304LSteel, "legtilted3cons");
m_pLegTiltedCons3PhysicalVolume = new G4PVPlacement(Rot3, G4ThreeVector(x_cons_leg1,-y_cons_leg1, z_cons_leg1), m_pLegTiltedCons3LogicalVolume, "support_legcons_tilted_physical_3", m_pMotherLogicalVolume,false,0);
m_pLegTiltedCons4LogicalVolume = new G4LogicalVolume(pLegTiltedCons1Volume, SS304LSteel, "legtilted4cons");
m_pLegTiltedCons4PhysicalVolume = new G4PVPlacement(Rot5, G4ThreeVector(-x_cons_leg1,-y_cons_leg1, z_cons_leg1), m_pLegTiltedCons4LogicalVolume, "support_legcons_tilted_physical_4", m_pMotherLogicalVolume,false,0);

//Air
m_pLegTiltedConsAir1LogicalVolume = new G4LogicalVolume(air_beam_tilted_cons, Air, "air_legtilted1cons");
m_pLegTiltedConsAir1PhysicalVolume = new G4PVPlacement(Rot6, G4ThreeVector(x_cons_leg1,y_cons_leg1, z_cons_leg1), m_pLegTiltedConsAir1LogicalVolume, "Air_support_legcons_tilted_physical_1", m_pMotherLogicalVolume,false,0);

m_pLegTiltedConsAir2PhysicalVolume = new G4PVPlacement(Rot4, G4ThreeVector(-x_cons_leg1,y_cons_leg1, z_cons_leg1), m_pLegTiltedConsAir1LogicalVolume, "Air_support_legcons_tilted_physical_2", m_pMotherLogicalVolume,false,0);

m_pLegTiltedConsAir3PhysicalVolume = new G4PVPlacement(Rot3, G4ThreeVector(x_cons_leg1,-y_cons_leg1, z_cons_leg1), m_pLegTiltedConsAir1LogicalVolume, "Air_support_legcons_tilted_physical_3", m_pMotherLogicalVolume,false,0);

m_pLegTiltedConsAir4PhysicalVolume = new G4PVPlacement(Rot5, G4ThreeVector(-x_cons_leg1,-y_cons_leg1, z_cons_leg1), m_pLegTiltedConsAir1LogicalVolume, "Air_support_legcons_tilted_physical_4", m_pMotherLogicalVolume,false,0);


//position of the top legs
G4double x_center_top_beam1 = x_cons_leg1- z_tilt_cons_beam*sintilt*cosrot- 2.*(x_outer/costilt)*sintilt*sintilt*cosrot;

G4double y_center_top_beam1 = y_cons_leg1- z_tilt_cons_beam*sintilt*cosrot- 2.*(x_outer/costilt)*sintilt*sintilt*cosrot;

//lenght tilt beam on the top
G4double z_tilt_beam_top = sqrt(4.*x_center_top_beam1*x_center_top_beam1+4.*y_center_top_beam1*y_center_top_beam1)*0.5;
G4double z_tilt_beam_top_2 =z_tilt_beam_top*0.5-x_outer*0.5;

//Top Tilted Volume
G4UnionSolid *pLegTop1Volume = ConstructBeam(x_outer, y_outer, z_tilt_beam_top, x_inner, y_inner, z_tilt_beam_top);
G4UnionSolid *pLegTop2Volume = ConstructBeam(x_outer, y_outer, z_tilt_beam_top_2, x_inner, y_inner, z_tilt_beam_top_2);
G4Box *air_beam_top_1 = new G4Box("box_top", x_air, y_air, z_tilt_beam_top);
G4Box *air_beam_top_2 = new G4Box("box_top_2",x_air, y_air, z_tilt_beam_top_2);


//zed position of the top legs


G4double z_center_top_beam1 =z_cons_leg1 + z_tilt_cons_beam*costilt+x_outer*sintilt+x_outer;

 

G4RotationMatrix *Rot7 = new G4RotationMatrix;
Rot7->rotateZ(-rotation_angle);
Rot7->rotateY(90.*deg);
G4RotationMatrix *Rot8 = new G4RotationMatrix;
Rot8->rotateZ(rotation_angle);
Rot8->rotateY(90.*deg);


//placement of the top leg
m_pLegTopLogicalVolume1 = new G4LogicalVolume(pLegTop1Volume, SS304LSteel, "legtop1");
m_pLegTopPhysicalVolume1 = new G4PVPlacement(Rot7, G4ThreeVector(x_center_top_beam1-z_tilt_beam_top*cosrot,y_center_top_beam1-z_tilt_beam_top*cosrot, z_center_top_beam1), m_pLegTopLogicalVolume1, "support_leg1_top", m_pMotherLogicalVolume,false,0);

m_pLegTopLogicalVolume2 = new G4LogicalVolume(pLegTop2Volume, SS304LSteel, "legtop1");
m_pLegTopPhysicalVolume2 = new G4PVPlacement(Rot8, G4ThreeVector(-x_center_top_beam1+z_tilt_beam_top_2*cosrot,y_center_top_beam1-z_tilt_beam_top_2*cosrot, z_center_top_beam1), m_pLegTopLogicalVolume2, "support_leg2_top", m_pMotherLogicalVolume,false,0);

m_pLegTopPhysicalVolume3 = new G4PVPlacement(Rot8, G4ThreeVector(x_center_top_beam1-z_tilt_beam_top_2*cosrot,-y_center_top_beam1+z_tilt_beam_top_2*cosrot, z_center_top_beam1), m_pLegTopLogicalVolume2, "support_leg3_top", m_pMotherLogicalVolume,false,0);


//air

m_pLegTopAirLogicalVolume1 = new G4LogicalVolume(air_beam_top_1, Air, "air_legtop1");
m_pLegTopAirPhysicalVolume1 = new G4PVPlacement(Rot7, G4ThreeVector(x_center_top_beam1-z_tilt_beam_top*cosrot,y_center_top_beam1-z_tilt_beam_top*cosrot, z_center_top_beam1), m_pLegTopAirLogicalVolume1, "Air_support_leg1_top", m_pMotherLogicalVolume,false,0);
m_pLegTopAirLogicalVolume2 = new G4LogicalVolume(air_beam_top_2, Air, "air_legtop1");
m_pLegTopAirPhysicalVolume2 = new G4PVPlacement(Rot8, G4ThreeVector(-x_center_top_beam1+z_tilt_beam_top_2*cosrot,y_center_top_beam1-z_tilt_beam_top_2*cosrot, z_center_top_beam1), m_pLegTopAirLogicalVolume2, "Air_support_leg2_top", m_pMotherLogicalVolume,false,0);
m_pLegTopAirPhysicalVolume3 = new G4PVPlacement(Rot8, G4ThreeVector(x_center_top_beam1-z_tilt_beam_top_2*cosrot,-y_center_top_beam1+z_tilt_beam_top_2*cosrot, z_center_top_beam1), m_pLegTopAirLogicalVolume2, "Air_support_leg3_top", m_pMotherLogicalVolume,false,0);



G4double position = 0.5*1237.*mm+x_outer;//from cad
//zed of square top legs
G4double z_top_vertical_leg = position-x_outer-x_outer*sqrt(2);

G4double position1 = 0.5*1449.*mm+x_outer;//from cad
//zed of square top legs
G4double z_top_vertical_leg_1 = position1-x_outer-x_outer*sqrt(2);

G4UnionSolid *pLegTopVerticalVolume1 = ConstructBeam(x_outer, y_outer, z_top_vertical_leg, x_inner, y_inner, z_top_vertical_leg);
G4UnionSolid *pLegTopVerticalVolume2 = ConstructBeam(x_outer, y_outer, z_top_vertical_leg_1, x_inner, y_inner, z_top_vertical_leg_1);
G4Box *air_beam_top_3 = new G4Box("box_top_3",x_air, y_air, z_top_vertical_leg);
G4Box *air_beam_top_4 = new G4Box("box_top_4",x_air, y_air, z_top_vertical_leg_1);

m_pLegTopLogicalVolume3 = new G4LogicalVolume(pLegTopVerticalVolume1, SS304LSteel, "legtop1");
m_pLegTopPhysicalVolume4 = new G4PVPlacement(Rot1, G4ThreeVector(0,position, z_center_top_beam1), m_pLegTopLogicalVolume3, "support_leg4_top", m_pMotherLogicalVolume,false,0);
m_pLegTopPhysicalVolume5 = new G4PVPlacement(Rot1, G4ThreeVector(0,-position, z_center_top_beam1), m_pLegTopLogicalVolume3, "support_leg5_top", m_pMotherLogicalVolume,false,0);

m_pLegTopLogicalVolume4 = new G4LogicalVolume(pLegTopVerticalVolume2, SS304LSteel, "legtop1");
m_pLegTopPhysicalVolume6 = new G4PVPlacement(Rot, G4ThreeVector(position1,0., z_center_top_beam1), m_pLegTopLogicalVolume4, "support_leg6_top", m_pMotherLogicalVolume,false,0);
m_pLegTopPhysicalVolume7 = new G4PVPlacement(Rot, G4ThreeVector(-position1,0., z_center_top_beam1), m_pLegTopLogicalVolume4, "support_leg7_top", m_pMotherLogicalVolume,false,0);

//Air
m_pLegTopAirLogicalVolume3 = new G4LogicalVolume(air_beam_top_3, Air, "air_legtop1");
m_pLegTopAirPhysicalVolume4 = new G4PVPlacement(Rot1, G4ThreeVector(0,position, z_center_top_beam1), m_pLegTopAirLogicalVolume3, "Air_support_leg4_top", m_pMotherLogicalVolume,false,0);
m_pLegTopAirPhysicalVolume5 = new G4PVPlacement(Rot1, G4ThreeVector(0,-position, z_center_top_beam1), m_pLegTopAirLogicalVolume3, "Air_support_leg5_top", m_pMotherLogicalVolume,false,0);
m_pLegTopAirLogicalVolume4 = new G4LogicalVolume(air_beam_top_4, Air, "legtop1");
m_pLegTopAirPhysicalVolume6 = new G4PVPlacement(Rot, G4ThreeVector(position1,0., z_center_top_beam1), m_pLegTopAirLogicalVolume4, "Air_support_leg6_top", m_pMotherLogicalVolume,false,0);
m_pLegTopAirPhysicalVolume7 = new G4PVPlacement(Rot, G4ThreeVector(-position1,0., z_center_top_beam1), m_pLegTopAirLogicalVolume4, "Air_support_leg7_top", m_pMotherLogicalVolume,false,0);

//Tie Rods
    
 
  
    G4double cylinder_height_tie_cons=508.*mm;
    
    G4Tubs *pcylindertierodscons= new G4Tubs("Cylinder_tie_rods",0., R_tie_rods,cylinder_height_tie_cons, 0.*deg, 360.*deg);
    
    m_pTieConsRodLogicalVolume = new G4LogicalVolume(pcylindertierodscons, SS304LSteel, "Cylinder_tie rods");
    
    G4double z_tie_rod_cons=-(dWaterConsZed/2. - cylinder_height_tie_cons);
    
    m_pTieRodCons1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,y_tie_rod1-200.,z_tie_rod_cons), m_pTieConsRodLogicalVolume, "Tie_Rod_Cons_1_support", m_pMotherLogicalVolume,false,0);
   m_pTieRodCons2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_2_tie_rod2,y_2_tie_rod2,z_tie_rod_cons), m_pTieConsRodLogicalVolume, "Tie_Rod_Cons_2_support", m_pMotherLogicalVolume,false,0);
    m_pTieRodCons3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(-x_2_tie_rod2,y_2_tie_rod2,z_tie_rod_cons), m_pTieConsRodLogicalVolume, "Tie_Rod_Cons_3_support", m_pMotherLogicalVolume,false,0);
    


m_pMotherLogicalVolume = m_pWaterLogicalVolume;

}




void Xenon1tDetectorConstruction::ConstructLeadBrick()
{
  //***Andrew 22/08/12***//
    //Same as Xe100

    //Dimensions
    G4double LeadBrick_len_x = GetGeometryParameter("LeadBrick_len_x");
  G4double LeadBrick_len_y = GetGeometryParameter("LeadBrick_len_y");
  G4double LeadBrick_len_z = GetGeometryParameter("LeadBrick_len_z");
    
  //Position
  G4double LeadBrick_pos_x = GetGeometryParameter("LeadBrick_pos_x");
  G4double LeadBrick_pos_y = GetGeometryParameter("LeadBrick_pos_y");
  G4double LeadBrick_pos_z = GetGeometryParameter("LeadBrick_pos_z");
    
  //Have brick length facing detector
  G4Box *LeadBrick =
    new G4Box("LeadBrick", LeadBrick_len_x/2, LeadBrick_len_y/2, LeadBrick_len_z/2);
  G4Material *Lead = G4Material::GetMaterial("G4_Pb");
  m_pLeadBrickLogicalVolume =
    new G4LogicalVolume(LeadBrick, Lead, "LeadBrick");
  m_pLeadBrickPhysicalVolume =
    new G4PVPlacement(0, G4ThreeVector(LeadBrick_pos_x,
				       LeadBrick_pos_y,
				       LeadBrick_pos_z),
		      m_pLeadBrickLogicalVolume, "LeadBrick_phys",
		      m_pWaterLogicalVolume, false, 0);
}


void Xenon1tDetectorConstruction::ConstructNeutronGenerator()
{
    //***Andrew, Jacques 17/01/13***//
    
    //Positions
    G4double GeneratorContainer_x = GetGeometryParameter("GeneratorContainer_x");
    G4double GeneratorContainer_y = GetGeometryParameter("GeneratorContainer_y");
    G4double GeneratorContainer_z = GetGeometryParameter("GeneratorContainer_z");
        
    m_pNeutronGenerator = new Xenon1tNeutronGenerator(m_pWaterLogicalVolume, 
                                                      GeneratorContainer_x, 
                                                      GeneratorContainer_y, 
                                                      GeneratorContainer_z);
    
}



//===================================================================================================================================================SERENA


//================================== CABLES PIPE =================================SERENA
void
Xenon1tDetectorConstruction::ConstructCablesPipe()
{
  
  
  const G4double dCablesPipeBaseInnerRadius = GetGeometryParameter("CablesPipeBaseInnerRadius");
  const G4double dCablesPipeBaseOuterRadius = GetGeometryParameter("CablesPipeBaseOuterRadius");
  const G4double dCablesPipeBaseHalfHeight = 0.5*GetGeometryParameter("CablesPipeBaseHeight");
  const G4double dCablesPipeBaseZOffset =  GetGeometryParameter("OuterCryostatDomeOuterHeight") + GetGeometryParameter("OuterCryostatCylinderHeight") 
    + GetGeometryParameter("OuterCryostatOffsetZ") + 0.5*GetGeometryParameter("TankOffset");
  
	
	
  double dCablePipe_tilt_angle = GetGeometryParameter("CablePipe_tilt_angle");
  G4RotationMatrix* rot0 = new G4RotationMatrix();
  rot0->rotateY(dCablePipe_tilt_angle);	
	
  const G4double dCablesPipeInnerRadius = GetGeometryParameter("CablesPipeInnerRadius");
  const G4double dCablesPipeOuterRadius = GetGeometryParameter("CablesPipeOuterRadius");
  const G4double dCablesPipeHalfHeight = 0.5*GetGeometryParameter("CablesPipeHeight");
  const G4double dCablesPipeZOffset =  dCablesPipeBaseZOffset + dCablesPipeHalfHeight*sin(dCablePipe_tilt_angle-90*deg) ;
  const G4double dCablesPipeXOffset =  GetGeometryParameter("CablesPipeBaseOuterRadius")*0.5 + GetGeometryParameter("WaterTankInnerRadius")*0.5 ;
  
	
  G4Material *SS304LSteel = G4Material::GetMaterial("SS304LSteel");
  G4Material *Air = G4Material::GetMaterial("G4_AIR");
  
  
  // SOLID VOLUMES
  G4Tubs *pCablesPipeBaseSolid = new G4Tubs("CablesPipeBaseSolid", dCablesPipeBaseInnerRadius, dCablesPipeBaseOuterRadius, dCablesPipeBaseHalfHeight, 0.*deg, 360.*deg);
  G4Tubs *pCablesPipeSolid = new G4Tubs("CablesPipeSolid", 0, dCablesPipeOuterRadius, dCablesPipeHalfHeight, 0.*deg, 360.*deg);
  G4Tubs *pCablesPipeAirSolid = new G4Tubs("CablesPipeAirSolid", 0, dCablesPipeInnerRadius, dCablesPipeHalfHeight, 0.*deg, 360.*deg);
  
  
	
  // LOGICAL VOLUMES
  m_pCablesPipeBaseLogicalVolume = new G4LogicalVolume(pCablesPipeBaseSolid, SS304LSteel, "CablesPipeBaseLogical", 0, 0, 0);
  m_pCablesPipeLogicalVolume = new G4LogicalVolume(pCablesPipeSolid, SS304LSteel, "CablesPipeLogical", 0, 0, 0);
  m_pCablesPipeAirLogicalVolume = new G4LogicalVolume(pCablesPipeAirSolid, Air, "CablesPipeAirLogical", 0, 0, 0);
  
  
  // PHYSICAL VOLUMES
  m_pCablesPipeBasePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dCablesPipeBaseZOffset), m_pCablesPipeBaseLogicalVolume, "CablesPipeBasePhysical", m_pMotherLogicalVolume, false, 0);
  m_pCablesPipePhysicalVolume = new G4PVPlacement(rot0, G4ThreeVector(dCablesPipeXOffset, 0, dCablesPipeZOffset), m_pCablesPipeLogicalVolume, "CablesPipePhysical", m_pMotherLogicalVolume, false, 0);
  m_pCablesPipeAirPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pCablesPipeAirLogicalVolume, "CablesPipeAirPhysical", m_pCablesPipeLogicalVolume, false, 0);
  
  
  // VISUALIZATION ATTRIBUTES
  G4Colour hCablesPipeBaseColor(0.500, 0.500, 0.500, 0.1);
  G4VisAttributes *pCablesPipeBaseVisAtt = new G4VisAttributes(hCablesPipeBaseColor);
  pCablesPipeBaseVisAtt->SetVisibility(false);
  m_pCablesPipeBaseLogicalVolume->SetVisAttributes(pCablesPipeBaseVisAtt); 
  m_pCablesPipeLogicalVolume->SetVisAttributes(pCablesPipeBaseVisAtt);
	
  G4Colour hAirColor(0, 1., 1.);
  G4VisAttributes *pCablesPipeAirVisAtt = new G4VisAttributes(hAirColor);
  pCablesPipeAirVisAtt->SetVisibility(false);
  m_pCablesPipeAirLogicalVolume->SetVisAttributes(pCablesPipeAirVisAtt);
  
}

void Xenon1tDetectorConstruction::ConstructPipe()



{
    m_pMotherLogicalVolume = m_pWaterLogicalVolume;
    G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");
	//G4Material *Air = G4Material::GetMaterial("G4_AIR");
    G4Material *Vacuum       = G4Material::GetMaterial("Vacuum");
    G4Material *Torlon  = G4Material::GetMaterial("Torlon");
    G4double cryo_offset = m_hGeometryParameters["OuterCryostatOffsetZ"];
    
    //small pipe paramters
    G4double Rmax_cylinder_small_pipe = GetGeometryParameter("Rmax_cylinder_small_pipe");
    G4double Rmin_cylinder_small_pipe = GetGeometryParameter("Rmin_cylinder_small_pipe");
    G4double R_base_small = GetGeometryParameter("flange_radius_small_pipe");
    G4double base_height_small = GetGeometryParameter("flange_height_small_pipe");
    G4double cylinder_height_small_pipe = GetGeometryParameter("cylinder_height_small_pipe");
    G4double cylinder_long_height_small_pipe = GetGeometryParameter("cylinder_long_height_small_pipe");
    G4double torus_radius_small_pipe = GetGeometryParameter("torus_radius_small_pipe");

    
    //central pipe parameters
    G4double R_max_tolon = GetGeometryParameter("R_max_tolon");
    G4double R_min_tolon =  GetGeometryParameter("R_min_tolon");
    G4double h_tolon =  GetGeometryParameter("h_tolon");
    G4double Rmax_cylinder = GetGeometryParameter("Rmax_cylinder_external_central_pipe");
    G4double Rmin_cylinder =  GetGeometryParameter("Rmin_cylinder_external_central_pipe");
    G4double Rmax_cylinder_internal = GetGeometryParameter("Rmax_cylinder_internal_central_big_pipe");
    G4double Rmin_cylinder_internal = GetGeometryParameter("Rmin_cylinder_internal_central_big_pipe");
    G4double Rmax_cylinder_internal_1 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_1");
    G4double Rmin_cylinder_internal_1 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_1");
    G4double Rmax_cylinder_internal_2 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_2");
    G4double Rmin_cylinder_internal_2 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_2");
    
    G4double Rmax_cylinder_internal_3 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_3");
    G4double Rmin_cylinder_internal_3 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_3");
    G4double Rmax_cylinder_internal_4 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_4");
    G4double Rmin_cylinder_internal_4 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_4");
    G4double Rmax_cylinder_internal_5 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_5");
    G4double Rmin_cylinder_internal_5 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_5");
    
    
    G4double cylinder_height = GetGeometryParameter("cylinder_height_central_pipe");
    G4double cylinder_height_low = GetGeometryParameter("cylinder_height_low");
    
    
    G4double torus_angle = GetGeometryParameter("torus_spanned_angle");
    G4double torus_swept_radius = GetGeometryParameter("torus_radius");
    G4double torus_swept_radius_internal5 = GetGeometryParameter("torus_radius_internal_5");
    G4double torus_swept_radius_internal4 = GetGeometryParameter("torus_radius_internal_4");
    G4double torus_swept_radius_internal3 = GetGeometryParameter("torus_radius_internal_3");


    G4double Rmax_cylinder_tilted = Rmax_cylinder;
    G4double Rmin_cylinder_tilted = Rmin_cylinder;
   
    G4double cylinder_tilted_height_long = GetGeometryParameter("cylinder_tilted_long_height_central_pipe");
    
    G4double base_height = GetGeometryParameter("flange_height");
    G4double base_height_internal = GetGeometryParameter("flange_height_internal");
    G4double R_base = GetGeometryParameter("flange_radius");
    G4double R_base_min = GetGeometryParameter("flange_radius")-20.*mm;//-20.*mm is the distance between the flange and the plates
    G4double R_base_internal = GetGeometryParameter("internal_big_flange_radius");
    G4double R_base_internal_1 = GetGeometryParameter("internal_flange_radius_1");
    G4double R_base_internal_2 = GetGeometryParameter("internal_flange_radius_2");
    G4double R_base_internal_3 = GetGeometryParameter("internal_flange_radius_3");
    G4double R_base_internal_4 = GetGeometryParameter("internal_flange_radius_4");
    G4double R_base_internal_5 = GetGeometryParameter("internal_flange_radius_5");
    
    
    G4double x_offset_internal_1 = GetGeometryParameter("x_offset_internal_1");
    G4double x_offset_internal_2 = GetGeometryParameter("x_offset_internal_2");
    G4double x_offset_internal_3 = GetGeometryParameter("x_offset_internal_3");
    G4double x_offset_internal_4 = GetGeometryParameter("x_offset_internal_4");
    G4double x_offset_internal_5 = GetGeometryParameter("x_offset_internal_5");
    
    G4double y_offset_internal_1 = GetGeometryParameter("y_offset_internal_1");
    G4double y_offset_internal_2 = GetGeometryParameter("y_offset_internal_2");
    G4double y_offset_internal_3 = GetGeometryParameter("y_offset_internal_3");
    G4double y_offset_internal_4 = GetGeometryParameter("y_offset_internal_4");
    G4double y_offset_internal_5 = GetGeometryParameter("y_offset_internal_5");

    
    G4double R_small_stain = GetGeometryParameter("R_small_stain");
    G4double height_small_stain = GetGeometryParameter("height_small_stain");
   
    G4double R_plate = GetGeometryParameter("R_plate");
    G4double h_plate = GetGeometryParameter("h_plate");
    G4double h_plate_low = GetGeometryParameter("h_plate_low");
    
    
    
    G4double z_pipe_box = GetGeometryParameter("z_pipe_box");
    

    G4double y_pipe_box_1 = GetGeometryParameter("y_pipe_box_1");
    G4double z_pipe_box_1 = GetGeometryParameter("z_pipe_box_1");
    
    
    G4double R_cyl_screw_1=GetGeometryParameter("R_cyl_screw_1");
    G4double R_cyl_screw_2=GetGeometryParameter("R_cyl_screw_2");
    G4double height_cyl_screw_1=GetGeometryParameter("height_cyl_screw_1");
    G4double height_cyl_screw_2=GetGeometryParameter("height_cyl_screw_2");
    
    //small pipe
    
    G4Tubs *pcylindersmallpipe= new G4Tubs("Cylinder_external_small",0., Rmax_cylinder_small_pipe,cylinder_height_small_pipe, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_smallpipeair = new G4Tubs("Cylinder_vacuum_small", 0., Rmin_cylinder_small_pipe, cylinder_height_small_pipe, 0.*deg, 360.*deg);
    G4Tubs *pcylinderbasesmallpipe= new G4Tubs("base_external_small",Rmax_cylinder_small_pipe, R_base_small,base_height_small, 0.*deg, 360.*deg);
    G4Torus *ptorus_external_small = new G4Torus("torus_external_small", Rmin_cylinder_small_pipe, Rmax_cylinder_small_pipe, torus_radius_small_pipe, 0.*deg, 85.*deg);
    G4Torus *ptorus_smallpipe_air = new G4Torus("torus_vacuum_small", 0., Rmin_cylinder_small_pipe-0.001*mm, torus_radius_small_pipe, 0.*deg, 85.*deg);

    G4Tubs *pcylinder_long_small_pipe= new G4Tubs("Cylinder_long_small",0., Rmax_cylinder_small_pipe,cylinder_long_height_small_pipe, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_long_air_small_pipe= new G4Tubs("Cylinder_long_small_air",0.,Rmin_cylinder_small_pipe,cylinder_long_height_small_pipe, 0.*deg, 360.*deg);
    
    //solid of the central pipe
    G4Tubs *pcylindertolon= new G4Tubs("Cylinder_external_tolon",R_min_tolon, R_max_tolon,h_tolon, 0.*deg, 360.*deg);
    G4Tubs *pcylinderexternaltubs= new G4Tubs("Cylinder_external_SS",0., Rmax_cylinder,cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_air = new G4Tubs("Cylinder_vacuum", 0., Rmin_cylinder, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal = new G4Tubs("Cylinder_internal_SS", Rmin_cylinder_internal, Rmax_cylinder_internal, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_1 = new G4Tubs("Cylinder_internal_SS_1", Rmin_cylinder_internal_1, Rmax_cylinder_internal_1, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_2 = new G4Tubs("Cylinder_internal_SS_2", Rmin_cylinder_internal_2, Rmax_cylinder_internal_2, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_3 = new G4Tubs("Cylinder_internal_SS_3", Rmin_cylinder_internal_3, Rmax_cylinder_internal_3, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_4 = new G4Tubs("Cylinder_internal_SS_4", Rmin_cylinder_internal_4, Rmax_cylinder_internal_4, cylinder_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_5 = new G4Tubs("Cylinder_internal_SS_5", Rmin_cylinder_internal_5, Rmax_cylinder_internal_5, cylinder_height, 0.*deg, 360.*deg);
    
    G4Tubs *pcylinderexternal_low= new G4Tubs("Cylinder_external_SS",0., Rmax_cylinder,cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_air_low = new G4Tubs("Cylinder_vacuum", 0., Rmin_cylinder, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low = new G4Tubs("Cylinder_internal_SS", Rmin_cylinder_internal, Rmax_cylinder_internal, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low_1 = new G4Tubs("Cylinder_internal_SS_1", Rmin_cylinder_internal_1, Rmax_cylinder_internal_1, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low_2 = new G4Tubs("Cylinder_internal_SS_2", Rmin_cylinder_internal_2, Rmax_cylinder_internal_2, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low_3 = new G4Tubs("Cylinder_internal_SS_3", Rmin_cylinder_internal_3, Rmax_cylinder_internal_3, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low_4 = new G4Tubs("Cylinder_internal_SS_4", Rmin_cylinder_internal_4, Rmax_cylinder_internal_4, cylinder_height_low, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_internal_low_5 = new G4Tubs("Cylinder_internal_SS_5", Rmin_cylinder_internal_5, Rmax_cylinder_internal_5, cylinder_height_low, 0.*deg, 360.*deg);

    
    
    G4Torus *ptorus_external = new G4Torus("torus_external", Rmin_cylinder, Rmax_cylinder, torus_swept_radius, 0.*deg, 85.*deg);
    //G4Tubs  *ptorus_small_stain = new G4Torus("torus_external", Rmax_cylinder, R_small_stain, height_small_stain, 0.*deg, 360.*deg);
    G4Torus *ptorus_air = new G4Torus("torus_vacuum", 0., Rmin_cylinder-0.001*mm, torus_swept_radius, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal = new G4Torus("torus_Internal", Rmin_cylinder_internal, Rmax_cylinder_internal, torus_swept_radius, 0.*deg, 85.*deg);
    
    G4Torus *ptorus_air_internal = new G4Torus("torus_vacuum_Internal", 0., Rmin_cylinder_internal, torus_swept_radius, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal_1 = new G4Torus("torus_Internal_1", Rmin_cylinder_internal_1, Rmax_cylinder_internal_1, torus_swept_radius, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal_2 = new G4Torus("torus_Internal_2", Rmin_cylinder_internal_2, Rmax_cylinder_internal_2, torus_swept_radius, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal_3 = new G4Torus("torus_Internal_3", Rmin_cylinder_internal_3, Rmax_cylinder_internal_3, torus_swept_radius_internal3, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal_4 = new G4Torus("torus_Internal_4", Rmin_cylinder_internal_4, Rmax_cylinder_internal_4, torus_swept_radius_internal4, 0.*deg, 85.*deg);
    G4Torus *ptorus_internal_5 = new G4Torus("torus_Internal_5", Rmin_cylinder_internal_5, Rmax_cylinder_internal_5, torus_swept_radius_internal5, 0.*deg, 85.*deg);
  
    
    G4Tubs  *pcylinder_tilted_external_long = new G4Tubs("Cylinder_external_tilted_long",0., Rmax_cylinder_tilted,cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs  *pcylinder_tilted_air_long = new G4Tubs("Cylinder_external_tilted_vacuum_long", 0., Rmin_cylinder_tilted,cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long = new G4Tubs("Cylinder_internal_SS_long", Rmin_cylinder_internal, Rmax_cylinder_internal, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long_1 = new G4Tubs("Cylinder_internal_SS_long_1", Rmin_cylinder_internal_1, Rmax_cylinder_internal_1, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long_2 = new G4Tubs("Cylinder_internal_SS_long_2", Rmin_cylinder_internal_2, Rmax_cylinder_internal_2, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long_3 = new G4Tubs("Cylinder_internal_SS_long_3", Rmin_cylinder_internal_3, Rmax_cylinder_internal_3, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long_4 = new G4Tubs("Cylinder_internal_SS_long_4", Rmin_cylinder_internal_4, Rmax_cylinder_internal_4, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_tilted_internal_long_5 = new G4Tubs("Cylinder_internal_SS_long_5", Rmin_cylinder_internal_5, Rmax_cylinder_internal_5, cylinder_tilted_height_long, 0.*deg, 360.*deg);
    
    
    G4Tubs *pcylinderbase= new G4Tubs("flange",R_base_min, R_base,base_height, 0.*deg, 360.*deg);
    G4Tubs *pcylinderbase_internal = new G4Tubs("flange_internal",Rmax_cylinder_internal, R_base_internal,base_height_internal, 0.*deg, 360.*deg);
    G4Tubs *pcylinderbase_internal_1 = new G4Tubs("flange_internal_1",Rmax_cylinder_internal_1, R_base_internal_1,base_height_internal, 0.*deg, 360.*deg);
        G4Tubs *pcylinderbase_internal_2 = new G4Tubs("flange_internal_2",Rmax_cylinder_internal_2, R_base_internal_2,base_height_internal, 0.*deg, 360.*deg);
        G4Tubs *pcylinderbase_internal_3 = new G4Tubs("flange_internal_3",Rmax_cylinder_internal_3, R_base_internal_3,base_height_internal, 0.*deg, 360.*deg);
        G4Tubs *pcylinderbase_internal_4 = new G4Tubs("flange_internal_4",Rmax_cylinder_internal_4, R_base_internal_4,base_height_internal, 0.*deg, 360.*deg);
        G4Tubs *pcylinderbase_internal_5 = new G4Tubs("flange_internal_5",Rmax_cylinder_internal_5, R_base_internal_5,base_height_internal, 0.*deg, 360.*deg);
    
    
    G4Tubs *pcylinder_small_stain = new G4Tubs("Cylinder_small_stain", Rmax_cylinder, R_small_stain, height_small_stain, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_plate_small = new G4Tubs("Cylinder_small_plate", Rmax_cylinder, R_plate, h_plate, 0.*deg, 360.*deg);
    G4Tubs *pcylinder_plate_low_small = new G4Tubs("Cylinder_small_low_plate", Rmax_cylinder, R_plate, h_plate_low, 0.*deg, 360.*deg);
    
    
    G4double anglepipebox=8.49*deg;
    G4Tubs *pboxpipe = new G4Tubs("boxpipe", R_plate, R_base_min, z_pipe_box, 0,anglepipebox);//anglepipebox);
       
    G4Tubs *pboxpipe1 = new G4Tubs("boxpipe1", R_plate, R_base_min, z_pipe_box, 360.*deg-anglepipebox, anglepipebox);
    G4Tubs *pboxpipe2 = new G4Tubs("boxpipe2", R_plate, R_base_min, z_pipe_box, 90.*deg, anglepipebox);
    G4Tubs *pboxpipe3 = new G4Tubs("boxpipe3", R_plate, R_base_min, z_pipe_box, 90.*deg-anglepipebox, anglepipebox);
    G4Tubs *pboxpipe4 = new G4Tubs("boxpipe4", R_plate, R_base_min, z_pipe_box, 180.*deg, anglepipebox);
    G4Tubs *pboxpipe5 = new G4Tubs("boxpipe5", R_plate, R_base_min, z_pipe_box, 180.*deg-anglepipebox, anglepipebox);
    G4Tubs *pboxpipe6 = new G4Tubs("boxpipe6", R_plate, R_base_min, z_pipe_box, 270.*deg, anglepipebox);
    G4Tubs *pboxpipe7 = new G4Tubs("boxpipe7", R_plate, R_base_min, z_pipe_box, 270.*deg-anglepipebox, anglepipebox);
   
    
    G4double anglepipeboxsmall=1.2*deg;
    G4Tubs *pboxpipesmall1 = new G4Tubs("boxpipesmall1", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, anglepipebox+anglepipeboxsmall, anglepipeboxsmall);
    G4Tubs *pboxpipesmall2 = new G4Tubs("boxpipesmall2", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 360.*deg-anglepipebox-anglepipeboxsmall,anglepipeboxsmall);
    G4Tubs *pboxpipesmall3 = new G4Tubs("boxpipesmall3", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 45.*deg, anglepipeboxsmall);
    G4Tubs *pboxpipesmall4 = new G4Tubs("boxpipesmall4", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 80.*deg,anglepipeboxsmall);
    G4Tubs *pboxpipesmall5 = new G4Tubs("boxpipesmall5", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 315.*deg, anglepipeboxsmall);
    G4Tubs *pboxpipesmall6 = new G4Tubs("boxpipesmall6", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 285.*deg, anglepipeboxsmall);
    G4Tubs *pboxpipesmall7 = new G4Tubs("boxpipesmall7", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 180.*deg+anglepipebox-anglepipeboxsmall, anglepipeboxsmall);
    G4Tubs *pboxpipesmall8 = new G4Tubs("boxpipesmall8", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 180.*deg-anglepipebox-anglepipeboxsmall,anglepipeboxsmall);
    G4Tubs *pboxpipesmall9 = new G4Tubs("boxpipesmall9", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 225.*deg, anglepipeboxsmall);
    G4Tubs *pboxpipesmall10 = new G4Tubs("boxpipesmall10", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 260.*deg,anglepipeboxsmall);
    G4Tubs *pboxpipesmall11 = new G4Tubs("boxpipesmall11", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 135.*deg, anglepipeboxsmall);
    G4Tubs *pboxpipesmall12 = new G4Tubs("boxpipesmall12", Rmax_cylinder, Rmax_cylinder+y_pipe_box_1, z_pipe_box_1, 100.*deg,anglepipeboxsmall);

    G4Tubs *pcylinderscrew1= new G4Tubs("screw1",0,R_cyl_screw_1, height_cyl_screw_1, 0.*deg, 360.*deg);
    G4Tubs *pcylinderscrew2= new G4Tubs("screw2",0,R_cyl_screw_2, height_cyl_screw_2, 0.*deg, 360.*deg);
    G4ThreeVector screwunionvec (0,0,height_cyl_screw_1+height_cyl_screw_2);
    G4UnionSolid *screwunion = new G4UnionSolid("screwunion",pcylinderscrew1, pcylinderscrew2,0,screwunionvec);
    
    G4RotationMatrix *Rotflange = new G4RotationMatrix;
    Rotflange->rotateX(90.*deg);
    G4RotationMatrix *Rotflangeopp = new G4RotationMatrix;
    Rotflangeopp->rotateX(-90.*deg);
    G4ThreeVector screwoffset(0,R_base+height_cyl_screw_1,0);
    G4RotationMatrix *Rotflange1 = new G4RotationMatrix;
    Rotflange1->rotateY(-90.*deg);
    G4ThreeVector screwoffset1(R_base+height_cyl_screw_1,0,0);
    G4RotationMatrix *Rotflangeopp1 = new G4RotationMatrix;
    Rotflangeopp1->rotateY(90.*deg);
    
    G4UnionSolid *flangescrew = new G4UnionSolid("flangescrew",pcylinderbase, screwunion,Rotflange,screwoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, screwunion,Rotflangeopp,-screwoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, screwunion,Rotflange1,screwoffset1);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, screwunion,Rotflangeopp1,-screwoffset1);
    
    G4ThreeVector plateoffset(0,0,base_height+34.*mm+h_plate);
    G4ThreeVector platelowoffset(0,0,base_height+106.5*mm+h_plate_low);
    
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pcylinder_plate_small,0,plateoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pcylinder_plate_small,0,-plateoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pcylinder_plate_low_small,0,-platelowoffset);
    
    G4ThreeVector boxoffset(0,0,-base_height+10.*mm);
    
    G4ThreeVector boxoffset1(0,0,base_height+5.*mm);
    
    G4ThreeVector smallboxoffset(0,0,base_height+40.*mm+z_pipe_box_1);
    
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe,0,boxoffset1);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe1,0,boxoffset1);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe2,0,boxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe3,0,boxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe4,0,boxoffset1);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe5,0,boxoffset1);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe6,0,boxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipe7,0,boxoffset);
    
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall1,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall2,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall3,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall4,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall5,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall6,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall7,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall8,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall9,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall10,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall11,0,smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall12,0,smallboxoffset);
    
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall1,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall2,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall3,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall4,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall5,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall6,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall7,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall8,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall9,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall10,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall11,0,-smallboxoffset);
    flangescrew = new G4UnionSolid("flangescrew",flangescrew, pboxpipesmall12,0,-smallboxoffset);
    

    
   
    
    m_pPipeCylinderSmallSSLogicalVolume = new G4LogicalVolume(pcylindersmallpipe, SS316Ti, "Cylinder_SS");
    m_pPipeCylinderAirSmallLogicalVolume = new G4LogicalVolume(pcylinder_smallpipeair, Vacuum, "Cylinder_vacuum");
    m_pPipeTorusSmallSSLogicalVolume = new G4LogicalVolume(ptorus_external_small, SS316Ti, "Torus_SS");
    m_pPipeTorusAirSmallLogicalVolume = new G4LogicalVolume(ptorus_smallpipe_air, Vacuum, "Torus_vacuum");
    m_pPipeCylinderTiltedLongSmallSSLogicalVolume = new G4LogicalVolume(pcylinder_long_small_pipe, SS316Ti, "Cylinder_Tilted_SS");
    m_pPipeCylinderTiltedLongAirSmallLogicalVolume = new G4LogicalVolume(pcylinder_long_air_small_pipe, Vacuum, "Cylinder_Tilted_vacuum");
    m_pPipeBaseSmallLogicalVolume= new G4LogicalVolume(pcylinderbasesmallpipe, SS316Ti, "Base");


    
    //logical volume cryogenics pipe
    
    m_pPipeTolonLogicalVolume = new G4LogicalVolume(pcylindertolon, Torlon, "Cylinder_SS");
    m_pPipeCylinderSSLogicalVolume = new G4LogicalVolume(pcylinderexternaltubs, SS316Ti, "Cylinder_SS");
    m_pPipeCylinderAirLogicalVolume = new G4LogicalVolume(pcylinder_air, Vacuum, "Cylinder_vacuum");
    m_pPipeCylinderInternalSSLogicalVolume = new G4LogicalVolume(pcylinder_internal, SS316Ti, "Cylinder_SS");
    m_pPipeCylinderInternalSSLogicalVolume_1 = new G4LogicalVolume(pcylinder_internal_1, SS316Ti, "Cylinder_SS_1");
    m_pPipeCylinderInternalSSLogicalVolume_2 = new G4LogicalVolume(pcylinder_internal_2, SS316Ti, "Cylinder_SS_2");
    m_pPipeCylinderInternalSSLogicalVolume_3 = new G4LogicalVolume(pcylinder_internal_3, SS316Ti, "Cylinder_SS_3");
    m_pPipeCylinderInternalSSLogicalVolume_4 = new G4LogicalVolume(pcylinder_internal_4, SS316Ti, "Cylinder_SS_4");
    m_pPipeCylinderInternalSSLogicalVolume_5 = new G4LogicalVolume(pcylinder_internal_5, SS316Ti, "Cylinder_SS_5");
  
    m_pPipeCylinderLowSSLogicalVolume = new G4LogicalVolume(pcylinderexternal_low, SS316Ti, "Cylinder_SS");
    m_pPipeCylinderLowAirLogicalVolume = new G4LogicalVolume(pcylinder_air_low, Vacuum, "Cylinder_vacuum");
    m_pPipeCylinderInternalLowSSLogicalVolume = new G4LogicalVolume(pcylinder_internal_low, SS316Ti, "Cylinder_SS");
    m_pPipeCylinderInternalLowSSLogicalVolume_1 = new G4LogicalVolume(pcylinder_internal_low_1, SS316Ti, "Cylinder_SS_1");
    m_pPipeCylinderInternalLowSSLogicalVolume_2 = new G4LogicalVolume(pcylinder_internal_low_2, SS316Ti, "Cylinder_SS_2");
    m_pPipeCylinderInternalLowSSLogicalVolume_3 = new G4LogicalVolume(pcylinder_internal_low_3, SS316Ti, "Cylinder_SS_3");
    m_pPipeCylinderInternalLowSSLogicalVolume_4 = new G4LogicalVolume(pcylinder_internal_low_4, SS316Ti, "Cylinder_SS_4");
    m_pPipeCylinderInternalLowSSLogicalVolume_5 = new G4LogicalVolume(pcylinder_internal_low_5, SS316Ti, "Cylinder_SS_5");
    m_pPipeCylinderSmallStainSSLogicalVolume = new G4LogicalVolume(pcylinder_small_stain, SS316Ti, "Cylinder_Small_stain");
    
    
    m_pPipeTorusSSLogicalVolume = new G4LogicalVolume(ptorus_external, SS316Ti, "Torus_SS");
    m_pPipeTorusAirLogicalVolume = new G4LogicalVolume(ptorus_air, Vacuum, "Torus_vacuum");
    m_pPipeTorusInternalSSLogicalVolume = new G4LogicalVolume(ptorus_internal, SS316Ti, "Torus_SS");
    m_pPipeTorusInternalSSLogicalVolume_1 = new G4LogicalVolume(ptorus_internal_1, SS316Ti, "Torus_SS");
    m_pPipeTorusInternalSSLogicalVolume_2 = new G4LogicalVolume(ptorus_internal_2, SS316Ti, "Torus_SS");
    m_pPipeTorusInternalSSLogicalVolume_3 = new G4LogicalVolume(ptorus_internal_3, SS316Ti, "Torus_SS");
    m_pPipeTorusInternalSSLogicalVolume_4 = new G4LogicalVolume(ptorus_internal_4, SS316Ti, "Torus_SS");
    m_pPipeTorusInternalSSLogicalVolume_5 = new G4LogicalVolume(ptorus_internal_5, SS316Ti, "Torus_SS");
    m_pPipeTorusAirInternalLogicalVolume = new G4LogicalVolume(ptorus_air_internal, Vacuum, "Torus_vacuum_internal");
    
    m_pPipeCylinderTiltedLongSSLogicalVolume = new G4LogicalVolume(pcylinder_tilted_external_long, SS316Ti, "Cylinder_Tilted_SS");
    m_pPipeCylinderTiltedLongAirLogicalVolume = new G4LogicalVolume(pcylinder_tilted_air_long, Vacuum, "Cylinder_Tilted_vacuum");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume = new G4LogicalVolume(pcylinder_tilted_internal_long, SS316Ti, "Cylinder_Tilted_in_SS");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume_1 = new G4LogicalVolume(pcylinder_tilted_internal_long_1, SS316Ti, "Cylinder_Tilted_in_SS");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume_2 = new G4LogicalVolume(pcylinder_tilted_internal_long_2, SS316Ti, "Cylinder_Tilted_in_SS");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume_3 = new G4LogicalVolume(pcylinder_tilted_internal_long_3, SS316Ti, "Cylinder_Tilted_in_SS");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume_4 = new G4LogicalVolume(pcylinder_tilted_internal_long_4, SS316Ti, "Cylinder_Tilted_in_SS");
    m_pPipeCylinderTiltedLongInternalSSLogicalVolume_5 = new G4LogicalVolume(pcylinder_tilted_internal_long_5, SS316Ti, "Cylinder_Tilted_in_SS");
    
    
    m_pPipeBaseLogicalVolume= new G4LogicalVolume(flangescrew, SS316Ti, "Base");
    m_pPipeBaseInternalLogicalVolume= new G4LogicalVolume(pcylinderbase_internal, SS316Ti, "Base");
    m_pPipeBaseInternal1LogicalVolume= new G4LogicalVolume(pcylinderbase_internal_1, SS316Ti, "Base");
    m_pPipeBaseInternal2LogicalVolume= new G4LogicalVolume(pcylinderbase_internal_2, SS316Ti, "Base");
    m_pPipeBaseInternal3LogicalVolume= new G4LogicalVolume(pcylinderbase_internal_3, SS316Ti, "Base");
    m_pPipeBaseInternal4LogicalVolume= new G4LogicalVolume(pcylinderbase_internal_4, SS316Ti, "Base");
    m_pPipeBaseInternal5LogicalVolume= new G4LogicalVolume(pcylinderbase_internal_5, SS316Ti, "Base");
   

  //  m_pPipeBaseHalfLogicalVolume= new G4LogicalVolume(flangescrew2, SS316Ti, "Base");
    
//m_pPipeBaseInternalLogicalVolume= new G4LogicalVolume(pcylinderbase_internal, SS316Ti, "Base");
    
    
    
    //position of the physical volumes of the central pipe.
    
    G4double x_base_small = 450.;
    G4double y_base_small = 260.;
    G4double z_base_small = 1180.1*mm+cryo_offset+base_height_small; //-3.85
    G4double z_cylinder_small = 1180.1*mm+cryo_offset+cylinder_height_small_pipe;
    G4double z_torus_small = z_cylinder_small + cylinder_height_small_pipe;
    G4double y_torus_small = y_base_small-torus_radius_small_pipe;
    G4double y_cylinder_tilted_long_small = y_torus_small - cylinder_long_height_small_pipe*cos(90.*deg-torus_angle)+torus_radius_small_pipe*sin(90.*deg-torus_angle);
    G4double z_cylinder_tilted_long_small = z_torus_small + cylinder_long_height_small_pipe*sin(90.*deg-torus_angle)+torus_radius_small_pipe*cos(90.*deg-torus_angle);

    
    
    G4double x_base_low = 0.;
    G4double y_base_low = 0.;
    G4double z_base_low = 1261.1*mm+cryo_offset+base_height+2.*cylinder_height_low; //-3.85
    G4double y_cylinder = 0.;
    G4double x_cylinder_external = 0.;
    G4double y_cylinder_external = 0.;
    G4double x_cylinder_internal_1 = x_offset_internal_1;
    G4double y_cylinder_internal_1 = y_offset_internal_1;
    G4double x_cylinder_internal_2 = x_offset_internal_2;
    G4double y_cylinder_internal_2 = y_offset_internal_2;
    G4double x_cylinder_internal_3 = x_offset_internal_3;
    G4double y_cylinder_internal_3 = y_offset_internal_3;
    G4double x_cylinder_internal_4 = x_offset_internal_4;
    G4double y_cylinder_internal_4 = y_offset_internal_4;
    G4double x_cylinder_internal_5 = x_offset_internal_5;
    G4double y_cylinder_internal_5 = y_offset_internal_5;
   
    
    G4double z_cylinder = 1261.1*mm+cryo_offset+cylinder_height+2.*cylinder_height_low;
    G4double z_cylinder_low = 1261.1*mm+cryo_offset+cylinder_height_low;
   
    G4double z_torus = z_cylinder + cylinder_height;
    G4double y_torus = y_cylinder-torus_swept_radius;
    G4double x_torus =0.;
   // G4double z_torus_internal_1 = z_cylinder + cylinder_height;
   // G4double y_torus_internal_1 = y_cylinder-torus_swept_radius;
    G4double x_torus_internal_1 =x_offset_internal_1;
    //G4double z_torus_internal_2 = z_cylinder + cylinder_height;
   // G4double y_torus_internal_2 = y_cylinder-torus_swept_radius;
    G4double x_torus_internal_2 =x_offset_internal_2;
        G4double y_torus_internal_3 = y_offset_internal_3+(-torus_swept_radius_internal3+torus_swept_radius);//-Rmax_cylinder_internal_3-(-torus_swept_radius_internal3+torus_swept_radius)*cos(85.*deg);//+torus_swept_radius_internal3-torus_swept_radius;
    G4double x_torus_internal_3 =x_offset_internal_3;
    
    G4double y_torus_internal_4 = y_offset_internal_4+(-torus_swept_radius_internal4+torus_swept_radius);
    G4double x_torus_internal_4 =x_offset_internal_4;
    
    G4double y_torus_internal_5 = y_offset_internal_5+(-torus_swept_radius_internal5+torus_swept_radius);
    G4double x_torus_internal_5 = x_offset_internal_5;
    
    
    
        G4RotationMatrix *Rot_torus = new G4RotationMatrix;
    Rot_torus->rotateX(270.*deg);
    Rot_torus->rotateY(270.*deg);

    
    G4double y_cylinder_tilted_long = y_torus - cylinder_tilted_height_long*cos(90.*deg-torus_angle)+torus_swept_radius*sin(90.*deg-torus_angle);
    G4double x_cylinder_tilted_long = 0.*mm;
    G4double z_cylinder_tilted_long = z_torus + cylinder_tilted_height_long*sin(90.*deg-torus_angle) +torus_swept_radius*cos(90.*deg-torus_angle);
   /* G4double y_cylinder_tilted_long_internal_1 = y_torus_internal_1 - cylinder_tilted_height_long*cos(90.*deg-torus_angle)+torus_swept_radius*sin(90.*deg-torus_angle);
    G4double x_cylinder_tilted_long_internal_1 = x_offset_internal_1;
    G4double z_cylinder_tilted_long_internal_1 = z_torus_internal_1 + cylinder_tilted_height_long*sin(90.*deg-torus_angle) +torus_swept_radius*cos(90.*deg-torus_angle);
    G4double y_cylinder_tilted_long_internal_2 = y_torus_internal_2 - cylinder_tilted_height_long*cos(90.*deg-torus_angle)+torus_swept_radius*sin(90.*deg-torus_angle);
    G4double x_cylinder_tilted_long_internal_2 = x_offset_internal_2;
    G4double z_cylinder_tilted_long_internal_2 = z_torus_internal_2 + cylinder_tilted_height_long*sin(90.*deg-torus_angle) +torus_swept_radius*cos(90.*deg-torus_angle);
  */
    G4double y_cylinder_tilted_long_internal_3 = y_offset_internal_3; //-(y_torus_internal_3 +torus_swept_radius_internal3*sin(90.*deg-torus_angle));
   // G4double x_cylinder_tilted_long_internal_3 = x_offset_internal_3;
    G4double z_cylinder_tilted_long_internal_3 = 0.;//-(torus_swept_radius_internal3*cos(90.*deg-torus_angle));
    
    
    
    G4double y_base_tilt = y_cylinder_tilted_long - (cylinder_tilted_height_long-200.)*cos(90.*deg-torus_angle) - 0.5*base_height*cos(90.*deg-torus_angle);
    G4double x_base_tilt = 0.;
    G4double z_base_tilt = z_cylinder_tilted_long + (cylinder_tilted_height_long-200.)*sin(90.*deg-torus_angle) + 0.5*base_height*sin(90.*deg-torus_angle);
    
    G4RotationMatrix *Rot_cyl = new G4RotationMatrix;
    Rot_cyl->rotateX(-torus_angle);
    G4RotationMatrix *Rot_cyl1 = new G4RotationMatrix;
    Rot_cyl1->rotateX(-torus_angle+180.*deg);
    G4RotationMatrix *Rot_small_stain = new G4RotationMatrix;
    Rot_small_stain->rotateX(135.*deg);
    
    //Physical volume central pipe
    
    m_pPipeTolonPhysicalVolume1 = new G4PVPlacement(0, G4ThreeVector(0., 0., -27.5*mm), m_pPipeTolonLogicalVolume, "Pipe_Torlon_external", m_pPipeCylinderAirLogicalVolume, false, 0);
    
   m_pPipeBaseLowPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_base_low, y_base_low, z_base_low), m_pPipeBaseLogicalVolume, "Pipe_SS_Flange_Base", m_pMotherLogicalVolume, false, 0);
    m_pPipeCylinderInternalSSPhysicalVolume_1 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_1, y_cylinder_internal_1, 0.), m_pPipeCylinderInternalSSLogicalVolume_1, "Pipe_SS_cylinder_internal_SS_1", m_pPipeCylinderAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalSSPhysicalVolume_2 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_2, y_cylinder_internal_2, 0.), m_pPipeCylinderInternalSSLogicalVolume_2, "Pipe_SS_cylinder_internal_SS_2", m_pPipeCylinderAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalSSPhysicalVolume_3 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_3, y_cylinder_internal_3, 0.), m_pPipeCylinderInternalSSLogicalVolume_3, "Pipe_SS_cylinder_internal_SS_3", m_pPipeCylinderAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalSSPhysicalVolume_4 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_4, y_cylinder_internal_4, 0.), m_pPipeCylinderInternalSSLogicalVolume_4, "Pipe_SS_cylinder_internal_SS_4", m_pPipeCylinderAirLogicalVolume, false, 0);
        m_pPipeCylinderInternalSSPhysicalVolume_5 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_5, y_cylinder_internal_5, 0.), m_pPipeCylinderInternalSSLogicalVolume_5, "Pipe_SS_cylinder_internal_SS_5", m_pPipeCylinderAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0., 0.), m_pPipeCylinderInternalSSLogicalVolume, "Pipe_SS_cylinder_internal_SS", m_pPipeCylinderAirLogicalVolume, false, 0);
 /*   m_pPipeBaseLowInternalPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,-cylinder_height+base_height_internal), m_pPipeBaseInternalLogicalVolume, "Pipe_Flange_Base_internal", m_pPipeCylinderAirLogicalVolume, false, 0);//+52.mm donato indication
      m_pPipeBaseLowInternal1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_1,y_cylinder_internal_1,-cylinder_height+base_height_internal), m_pPipeBaseInternal1LogicalVolume, "Pipe_Flange_Base_internal_1", m_pPipeCylinderAirLogicalVolume, false, 0);
m_pPipeBaseLowInternal2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_2,y_cylinder_internal_2,-cylinder_height+base_height_internal), m_pPipeBaseInternal2LogicalVolume, "Pipe_Flange_Base_internal_2", m_pPipeCylinderAirLogicalVolume, false, 0);
      m_pPipeBaseLowInternal3PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_3,y_cylinder_internal_3,-cylinder_height+base_height_internal), m_pPipeBaseInternal3LogicalVolume, "Pipe_Flange_Base_internal_3", m_pPipeCylinderAirLogicalVolume, false, 0);
m_pPipeBaseLowInternal4PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_4,y_cylinder_internal_4,-cylinder_height+base_height_internal), m_pPipeBaseInternal4LogicalVolume, "Pipe_Flange_Base_internal_4", m_pPipeCylinderAirLogicalVolume, false, 0);
m_pPipeBaseLowInternal5PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_5,y_cylinder_internal_5,-cylinder_height+base_height_internal), m_pPipeBaseInternal5LogicalVolume, "Pipe_Flange_Base_internal_5", m_pPipeCylinderAirLogicalVolume, false, 0);*/
    
m_pPipeCylinderAirPhysicalVolume =new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), m_pPipeCylinderAirLogicalVolume, "Pipe_Air_cylinder_external_vacuum", m_pPipeCylinderSSLogicalVolume, false, 0);
    m_pPipeCylinderSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_external, y_cylinder_external, z_cylinder), m_pPipeCylinderSSLogicalVolume, "Pipe_SS_cylinder_external_SS", m_pMotherLogicalVolume, false, 0);
    
    
    m_pPipeCylinderInternalLowSSPhysicalVolume_1 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_1, y_cylinder_internal_1, 0.), m_pPipeCylinderInternalLowSSLogicalVolume_1, "Pipe_SS_cylinder_low_internal_SS_1", m_pPipeCylinderLowAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalLowSSPhysicalVolume_2 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_2, y_cylinder_internal_2, 0.), m_pPipeCylinderInternalLowSSLogicalVolume_2, "Pipe_SS_cylinder_low_internal_SS_2", m_pPipeCylinderLowAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalLowSSPhysicalVolume_3 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_3, y_cylinder_internal_3, 0.), m_pPipeCylinderInternalLowSSLogicalVolume_3, "Pipe_SS_cylinder_low_internal_SS_3", m_pPipeCylinderLowAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalLowSSPhysicalVolume_4 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_4, y_cylinder_internal_4, 0.), m_pPipeCylinderInternalLowSSLogicalVolume_4, "Pipe_SS_cylinder_low_internal_SS_4", m_pPipeCylinderLowAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalLowSSPhysicalVolume_5 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_internal_5, y_cylinder_internal_5, 0.), m_pPipeCylinderInternalLowSSLogicalVolume_5, "Pipe_SS_cylinder_low_internal_SS_5", m_pPipeCylinderLowAirLogicalVolume, false, 0);
    m_pPipeCylinderInternalLowSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0., 0.), m_pPipeCylinderInternalLowSSLogicalVolume, "Pipe_SS_cylinder_low_internal_SS", m_pPipeCylinderLowAirLogicalVolume, false, 0);

    m_pPipeCylinderLowAirPhysicalVolume =new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), m_pPipeCylinderLowAirLogicalVolume, "Pipe_Air_cylinder_low_external_vacuum", m_pPipeCylinderLowSSLogicalVolume, false, 0);
    m_pPipeCylinderLowSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_cylinder_external, y_cylinder_external, z_cylinder_low), m_pPipeCylinderLowSSLogicalVolume, "Pipe_SS_cylinder_low_external_SS", m_pMotherLogicalVolume, false, 0);

    
    
    
    m_pPipeCylinderSmallStainSSPhysicalVolume1 = new G4PVPlacement(0, G4ThreeVector(x_cylinder_external, y_cylinder_external, z_cylinder+cylinder_height-height_small_stain), m_pPipeCylinderSmallStainSSLogicalVolume, "Pipe_SS_cylinder_Small_stain_1", m_pMotherLogicalVolume, false, 0);
    m_pPipeCylinderSmallStainSSPhysicalVolume3 = new G4PVPlacement(Rot_cyl, G4ThreeVector(x_cylinder_tilted_long, y_torus-height_small_stain*cos(90.*deg-torus_angle)+torus_swept_radius*sin(90.*deg-torus_angle), z_torus+torus_swept_radius*cos(90.*deg-torus_angle)+height_small_stain*sin(90.*deg-torus_angle)), m_pPipeCylinderSmallStainSSLogicalVolume, "Pipe_SS_cylinder_Small_stain_3", m_pMotherLogicalVolume, false, 0);
    // m_pPipeCylinderSmallStainSSPhysicalVolume2 = new G4PVPlacement(Rot_small_stain, G4ThreeVector(x_cylinder_tilted_long, y_torus-height_small_stain*cos(45.*deg)+torus_swept_radius*sin(45.*deg), z_torus+torus_swept_radius*cos(45.*deg)+height_small_stain*sin(45.*deg)), m_pPipeCylinderSmallStainSSLogicalVolume, "Pipe_cylinder_Small_stain_2", m_pMotherLogicalVolume, false, 0);
    

    
    
    
    
    
    m_pPipeTorusInternalSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), m_pPipeTorusInternalSSLogicalVolume, "Pipe_SS_Torus_internal_SS", m_pPipeTorusAirLogicalVolume, false, 0);
   m_pPipeTorusInternalSSPhysicalVolume_1 = new G4PVPlacement(0, G4ThreeVector(0.,0., x_torus_internal_1), m_pPipeTorusInternalSSLogicalVolume_1, "Pipe_SS_Torus_internal_SS_1", m_pPipeTorusAirLogicalVolume, false, 0);
    m_pPipeTorusInternalSSPhysicalVolume_2 = new G4PVPlacement(0, G4ThreeVector(0.,0.,x_torus_internal_2), m_pPipeTorusInternalSSLogicalVolume_2, "Pipe_SS_Torus_internal_SS_2",m_pPipeTorusAirLogicalVolume, false, 0);
    m_pPipeTorusInternalSSPhysicalVolume_3 = new G4PVPlacement(0, G4ThreeVector(y_torus_internal_3,0., x_torus_internal_3), m_pPipeTorusInternalSSLogicalVolume_3, "Pipe_SS_Torus_internal_SS_3", m_pPipeTorusAirLogicalVolume, false, 0);
   m_pPipeTorusInternalSSPhysicalVolume_4 = new G4PVPlacement(0, G4ThreeVector(y_torus_internal_4,0.,x_torus_internal_4), m_pPipeTorusInternalSSLogicalVolume_4, "Pipe_SS_Torus_internal_SS_4",m_pPipeTorusAirLogicalVolume, false, 0);
        m_pPipeTorusInternalSSPhysicalVolume_5 = new G4PVPlacement(0, G4ThreeVector(y_torus_internal_5,0,x_torus_internal_5), m_pPipeTorusInternalSSLogicalVolume_5, "Pipe_SS_Torus_internal_SS_5",m_pPipeTorusAirLogicalVolume, false, 0);
    
    
    m_pPipeTorusAirPhysicalVolume =new G4PVPlacement(Rot_torus, G4ThreeVector(x_torus, y_torus, z_torus), m_pPipeTorusAirLogicalVolume, "Pipe_Air_Torus_external_vacuum", m_pMotherLogicalVolume, false, 0);

    
    
    
    m_pPipeTorusSSPhysicalVolume = new G4PVPlacement(Rot_torus, G4ThreeVector(x_torus, y_torus, z_torus), m_pPipeTorusSSLogicalVolume, "Pipe_SS_Torus_external_SS", m_pMotherLogicalVolume, false, 0);
    
    m_pPipeTolonPhysicalVolume2 = new G4PVPlacement(0, G4ThreeVector(0., 0., -2200.+235.), m_pPipeTolonLogicalVolume, "Pipe_Torlon_external_SS_2", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
     m_pPipeTolonPhysicalVolume3 = new G4PVPlacement(0, G4ThreeVector(0., 0., -2200.+1414.), m_pPipeTolonLogicalVolume, "Pipe_Torlon_external_SS_3", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
     m_pPipeTolonPhysicalVolume4 = new G4PVPlacement(0, G4ThreeVector(0., 0., -2200.+2615.), m_pPipeTolonLogicalVolume, "Pipe_Torlon_external_SS_4", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
     m_pPipeTolonPhysicalVolume5 = new G4PVPlacement(0, G4ThreeVector(0., 0., -2200.+3820.), m_pPipeTolonLogicalVolume, "Pipe_Torlon_external_SS_5", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    
  
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pPipeCylinderTiltedLongInternalSSLogicalVolume, "Pipe_SS_cylinder_tilted_long_internal_SS", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_1 = new G4PVPlacement(0, G4ThreeVector(x_offset_internal_1,0.,0.), m_pPipeCylinderTiltedLongInternalSSLogicalVolume_1, "Pipe_SS_cylinder_tilted_long_internal_SS_1", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_2 = new G4PVPlacement(0, G4ThreeVector(x_offset_internal_2,0.,0.), m_pPipeCylinderTiltedLongInternalSSLogicalVolume_2, "Pipe_SS_cylinder_tilted_long_internal_SS_2", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_3 = new G4PVPlacement(0, G4ThreeVector(x_offset_internal_3,y_cylinder_tilted_long_internal_3,z_cylinder_tilted_long_internal_3), m_pPipeCylinderTiltedLongInternalSSLogicalVolume_3, "Pipe_SS_cylinder_tilted_long_internal_SS_3", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_4 = new G4PVPlacement(0, G4ThreeVector(x_offset_internal_4,y_offset_internal_4,0.), m_pPipeCylinderTiltedLongInternalSSLogicalVolume_4, "Pipe_SS_cylinder_tilted_long_internal_SS_4", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_5 = new G4PVPlacement(0, G4ThreeVector(x_offset_internal_5,y_offset_internal_5,0.), m_pPipeCylinderTiltedLongInternalSSLogicalVolume_5, "Pipe_SS_cylinder_tilted_long_internal_SS_5", m_pPipeCylinderTiltedLongAirLogicalVolume, false, 0);
    
    
    m_pPipeCylinderTiltedLongAirPhysicalVolume =new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pPipeCylinderTiltedLongAirLogicalVolume, "Pipe_Air_cylinder_tilted_external_long_vacuum", m_pPipeCylinderTiltedLongSSLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongSSPhysicalVolume = new G4PVPlacement(Rot_cyl, G4ThreeVector(x_cylinder_tilted_long, y_cylinder_tilted_long, z_cylinder_tilted_long), m_pPipeCylinderTiltedLongSSLogicalVolume, "Pipe_SS_cylinder_Tilted_long_external_SS", m_pMotherLogicalVolume, false, 0);
    
    m_pPipeBaseHalfPhysicalVolume = new G4PVPlacement(Rot_cyl1, G4ThreeVector(x_base_tilt, y_base_tilt, z_base_tilt), m_pPipeBaseLogicalVolume, "Pipe_SS_Flange_cylinder", m_pMotherLogicalVolume, false, 0);
    
    //small pipe
    
     m_pPipeBaseSmallLowPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_base_small, y_base_small, z_base_small), m_pPipeBaseSmallLogicalVolume, "Pipe_SS_Small_Flange_Base", m_pMotherLogicalVolume, false, 0);
    m_pPipeCylinderAirSmallPhysicalVolume =new G4PVPlacement(0, G4ThreeVector(0., 0., 0.), m_pPipeCylinderAirSmallLogicalVolume, "Pipe_Air_cylinder_external_small_vacuum", m_pPipeCylinderSmallSSLogicalVolume, false, 0);
    m_pPipeCylinderSmallSSPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(x_base_small, y_base_small, z_cylinder_small), m_pPipeCylinderSmallSSLogicalVolume, "Pipe_SS_cylinder_external_small_SS", m_pMotherLogicalVolume, false, 0);
    m_pPipeTorusAirSmallPhysicalVolume =new G4PVPlacement(Rot_torus, G4ThreeVector(x_base_small, y_torus_small, z_torus_small), m_pPipeTorusAirSmallLogicalVolume, "Pipe_Air_Torus_external_small_vacuum", m_pMotherLogicalVolume, false, 0);
    
    m_pPipeTorusSmallSSPhysicalVolume = new G4PVPlacement(Rot_torus, G4ThreeVector(x_base_small, y_torus_small, z_torus_small), m_pPipeTorusSmallSSLogicalVolume, "Pipe_SS_Torus_external_small_SS", m_pMotherLogicalVolume, false, 0);
    
    m_pPipeCylinderTiltedLongAirSmallPhysicalVolume =new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pPipeCylinderTiltedLongAirSmallLogicalVolume, "Pipe_Air_cylinder_tilted_external_long_small_vacuum", m_pPipeCylinderTiltedLongSmallSSLogicalVolume, false, 0);
    m_pPipeCylinderTiltedLongSmallSSPhysicalVolume = new G4PVPlacement(Rot_cyl, G4ThreeVector(x_base_small, y_cylinder_tilted_long_small, z_cylinder_tilted_long_small), m_pPipeCylinderTiltedLongSmallSSLogicalVolume, "Pipe_SS_cylinder_Tilted_long_external_small_SS", m_pMotherLogicalVolume, false, 0);
    
    
}



G4UnionSolid * 
Xenon1tDetectorConstruction::ConstructVessel(G4double D, G4double L, G4double R0top, G4double R1top, G4double R0bot, G4double R1bot,
                                             G4double TopCor, G4double BotCor,
                                             G4double dR_Flange, G4double h_Flange, G4double z_Flange, G4bool doBottom){
  //
  // ConstructVessel: - a la Columbia University - Gordon Tajiri
  //                  - vessel with two toro-spherical heads. 
  //                  
  // Input: 
  //        D          = cylinder diameter
  //        L          = cylinder length of the vessel
  //        R0top      = top spherical radius
  //        R1top      = top toroid radius
  //        R0bot      = bottom spherical radius
  //        R1bot      = bottom toroid radius
  //        TopCor     = correction for thicker/thinner top head 
  //        BotCor     = correction for thicker/thinner bottom head of vessel
  //        dR_Flange  = dR of flange
  //        h_Flange   = height of flange
  //        z_Flange   = z position of flange
  //        doBottom   = make the bottom torospherical head or not
  //
  // A.P.Colijn 08-03-2012 / colijn@nikhef.nl
  //
  
  // radius of vessel
  G4double R_cyl = D/2;
  
  //
  // Cylindrical body with flange. Don't compose of 2xG4Tubs, since you will run
  // into geant4 visualization problems/issues/features ....
  //
  G4double ZZ[]     = {-L/2, z_Flange-h_Flange/2-0.001*cm, z_Flange-h_Flange/2, z_Flange+h_Flange/2, z_Flange+h_Flange/2+0.001*cm, L/2};
  G4double RRin[]   = {0, 0, 0, 0, 0, 0};
  G4double RRout[]  = {R_cyl, R_cyl, R_cyl+dR_Flange, R_cyl+dR_Flange, R_cyl, R_cyl};
  
  G4Polycone *pTube = new G4Polycone("Tube", 0., 2*M_PI, 6, ZZ, RRin, RRout);
  //
  // help variables to calculate coordinates of cone and torus
  //
  // For the bottom
  G4double rc0 = R_cyl-R1bot-BotCor;
  G4double dR0 = R0bot-R1bot;
  
  G4double dTheta_bot = asin(rc0/dR0);
  G4double dZ_bot     = sqrt(dR0*dR0 - rc0*rc0) ;
  
  //
  // Torospherical bottom 
  //
  G4cout <<"BOTTOM: R_cyl="<<R_cyl<< "  R1bot= " <<R1bot<<" rc0="<<rc0<<" dR0="<<dR0<<" dTheta="<<dTheta_bot<<" dZ="<<dZ_bot<<G4endl;
  
  G4Sphere *pBottom1 = new G4Sphere("Bottom1", 0.6*R0bot, R0bot, 0., 2*M_PI, M_PI-dTheta_bot, dTheta_bot);
  G4Torus  *pBottom2 = new G4Torus("Bottom2",0.*cm, R1bot, rc0, 0, 2*M_PI);
  
  //
  // Continue with the top head of the vessel ......
  // 
  rc0 = R_cyl-R1top-TopCor;
  dR0 = R0top-R1top;
  
  G4double dTheta_top = asin(rc0/dR0);
  G4double dZ_top     = sqrt(dR0*dR0 - rc0*rc0) ;
  
  G4cout <<"TOP   : R_cyl="<<R_cyl<< "  R1top= " <<R1top<<" rc0="<<rc0<<" dR0="<<dR0<<" dTheta="<<dTheta_top<<" dZ="<<dZ_top<<G4endl;
  
  G4Sphere *pTop1    = new G4Sphere("Top1", 0.6*R0top, R0top, 0., 2*M_PI, 0., dTheta_top);
  G4Torus  *pTop2    = new G4Torus("Top2",0.*cm, R1top, rc0, 0, 2*M_PI);
  
  //
  // Make one solid of the vessel components
  //
  G4UnionSolid *pVessel;
  
  G4double zPos = L/2;
  G4cout<< "TOP   : toroid zPos="<<zPos<<G4endl;
  pVessel = new G4UnionSolid("UnionSolid", pTube, pTop2, 0, G4ThreeVector(0.001*mm,0,zPos));
  zPos = L/2 - dZ_top;
  G4cout<< "TOP   : sphere zPos="<<zPos<<G4endl;
  pVessel = new G4UnionSolid("UnionSolid", pVessel, pTop1, 0, G4ThreeVector(0.001*mm,0,zPos));
        
  if(doBottom){
    zPos =  -L/2;
    G4cout<< "BOTTOM: toroid zPos="<<zPos<<G4endl;
    pVessel = new G4UnionSolid("UnionSolid", pVessel, pBottom2, 0, G4ThreeVector(0.001*mm,0,zPos));
    zPos = -L/2 + dZ_bot;
    G4cout<< "BOTTOM: sphere zPos="<<zPos<<G4endl;
    pVessel = new G4UnionSolid("UnionSolid", pVessel, pBottom1, 0, G4ThreeVector(0.001*mm,0,zPos));
  }
  
  return pVessel;
}


G4UnionSolid * 
Xenon1tDetectorConstruction::ConstructPillar()
{
  G4double dTopBoxbase_y     = GetGeometryParameter("TopBoxBase_y");
  G4double dTopBox_height    = GetGeometryParameter("TopBox_height");
  G4double dfieldringThickness = GetGeometryParameter("FieldShaperRingsHeight");
  
  G4double dTrapezoidbase_y1 = GetGeometryParameter("TrapezoidBase_y1");
  G4double dTrapezoidbase_y2 = GetGeometryParameter("TrapezoidBase_y2");
  G4double dTrapezoid_height = GetGeometryParameter("Trapezoid_height");
  
  G4double dBottomBoxbase_x  = GetGeometryParameter("BottomBoxBase_x");
  G4double dBottomBoxbase_y  = GetGeometryParameter("BottomBoxBase_y");
  G4double dBottomBox_height = GetGeometryParameter("BottomBox_height");
  
  G4Box *p_TopBox    = new G4Box("TopBox", dBottomBoxbase_x*0.5, dTopBoxbase_y*0.5, dTopBox_height*0.5);
  G4Trd *p_trapezoid = new G4Trd("Trd", dBottomBoxbase_x*0.5, dBottomBoxbase_x*0.5, dTrapezoidbase_y1*0.5, dTrapezoidbase_y2*0.5, dTrapezoid_height*0.5);
  G4Box *p_bottomBox = new G4Box("bottomBox", dBottomBoxbase_x*0.5, dBottomBoxbase_y*0.5, dBottomBox_height*0.5);
  
  G4double zPos;
  G4double yPos;
  G4UnionSolid *pPillar_1;
  
  zPos = -dTopBox_height*0.5 + dTrapezoid_height*0.5;
  yPos = (dTopBoxbase_y-dTrapezoidbase_y2)*0.5;
  pPillar_1 = new G4UnionSolid("UnionSolid", p_TopBox, p_trapezoid, 0, G4ThreeVector(0.,yPos,zPos));
  
  zPos = -dTopBox_height*0.5 + dTrapezoid_height*0.5 - dBottomBox_height*0.5;
  yPos = (dBottomBoxbase_y-dTopBoxbase_y)*0.5 + 4.*mm;
  pPillar_1 = new G4UnionSolid("UnionSolid", pPillar_1, p_bottomBox, 0, G4ThreeVector(0.,yPos,zPos));
  
  return pPillar_1;
}  
  

void
Xenon1tDetectorConstruction::ConstructColumbiaCryostat()
{  

  G4cout << "Xenon1tDetectorConstruction::ConstructColumbiaCryostat Building cryostat geometry" << G4endl;
  
  //
  // select the material for the titanium cryostat
  //
  G4Material *cryoMaterial = G4Material::GetMaterial(pCryostatMaterial);;
  G4Material *Vacuum       = G4Material::GetMaterial("Vacuum");
  G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");
  
  // //_____________________________________________________________________________
  G4double Rmax_cylinder_internal_lateral1 = GetGeometryParameter("Rmax_cylinder_internal_lateral_pipe");
  G4double Rmax_cylinder_internal_1 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_1");
  G4double Rmin_cylinder_internal_1 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_1");
  G4double Rmax_cylinder_internal_2 = GetGeometryParameter("Rmax_cylinder_internal_central_pipe_2");
  G4double Rmin_cylinder_internal_2 = GetGeometryParameter("Rmin_cylinder_internal_central_pipe_2");
  G4double Rmax_cylinder_internal_small1 = GetGeometryParameter("Rmax_cylinder_internal_small_pipe1");
  G4double Rmax_cylinder_small2 =  GetGeometryParameter("Rmax_cylinder_external_small_pipe2");
  G4double Rmin_cylinder_small2 =  GetGeometryParameter("Rmin_cylinder_external_small_pipe2");
  //_____________________________________________________________________________
  
  //
  // The OUTER vessel
  // 
  
  // outer hull
  G4double L         = GetGeometryParameter("OuterCryostatCylinderHeight");
  G4double D         = GetGeometryParameter("OuterCryostatOuterDiameter");
  G4double R0top     = GetGeometryParameter("OuterCryostatR0top");
  G4double R1top     = GetGeometryParameter("OuterCryostatR1top");
  G4double R0bot     = GetGeometryParameter("OuterCryostatR0bot");
  G4double R1bot     = GetGeometryParameter("OuterCryostatR1bot");
  
  G4double h_Flange  = GetGeometryParameter("OuterCryostatFlangeHeight");
  G4double z_Flange  = GetGeometryParameter("OuterCryostatFlangeZ");
  G4double dR_Flange = GetGeometryParameter("OuterCryostatFlangeThickness");
  
  G4cout<<G4endl;
  G4cout <<"OUTER VESSEL: L=" <<L<<" D="<<D<<" R0top="<<R0top<<" R1top="<<R1top<<" R0bot="<<R0bot<<" R1bot="<<R1bot<<G4endl;
  
  G4double zPos = GetGeometryParameter("OuterCryostatOffsetZ"); 
  
  G4UnionSolid *pOuterCryostatUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,0,0,dR_Flange,h_Flange,z_Flange,true);
  
  //____________________________ holes ______________________________________________________________________________________

  G4double cylinder_height = 0.5*76.96*mm;
  G4double cylinder_outer_radius = GetGeometryParameter("Rmax_cylinder_external_central_pipe");
  G4double cylinder_inner_radius = GetGeometryParameter("Rmax_cylinder_external_central_pipe") - GetGeometryParameter("Wall_thickness_central_external_pipe");
  G4Tubs *connection = new G4Tubs("Cylinder_external_SS", 0., cylinder_outer_radius, cylinder_height, 0.*deg, 360.*deg);
  pOuterCryostatUnionSolid = new G4UnionSolid("L", pOuterCryostatUnionSolid, connection, 0, G4ThreeVector(0,0,(1259.14+cylinder_height-75.)*mm));
  
  G4double x_base_small = 450.*mm;
  G4double y_base_small = 260.*mm;
  G4double Rmax_cylinder_small_pipe = 0.5*120.*mm;
  G4double small_pipe_height = 0.5*190.1*mm;
  G4Tubs *connection_small_pipe = new G4Tubs("Cylinder_lateral_SS", 0., Rmax_cylinder_small_pipe, small_pipe_height, 
					     0.*deg, 360.*deg);
  pOuterCryostatUnionSolid = new G4UnionSolid("L", pOuterCryostatUnionSolid, connection_small_pipe, 0,
					      G4ThreeVector(x_base_small, y_base_small, 990.*mm+small_pipe_height));
   
  // G4double cylinder_radius_small1 = 0.5*105.*mm;
  // G4double cylinder_height_small1 = 0.5*169.3*mm;
  // G4Tubs *connection_small1= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_small1,cylinder_height_small1, 0.*deg, 360.*deg);
  // pOuterCryostatUnionSolid = new G4UnionSolid("L", pOuterCryostatUnionSolid, connection_small1,0,G4ThreeVector(450.331,-260.,1015.*mm));
  
  // G4double cylinder_radius_small2 = 0.5*39.8*mm;
  // G4double cylinder_height_small2 = 0.5*350.*mm;
  // G4Tubs *connection_small2= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_small2,cylinder_height_small2, 0.*deg, 360.*deg);
  // pOuterCryostatUnionSolid = new G4UnionSolid("L", pOuterCryostatUnionSolid, connection_small2,0,G4ThreeVector(-450.331,-260.,1015.*mm));  
  //_________________________________________________________________________________________________________________________
  
  m_pOuterCryostatLogicalVolume = new G4LogicalVolume(pOuterCryostatUnionSolid, cryoMaterial, "OuterCryostatUnionSolid", 0, 0, 0);
  m_pOuterCryostatPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.*mm, 0.*mm, zPos),
                                                     m_pOuterCryostatLogicalVolume, "SS_OuterCryostat", m_pMotherLogicalVolume, false, 0);
  m_pMotherLogicalVolume = m_pOuterCryostatLogicalVolume;
    
  // inner hull
  L         = GetGeometryParameter("OuterCryostatCylinderHeight");
  D         = GetGeometryParameter("OuterCryostatOuterDiameter")-2*GetGeometryParameter("OuterCryostatThickness");
  R0top     = GetGeometryParameter("OuterCryostatR0top") - GetGeometryParameter("OuterCryostatThicknessTop");
  R1top     = GetGeometryParameter("OuterCryostatR1top") - GetGeometryParameter("OuterCryostatThicknessTop");
  R0bot     = GetGeometryParameter("OuterCryostatR0bot") - GetGeometryParameter("OuterCryostatThicknessBot");
  R1bot     = GetGeometryParameter("OuterCryostatR1bot") - GetGeometryParameter("OuterCryostatThicknessBot");
  G4double TopCor    = GetGeometryParameter("OuterCryostatThicknessTop")- GetGeometryParameter("OuterCryostatThickness");
  G4double BotCor    = GetGeometryParameter("OuterCryostatThicknessBot")- GetGeometryParameter("OuterCryostatThickness");
  
  G4cout<<G4endl;
  G4cout <<"ISO VACUUM  : L=" <<L<<" D="<<D<<" R0top="<<R0top<<" R1top="<<R1top<<" R0bot="<<R0bot<<" R1bot="<<R1bot<<G4endl;

  // G4double cylinder_radius_v = 0.5*204.*mm;
  // G4double cylinder_height_v = 0.5*189.*mm;
  
  G4UnionSolid *pOuterCryostatVacuumUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,TopCor,BotCor,0,0,0, true);
  
  //________________________________________________________________________________________________________________________

  // G4Tubs *connection_v= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_v,cylinder_height_v, 0.*deg, 360.*deg);
  // G4double cylinder_radius_center_small1_v = 0.5*102.*mm;
  // G4double cylinder_height_center_small1_v = 0.5*175.1*mm;
  // G4Tubs *connection_center_small1_v= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_center_small1_v,cylinder_height_center_small1_v, 0.*deg, 360.*deg);

  // G4double cylinder_radius_center_small2_v = 0.5*38.*mm;
  // G4double cylinder_height_center_small2_v = 0.5*355.9*mm;
  // G4Tubs *connection_center_small2_v= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_center_small2_v,
  // 						 cylinder_height_center_small2_v, 0.*deg, 360.*deg);
  // pOuterCryostatVacuumUnionSolid = new G4UnionSolid("L", pOuterCryostatVacuumUnionSolid, connection_v,0,
  // 						    G4ThreeVector(0,-375.,1025.*mm));  

  // G4double cylinder_height_center_v = 0.5*5.*mm;
  // G4Tubs *connection_center_v= new G4Tubs("Cylinder_external_SS",0., cylinder_inner_radius, cylinder_height_center_v, 0.*deg, 360.*deg);
  
  G4Tubs *connection_center_v = new G4Tubs("Cylinder_external_SS",0., cylinder_inner_radius, cylinder_height, 0.*deg, 360.*deg);
  pOuterCryostatVacuumUnionSolid = new G4UnionSolid("L", pOuterCryostatVacuumUnionSolid, connection_center_v, 0, 
						    G4ThreeVector(0,0,1259.14*mm+cylinder_height-75.*mm)); 
  
  G4double small_pipe_height_v = small_pipe_height + 13.*mm;
  G4double Rmin_cylinder_small_pipe = 0.5*(120.-3.)*mm;
  G4Tubs *samll_pipe_connection_v = new G4Tubs("Cylinder_small_SS",0., Rmin_cylinder_small_pipe, small_pipe_height_v, 0.*deg, 360.*deg);
  pOuterCryostatVacuumUnionSolid = new G4UnionSolid("L", pOuterCryostatVacuumUnionSolid, samll_pipe_connection_v, 0, 
   						    G4ThreeVector(x_base_small, y_base_small, 964.*mm+small_pipe_height_v)); 
  
  // G4double cylinder_radius_lateral_v = 0.5*50.*mm;
  // G4double cylinder_height_lateral_v = 0.5*98.*mm;
  // G4Tubs *connection_lateral_v= new G4Tubs("Cylinder_extlateral_SS",0., cylinder_radius_lateral_v,cylinder_height_lateral_v, 0.*deg, 360.*deg);
  // pOuterCryostatVacuumUnionSolid = new G4UnionSolid("L", pOuterCryostatVacuumUnionSolid, connection_lateral_v,0,
  //   						    G4ThreeVector(451.69*mm,451.69*mm,1090.*mm+cylinder_height_lateral_v));
  


  // pOuterCryostatVacuumUnionSolid = new G4UnionSolid("L", pOuterCryostatVacuumUnionSolid, connection_center_small2_v,0,
  // 						    G4ThreeVector(-450.331,-260.,1012.*mm));
  //___________________________________________________________________________________________________________________________________________

  m_pOuterCryostatVacuumLogicalVolume = new G4LogicalVolume(pOuterCryostatVacuumUnionSolid, Vacuum, "OuterCryostatVacuumUnionSolid", 0, 0, 0); 
  m_pOuterCryostatVacuumPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pOuterCryostatVacuumLogicalVolume, 
    							   "OuterCryostatVacuum", m_pMotherLogicalVolume, false, 0);    
  m_pMotherLogicalVolume = m_pOuterCryostatVacuumLogicalVolume;
    
  //
  // The INNER vessel
  //  
  
  // outer hull
  L         = GetGeometryParameter("InnerCryostatCylinderHeight");
  D         = GetGeometryParameter("InnerCryostatOuterDiameter");
  R0top     = GetGeometryParameter("InnerCryostatR0top");
  R1top     = GetGeometryParameter("InnerCryostatR1top");
  R0bot     = GetGeometryParameter("InnerCryostatR0bot");
  R1bot     = GetGeometryParameter("InnerCryostatR1bot");
  h_Flange  = GetGeometryParameter("InnerCryostatFlangeHeight");
  z_Flange  = GetGeometryParameter("InnerCryostatFlangeZ");
  dR_Flange = GetGeometryParameter("InnerCryostatFlangeThickness");
  G4cout<<G4endl;
  G4cout <<"INNER VESSEL: L=" <<L<<" D="<<D<<" R0top="<<R0top<<" R1top="<<R1top<<" R0bot="<<R0bot<<" R1bot="<<R1bot<<G4endl;
  
  // Define the Torospherical vessel.....
  
  zPos = GetGeometryParameter("InnerCryostatOffsetZ");
  
  // //_________________________ inner cryostat holes _____________________________________________________________________________
 
  G4UnionSolid *pInnerCryostatUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,0,0,dR_Flange,h_Flange,z_Flange,true);
  
  G4double cylinder_Outradius_innerConn = GetGeometryParameter("Rmax_cylinder_internal_central_big_pipe");
  G4double cylinder_Innradius_innerConn = GetGeometryParameter("Rmax_cylinder_internal_central_big_pipe") - GetGeometryParameter("Wall_thickness_central_internal_big_pipe");
  G4double cylinder_height_inner = 0.5*217.78*mm;
  G4Tubs *connection_inner= new G4Tubs("Cylinder_external_SS_4",0., cylinder_Outradius_innerConn, cylinder_height_inner, 0.*deg, 360.*deg);
  pInnerCryostatUnionSolid = new G4UnionSolid("L", pInnerCryostatUnionSolid, connection_inner, 0, G4ThreeVector(0.,0.,994.32*mm-47.*mm+cylinder_height_inner));
  
  Rmax_cylinder_small_pipe = GetGeometryParameter("Rmax_cylinder_small_pipe"); 
  G4double small_pipe_height_inner = small_pipe_height+0.5*178.*mm;
  G4Tubs *samll_pipe_connection_inner = new G4Tubs("Cylinder_small_SS",0., Rmax_cylinder_small_pipe, small_pipe_height_inner, 
   						   0.*deg, 360.*deg);
  pInnerCryostatUnionSolid = new G4UnionSolid("L", pInnerCryostatUnionSolid, samll_pipe_connection_inner, 
   					      0, G4ThreeVector(x_base_small, y_base_small, 716.*mm+small_pipe_height_inner));
  
  // G4RotationMatrix *RotPiece = new G4RotationMatrix;
  // RotPiece->rotateX(180.*deg);
  // G4double cylinder_height_inner_lateral=190.8*mm;
  // G4double cylinder_height_inner_small1=170.8*mm;
  // G4Tubs *connection_inner_lateral= new G4Tubs("Cylinder_external_SS_4ca",0., Rmax_cylinder_internal_lateral1, cylinder_height_inner_lateral, 0.*deg, 360.*deg);
  // G4Tubs *connection_inner_small1= new G4Tubs("Cylinder_external_SS_4",0., Rmax_cylinder_internal_small1  ,cylinder_height_inner_small1, 0.*deg, 360.*deg);
  
  // G4double cylinder_height_central_inner_air = 0.5*1936.8*mm;
  // G4double cylinder_radius_central_inner_air = 0.5*203.*mm;
  // G4Tubs *pcylinder_connection_air_central_inner = new G4Tubs("Cylinder_vacuum", 0., cylinder_radius_central_inner_air, cylinder_height_central_inner_air, 0.*deg, 360.*deg);
  // G4Tubs *pcylinder_connection_internal_1_central_inner = new G4Tubs("Cylinder_internal_SS_1", Rmin_cylinder_internal_1, Rmax_cylinder_internal_1, cylinder_height_central_inner_air, 0.*deg, 360.*deg);
  // G4Tubs *pcylinder_connection_internal_2_central_inner = new G4Tubs("Cylinder_internal_SS_2", Rmin_cylinder_internal_2, Rmax_cylinder_internal_2, cylinder_height_central_inner_air, 0.*deg, 360.*deg);
  
  // G4ThreeVector zTrans_central_inner_1(0*mm, 0.*mm,-200.*mm);
  
  // //right shape to fit with the inner cryostat. I need a subtraction solid
  
  // G4SubtractionSolid *connection_internal_1_central_inner = new G4SubtractionSolid ("H", pcylinder_connection_internal_1_central_inner, pInnerCryostatUnionSolid,0,zTrans_central_inner_1);
  // G4SubtractionSolid *connection_internal_2_central_inner = new G4SubtractionSolid ("H", pcylinder_connection_internal_2_central_inner, pInnerCryostatUnionSolid,0,zTrans_central_inner_1);
  // G4SubtractionSolid *connection_air_central_inner = new G4SubtractionSolid ("H", pcylinder_connection_air_central_inner, pInnerCryostatUnionSolid,0,zTrans_central_inner_1); 
  
  // G4double cylinder_height_central_inner_small1 = 0.5*1757.1*mm;
  // G4ThreeVector zTrans_central_inner_small1(450.331*mm, -260.*mm,-200.*mm);
  // G4Tubs *pcylinder_connection_air_central_inner_small1 = new G4Tubs("Cylinder_vacuum", 0.,Rmax_cylinder_internal_small1-1.5*mm, cylinder_height_central_inner_small1, 0.*deg, 360.*deg);
  // G4SubtractionSolid *connection_air_central_inner_small1 = new G4SubtractionSolid ("H", pcylinder_connection_air_central_inner_small1, pInnerCryostatUnionSolid,0,zTrans_central_inner_small1); 
  
  // G4double cylinder_height_central_inner_small2 = 0.5*1460.5*mm;
  // G4ThreeVector zTrans_central_inner_small2(-450.331*mm, -260.*mm,-200.*mm);
  // G4Tubs *pcylinder_connection_central_inner_small2_ss = new G4Tubs("Cylinder_vacuum", Rmin_cylinder_small2, Rmax_cylinder_small2, cylinder_height_central_inner_small2, 0.*deg, 360.*deg);
  // G4SubtractionSolid *connection_central_inner_small2_ss = new G4SubtractionSolid ("H", pcylinder_connection_central_inner_small2_ss, pInnerCryostatUnionSolid,0,zTrans_central_inner_small2); 
  // G4LogicalVolume *connection_log_central_inner_small2_ss = new G4LogicalVolume(connection_central_inner_small2_ss, SS316Ti, "A");
  // G4VPhysicalVolume *m_pconnection_phys_central_inner_small2_ss = new G4PVPlacement(RotLat, G4ThreeVector(-450.331,-260.,228.8),connection_log_central_inner_small2_ss, "Carr_ss",m_pMotherLogicalVolume , false, 0);

  // pInnerCryostatUnionSolid = new G4UnionSolid("L", pInnerCryostatUnionSolid, connection_inner_small1,0,G4ThreeVector(450.331,-260.,900.*mm));
  
  //____________________________________________________________________________________________________________________________
  
  m_pInnerCryostatLogicalVolume = new G4LogicalVolume(pInnerCryostatUnionSolid, cryoMaterial, "InnerCryostatUnionSolid", 0, 0, 0);
  m_pInnerCryostatPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, zPos),
   						     m_pInnerCryostatLogicalVolume, "SS_InnerCryostat", m_pMotherLogicalVolume, false, 0);
  
  m_pMotherLogicalVolume = m_pInnerCryostatLogicalVolume;
 
 
  // //_______________________________________________________________________________________________________
  // G4LogicalVolume *connection_log_air_central_inner = new G4LogicalVolume(connection_air_central_inner, Vacuum, "A",0,0,0);
  // G4VPhysicalVolume *m_pconnection_phys_air_central_inner = new G4PVPlacement(0, G4ThreeVector(0,0,199.96*mm),connection_log_air_central_inner, 
  // 							      "Vacuum_Central_pipe_inner", m_pMotherLogicalVolume, false, 0);
  // G4LogicalVolume *connection_log_internal_1_central_inner = new G4LogicalVolume(connection_internal_1_central_inner, SS316Ti, "Adggd",0,0,0);
  // G4VPhysicalVolume *m_pconnection_phys_internal_1_central_inner = new G4PVPlacement(0, G4ThreeVector(0,0,0.*mm),
  // 										     connection_log_internal_1_central_inner, 
  // 										     "Vacuum_Central_Pipe_inner_1",connection_log_air_central_inner , 
  // 										     false, 0);
  // G4LogicalVolume *connection_log_internal_2_central_inner = new G4LogicalVolume(connection_internal_2_central_inner, SS316Ti, "Adhdhdh",0,0,0);
  // G4VPhysicalVolume *m_pconnection_phys_internal_2_central_inner = new G4PVPlacement(0, G4ThreeVector(0,0,0.*mm),
  // 										     connection_log_internal_2_central_inner,
  // 										     "Vacuum_Central_Pipe_inner",connection_log_air_central_inner , 
  // 										     false, 0);
  // G4double cylinder_height_central_inner_lateral = 0.5*1791.39*mm;
  // G4double cylinder_radius_central_inner_lateral = 0.5*102.*mm;
  // G4Tubs *pcylinder_connection_central_inner_lateral= new G4Tubs("Cylinder_external_SS",0., cylinder_radius_central_inner_lateral,
  // 								 cylinder_height_central_inner_lateral, 0.*deg, 360.*deg);
  // G4ThreeVector zTrans_central_inner_lateral(0*mm, -375.*mm,-200.*mm);
  // G4Tubs *pcylinder_connection_air_central_inner_lateral = new G4Tubs("Cylinder_vacuum", 0., cylinder_radius_central_inner_lateral, 
  // 								      cylinder_height_central_inner_lateral, 0.*deg, 360.*deg);
  // G4SubtractionSolid *connection_central_inner_air_lateral = new G4SubtractionSolid ("H", pcylinder_connection_air_central_inner_lateral, 
  // 										     pInnerCryostatUnionSolid,0,zTrans_central_inner_lateral); 
  
  // G4LogicalVolume *connection_log_air_central_inner_lateral = new G4LogicalVolume(connection_central_inner_air_lateral, Vacuum, "A");
  // G4VPhysicalVolume *m_pconnection_phys_central_inner_air_lateral = new G4PVPlacement(RotLat, G4ThreeVector(0,-375.,195.1*mm),
  // 										      connection_log_air_central_inner_lateral, 
  // 										      "VAcuum_Pipe_lateral_inner",m_pMotherLogicalVolume, false, 0);
  // G4LogicalVolume *connection_log_air_central_inner_small1 = new G4LogicalVolume(connection_air_central_inner_small1, Vacuum, "A");
  // G4VPhysicalVolume *m_pconnection_phys_air_central_inner_small1 = new G4PVPlacement(RotLat, G4ThreeVector(450.331*mm, -260.*mm,192.2*mm),
  // 										     connection_log_air_central_inner_small1, 
  // 										     "Vacuum_Pipe_lateral_small_1",m_pMotherLogicalVolume, false, 0); 
  //_______________________________________________________________________________________________________
  
  
  //================================== attributes =================================
  G4Colour hTitaniumColor(0.600, 0.600, 0.600, 0.1);
  G4VisAttributes *pTitaniumVisAtt = new G4VisAttributes(hTitaniumColor);
  pTitaniumVisAtt->SetVisibility(true);
  m_pOuterCryostatLogicalVolume->SetVisAttributes(pTitaniumVisAtt);
  m_pOuterCryostatVacuumLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  m_pInnerCryostatLogicalVolume->SetVisAttributes(pTitaniumVisAtt);
  
  G4cout << "Xenon1tDetectorConstruction::ConstructColumbiaCryostat Finished building cryostat geometry" << G4endl;  
  
}



void
Xenon1tDetectorConstruction::ConstructXenon()
{
  G4cout <<"Xenon1tDetectorConstruction::ConstructXenon() Construct Xenon " << G4endl;
  
  //const G4int iNbPolyhedraSides = (G4int) GetGeometryParameter("NbPolyhedraSides");
  
  //================================== Liquid xenon =================================
  // Changed to vacuum in order to reduce the total amount of xenon
  
  G4Material *Vacuum 	= G4Material::GetMaterial("Vacuum");
  
  G4double L         = GetGeometryParameter("InnerCryostatCylinderHeight");
  G4double D         = GetGeometryParameter("InnerCryostatOuterDiameter")-2*GetGeometryParameter("InnerCryostatThickness");
  G4double R0top     = GetGeometryParameter("InnerCryostatR0top") - GetGeometryParameter("InnerCryostatThicknessTop");
  G4double R1top     = GetGeometryParameter("InnerCryostatR1top") - GetGeometryParameter("InnerCryostatThicknessTop");
  G4double R0bot     = GetGeometryParameter("InnerCryostatR0bot") - GetGeometryParameter("InnerCryostatThicknessBot");
  G4double R1bot     = GetGeometryParameter("InnerCryostatR1bot") - GetGeometryParameter("InnerCryostatThicknessBot");

  //
  // make the LXe solid structure, such that it fills the complete inner cryostat
  //
  
  G4double cylinder_Innradius_innerConn = GetGeometryParameter("Rmax_cylinder_internal_central_big_pipe") - GetGeometryParameter("Wall_thickness_central_internal_big_pipe");
  G4double cylinder_height_inner = 0.5*217.78*mm;
  G4Tubs *connection_inner_LXe = new G4Tubs("Cylinder_external_SS_4",0., cylinder_Innradius_innerConn, cylinder_height_inner, 0.*deg, 360.*deg);
  G4UnionSolid *pLXeVacuumUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,0,0,0,0,0,true);
  pLXeVacuumUnionSolid = new G4UnionSolid("L", pLXeVacuumUnionSolid, connection_inner_LXe, 0, 
					  G4ThreeVector(0.,0.,994.32*mm-47.*mm+cylinder_height_inner));
  
  G4double x_base_small = 450.*mm;
  G4double y_base_small = 260.*mm;
  G4double Rmin_cylinder_small_pipe = GetGeometryParameter("Rmin_cylinder_small_pipe");
  G4double small_pipe_height        = small_pipe_height+0.5*568.1*mm;
  G4Tubs *small_connection_inner_LXe = new G4Tubs("Cylinder_small_SS",0., Rmin_cylinder_small_pipe, small_pipe_height, 
   						   0.*deg, 360.*deg);
  pLXeVacuumUnionSolid = new G4UnionSolid("L", pLXeVacuumUnionSolid, small_connection_inner_LXe, 0, 
					  G4ThreeVector(x_base_small, y_base_small, 516.*mm+small_pipe_height));
  
  
  m_pLXeVacuumLogicalVolume = new G4LogicalVolume(pLXeVacuumUnionSolid, Vacuum, "LXeVacuumVolume", 0, 0, 0, true);
  m_pLXeVacuumPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pLXeVacuumLogicalVolume, "LXeVacuum", m_pMotherLogicalVolume, false, 0);

  m_pMotherLogicalVolume = m_pLXeVacuumLogicalVolume;

  //================================== Gaseous xenon =================================

  G4Material *GXe = G4Material::GetMaterial("GXe");

  G4double dTopPlateOffsetZ = GetGeometryParameter("TopPlateOffsetZ");
  G4double dTopPmtHolderOffsetZ = dTopPlateOffsetZ- GetGeometryParameter("TopPlateHeight")*0.5 - 30.*mm - GetGeometryParameter("TopPmtHolderHeight")*0.5;
  G4double dTopAcrylicOffsetZ = dTopPmtHolderOffsetZ-GetGeometryParameter("TopPmtHolderHeight")*0.5-85.*mm-GetGeometryParameter("TopAcrylicHeight")*0.5; 
  G4double dTopPTFEOffsetZ = dTopAcrylicOffsetZ - GetGeometryParameter("TopAcrylicHeight")*0.5 - 33.55*mm - GetGeometryParameter("TopPTFEHeight")*0.5;
  G4double dTopElectrodePTFEOffsetZ = dTopPTFEOffsetZ - GetGeometryParameter("TopPTFEHeight")*0.5 - 32.8*mm - GetGeometryParameter("TopElectrodePTFEHeight")*0.5;
  G4double dGXeCutShiftZ       = dTopElectrodePTFEOffsetZ - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 + 2.*mm - L + 15.75*mm;
     
  G4UnionSolid *pGXeUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,0,0,0,0,0,true);
  G4Tubs *pCut = new G4Tubs("pCut1", 0., D, L, 0., 2*M_PI);
  
 
  G4double dLXeTopRadius = GetGeometryParameter("LXeTopRadius"); 
  G4double dLXeTopHeight = GetGeometryParameter("LXeTopHeight");
  G4double dLXeTopCutShiftZ  = dTopPlateOffsetZ +GetGeometryParameter("TopPlateHeight")*0.5 + 0.5*dLXeTopHeight;
  G4Tubs *pCutLT = new G4Tubs("pCutLT", 0., dLXeTopRadius, 0.5*dLXeTopHeight, 0., 2*M_PI);

  G4SubtractionSolid *pGXe; 
  pGXe = new G4SubtractionSolid("pGXeSolid", pGXeUnionSolid, pCut, 0, G4ThreeVector(0.,0.,dGXeCutShiftZ));
  
  m_pGXeLogicalVolume = new G4LogicalVolume(pGXe, GXe, "GXeLogicalVolume", 0, 0, 0);
  m_pGXePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pGXeLogicalVolume, "GXe", m_pMotherLogicalVolume, false, 0); 


  //================================== Top Liquid xenon =================================
  // Cyril, Nov 2013, added for the LXe veto above TPC

  G4Material *LXe = G4Material::GetMaterial("LXe");
  G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");

  if(pTpcWithBell){ //in the Bell option, there is LXe also around and on top of the TOP PMT array
  
    // full LXe layer on top of the top copper plate
    G4Tubs *pLXeTopTube = new G4Tubs("pLXeTopTube", 0., 0.5*D, 0.5*dLXeTopHeight, 0., 2*M_PI);
    G4IntersectionSolid *pLXeTop = new G4IntersectionSolid("pLXeTop",pLXeVacuumUnionSolid,pLXeTopTube,0, G4ThreeVector(0, 0, dLXeTopCutShiftZ));
    m_pLXeTopLogicalVolume = new G4LogicalVolume(pLXeTop, LXe, "LXeTopLogicalVolume", 0, 0, 0);
    m_pLXeTopPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pLXeTopLogicalVolume, "LXeTop", m_pGXeLogicalVolume, false, 0);   

    // Lateral part of the Bell, 3mm thick.
    G4double dLXeAroundBellHeight = 253.*mm; 
    G4double dLateralBellHeight =  dLXeAroundBellHeight;
    G4double dBellRadialThickness = 3.*mm; 
    G4double dBellInnerRadius =  GetGeometryParameter("TopPlateRad");  
    G4double dLateralBellOffsetZ = dTopPlateOffsetZ +GetGeometryParameter("TopPlateHeight")*0.5 - 0.5*dLateralBellHeight;
    G4Tubs *pLateralBellTube = new G4Tubs("pLateralBellTube", dBellInnerRadius, (dBellInnerRadius + dBellRadialThickness), 0.5*dLXeAroundBellHeight, 0., 2*M_PI);
    m_pLateralBellLogicalVolume = new G4LogicalVolume(pLateralBellTube, SS316Ti, "LateralBellLogicalVolume", 0, 0, 0);
    m_pLateralBellPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, dLateralBellOffsetZ), m_pLateralBellLogicalVolume, "SS_LateralBell", m_pGXeLogicalVolume, false, 0);     

    // LXe layer around the bell
    G4double dLXeAroundBellInnerRadius = dBellInnerRadius + dBellRadialThickness;
    G4Tubs *pLXeAroundBellTube = new G4Tubs("pLXeAroundBellTube", dLXeAroundBellInnerRadius, 0.5*D, 0.5*dLXeAroundBellHeight, 0., 2*M_PI);
    G4double dLXeAroundBellCutShiftZ = dTopPlateOffsetZ +GetGeometryParameter("TopPlateHeight")*0.5 - 0.5*dLXeAroundBellHeight;
    G4IntersectionSolid *pLXeAroundBell = new G4IntersectionSolid("pLXeAroundBell",pLXeVacuumUnionSolid,pLXeAroundBellTube,0, G4ThreeVector(0, 0, dLXeAroundBellCutShiftZ));
    m_pLXeAroundBellLogicalVolume = new G4LogicalVolume(pLXeAroundBell, LXe, "LXeAroundBellLogicalVolume", 0, 0, 0);
    m_pLXeAroundBellPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pLXeAroundBellLogicalVolume, "LXeAroundBell", m_pGXeLogicalVolume, false, 0); 
    

  }
    
  //================================== Liquid xenon =================================
  
  //G4Material *LXe = G4Material::GetMaterial("LXe");

  G4double dLXeCutShiftZ = dGXeCutShiftZ+L*2;
 
  G4UnionSolid *pLXeUnionSolid = ConstructVessel(D,L,R0top,R1top,R0bot,R1bot,0,0,0,0,0,true);
  G4Tubs *pCut2 = new G4Tubs("pCut2", 0., D, L, 0., 2*M_PI);
  G4SubtractionSolid *pLXe = new G4SubtractionSolid("pLXeSolid0",pLXeUnionSolid,pCut2,0,G4ThreeVector(0.,0.,dLXeCutShiftZ));
 
  m_pLXeLogicalVolume = new G4LogicalVolume(pLXe, LXe, "LXeLogicalVolume", 0, 0, 0);
  m_pLXePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pLXeLogicalVolume, "LXe", m_pMotherLogicalVolume, false, 0);

  m_pMotherLogicalVolume = m_pLXeLogicalVolume;
   
  //------------------------------ xenon sensitivity ------------------------------
  G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
  
  Xenon1tLXeSensitiveDetector *pLXeSD = new Xenon1tLXeSensitiveDetector("Xenon1t/LXeSD");
  pSDManager->AddNewDetector(pLXeSD);
  
  m_pLXeLogicalVolume->SetSensitiveDetector(pLXeSD);
  
  if(pTpcWithBell){
    m_pLXeTopLogicalVolume->SetSensitiveDetector(pLXeSD);
    m_pLXeAroundBellLogicalVolume->SetSensitiveDetector(pLXeSD);
  }
  
  
  // // why is this set to be active? APC m_pGXeLogicalVolume->SetSensitiveDetector(pLXeSD);
  
 //  ///  if (m_pLSLogicalVolume!=NULL) m_pLSLogicalVolume->SetSensitiveDetector(pLXeSD);
 //    ///  if (m_pWaterLogicalVolume!=NULL) m_pWaterLogicalVolume->SetSensitiveDetector(pLXeSD);
  
  //================================== attributes =================================
    G4Colour hLXeColor(0.094, 0.718, 0.812, 0.05);
    G4VisAttributes *pLXeVisAtt = new G4VisAttributes(hLXeColor);
    pLXeVisAtt->SetVisibility(false);
    m_pLXeLogicalVolume->SetVisAttributes(pLXeVisAtt);
    //   m_pLXeLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  
    G4Colour hGXeColor(0.539, 0.318, 0.378, 0.01);
    G4VisAttributes *pGXeVisAtt = new G4VisAttributes(hGXeColor);
    pGXeVisAtt->SetVisibility(false);
    m_pGXeLogicalVolume->SetVisAttributes(pGXeVisAtt);
    //   m_pGXeLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);

 
}


void
Xenon1tDetectorConstruction::ConstructTopTPC()
{
  G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");
  G4Material *Copper  = G4Material::GetMaterial("Copper");
  G4Material *Cirlex  = G4Material::GetMaterial("Cirlex");
  G4Material *Teflon  = G4Material::GetMaterial("Teflon");
  G4Material *Acrylic = G4Material::GetMaterial("Acrylic");
  
  G4double dcutRadius  = GetGeometryParameter("cutRadius");
  
  G4double dHVFT_OuterSS_Radius = GetGeometryParameter("HVFT_OuterSS_Radius");
  G4double HVFT_center_position = GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness") - GetGeometryParameter("HVFT_OuterSS_Radius") - GetGeometryParameter("HVFTdistanceFromInnerCryostat");
  G4double dHVFT_angular_Offset = GetGeometryParameter("HVFT_angular_Offset");  
  G4double HVFT_x_Offset        = HVFT_center_position * cos(dHVFT_angular_Offset);
  G4double HVFT_y_Offset        = HVFT_center_position * sin(dHVFT_angular_Offset);
  G4ThreeVector  transCut(HVFT_x_Offset, HVFT_y_Offset, 0.);
  
  //______________________ Top Copper Plate __________________________________________________________________

  G4double dTopPlateRadius  = GetGeometryParameter("TopPlateRad");
  G4double dTopPlateHeight  = GetGeometryParameter("TopPlateHeight");
  G4double dTopPlateOffsetZ = GetGeometryParameter("TopPlateOffsetZ");

  G4cout <<" ************ Top Plate (SS) ************ "<<G4endl;
  G4cout <<dTopPlateRadius<<"  "<<dTopPlateHeight<<"  "<<dTopPlateOffsetZ<<G4endl;
  
  G4Tubs *pTopPlateTmp = new G4Tubs("tubstmp", 0., dTopPlateRadius, dTopPlateHeight*0.5, 0, 2*M_PI);
  G4Tubs *pCut = new G4Tubs("cut_tubs", 0., dHVFT_OuterSS_Radius, dTopPlateHeight*0.5, 0, 2*M_PI);
  
  G4SubtractionSolid *pTopPlate = new G4SubtractionSolid("tubs", pTopPlateTmp, pCut, 0, transCut);
    
  m_pTopPlateLogicalVolume = new G4LogicalVolume(pTopPlate, SS316Ti, "TopPlateLogicalVolume", 0, 0, 0);
  m_pTopPlatePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopPlateOffsetZ), m_pTopPlateLogicalVolume, 
   						"SS_TopPlate", m_pGXeLogicalVolume, false, 0);
  
  // //_____________________ Top PMTs Holder (PTFE) _________________________________________________________________________
  
  G4double dTopPmtHolderRad     = GetGeometryParameter("TopPmtHolderRad");
  G4double dTopPmtHolderHeight  = GetGeometryParameter("TopPmtHolderHeight");
  G4double dTopPmtHolderOffsetZ = dTopPlateOffsetZ - dTopPlateHeight*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - dTopPmtHolderHeight*0.5;
  
  G4Tubs *pfull_TopPmtHolderTmp = new G4Tubs("full_TopPmtHoldertubsTmp", 0., dTopPmtHolderRad, dTopPmtHolderHeight*0.5, 0, 2*M_PI);
  G4Tubs *pcut_TopPmtHolder = new G4Tubs("pcut1", 0.*mm, dcutRadius, dTopPmtHolderHeight*0.5, 0, 2*M_PI);
  G4Tubs *pCut_1 = new G4Tubs("cut_tubs", 0., dHVFT_OuterSS_Radius, dTopPmtHolderHeight*0.5, 0, 2*M_PI);
  G4SubtractionSolid *pfull_TopPmtHolder = new G4SubtractionSolid("tubs", pfull_TopPmtHolderTmp, pCut_1, 0, transCut);
  G4SubtractionSolid *pTopPmtHolder = (G4SubtractionSolid*) pfull_TopPmtHolder;
  
  // //_____________________ Top Copper PMTs  _________________________________________________________________________
  
  G4double dTopPMTCopperRad     = GetGeometryParameter("TopPMTCopperRad");
  G4double dTopPMTCopperHeight  = GetGeometryParameter("TopPMTCopperHeight");
  G4double dTopPMTCopperOffsetZ = dTopPmtHolderOffsetZ - dTopPmtHolderHeight*0.5 - GetGeometryParameter("DistanceTopPmtHolderFromTopPMTCopper") - dTopPMTCopperHeight*0.5; 
  
  G4Tubs *pfull_TopPMTCopperTmp = new G4Tubs("full_TopPMTCoppertubsTmp", 0., dTopPMTCopperRad, dTopPMTCopperHeight*0.5, 0, 2*M_PI);
  G4Tubs *pcut_TopPMTCopper = new G4Tubs("pcut2", 0.*mm, dcutRadius, dTopPMTCopperHeight*0.5, 0, 2*M_PI);
  G4Tubs *pCut_2 = new G4Tubs("cut_tubs", 0., dHVFT_OuterSS_Radius, dTopPMTCopperHeight*0.5, 0, 2*M_PI);
  G4SubtractionSolid *pfull_TopPMTCopper = new G4SubtractionSolid("tubs", pfull_TopPMTCopperTmp, pCut_2, 0, transCut);
  G4SubtractionSolid *pTopPMTCopper = (G4SubtractionSolid*) pfull_TopPMTCopper;
  
  // //_____________________ Top PTFE reflector _________________________________________________________________________
  
  G4double dTopPTFERad     = GetGeometryParameter("TopPTFERad");
  G4double dTopPTFEHeight  = GetGeometryParameter("TopPTFEHeight");
  G4double dTopPTFEOffsetZ = dTopPMTCopperOffsetZ - dTopPMTCopperHeight*0.5 - GetGeometryParameter("DistanceTopPMTCopperFromTopPTFE") - dTopPTFEHeight*0.5; 
  
  G4Tubs *pfull_TopPTFEtmp = new G4Tubs("full_TopPTFEtubstmp", 0., dTopPTFERad, dTopPTFEHeight*0.5, 0, 2*M_PI);
  G4Tubs *pcut_TopPTFE = new G4Tubs("pcut3", 0., dcutRadius, dTopPTFEHeight*0.5, 0, 2*M_PI);
  G4Tubs *pCut_3 = new G4Tubs("cut_tubs", 0., dHVFT_OuterSS_Radius, dTopPTFEHeight*0.5, 0, 2*M_PI);
  G4SubtractionSolid *pfull_TopPTFE = new G4SubtractionSolid("tubs", pfull_TopPTFEtmp, pCut_3, 0, transCut);
  G4SubtractionSolid *pTopPTFE = (G4SubtractionSolid*) pfull_TopPTFE;
  

  G4double dcutRadius2 = GetGeometryParameter("TopPTFERadiusHoleCut"); // 32 or 33*mm;
  G4double dcutHalfHeightCons = 3.5*mm;
  G4Tubs *pcut_bottom1 = new G4Tubs("pcut_bottom1", 0., dcutRadius, dTopPTFEHeight*0.5 - dcutHalfHeightCons, 0, 2*M_PI);
  G4Cons *pcut_bottomCons = new G4Cons("pcut_bottomCons",
				       0., // Rmin at -Z
				       dcutRadius, // Rmax at +Z
				       0., // Rmin at +Z
				       dcutRadius2, // Rmax at +Z
				       dcutHalfHeightCons, //cone_half_z
				       0, //start_phi,
				       2*M_PI); // stop_phi);


  // ---------- Top PMTs bases (Cirlex) ----------
  G4double dPmtBasesRadius = GetGeometryParameter("PmtBasesDiameter")*0.5;
  G4double dPmtBasesHeight = GetGeometryParameter("PmtBasesHeight");
  G4double dPMTsOffsetZ = dTopPTFEOffsetZ + GetGeometryParameter("PMTHeight")*0.5 + 1.3*mm;
  
  G4double dTopPmtBasesOffsetZ = dPMTsOffsetZ + GetGeometryParameter("PMTHeight")*0.5 + dPmtBasesHeight*0.5 + GetGeometryParameter("DistancePmtFromPmtBase");
  
  G4Tubs *pPmtBases = new G4Tubs("pPmtBases", 0., dPmtBasesRadius, dPmtBasesHeight*0.5, 0, 2*M_PI);
  m_pPmtBasesLogicalVolume = new G4LogicalVolume(pPmtBases, Cirlex, "PmtBasesLogicalVolume", 0, 0, 0);
  
  // ---------- Top PMTs R11410 ----------
  G4int TotNbOfTopPmt = G4int(GetGeometryParameter("NbOfTopPMTs"));
  
  stringstream hVolumeName_1;
  stringstream hHoleName_1;
  stringstream hHoleName_2;
  stringstream hHoleName_3;
  stringstream hSolidName;
  
  for(G4int iPMTNt=1; iPMTNt<=TotNbOfTopPmt; ++iPMTNt)
    {
      hVolumeName_1.str(""); 
      hVolumeName_1 << "PmtTpcTop_" << iPMTNt;
      m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(0, GetPMTsPositionTopArray(iPMTNt)+G4ThreeVector(0.,0.,dPMTsOffsetZ), 
      							m_pPmtR11410LogicalVolume, hVolumeName_1.str(), 
      							m_pGXeLogicalVolume, false, iPMTNt));
    
      m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(0, GetPMTsPositionTopArray(iPMTNt)+G4ThreeVector(0.,0.,dTopPmtBasesOffsetZ),
      							     m_pPmtBasesLogicalVolume, "PmtBaseTpc", m_pGXeLogicalVolume, false, iPMTNt));
    
      hHoleName_1.str(""); 
      hHoleName_1<< "TopPmtHolderWithCuts_" << iPMTNt;
      pTopPmtHolder = new G4SubtractionSolid(hHoleName_1.str(),pTopPmtHolder,pcut_TopPmtHolder,0,GetPMTsPositionTopArray(iPMTNt));
    
      hHoleName_2.str(""); 
      hHoleName_2<< "TopPMTCopperWithCuts_" << iPMTNt;
      pTopPMTCopper = new G4SubtractionSolid(hHoleName_2.str(),pTopPMTCopper,pcut_TopPMTCopper,0,GetPMTsPositionTopArray(iPMTNt));
    
      hHoleName_3.str(""); 
      hHoleName_3<< "TopPTFEWithCuts_" << iPMTNt;
      //pTopPTFE = new G4SubtractionSolid(hHoleName_3.str(),pTopPTFE,pcut_TopPTFE,0,GetPMTsPositionTopArray(iPMTNt));
      G4ThreeVector posPMT = GetPMTsPositionTopArray(iPMTNt);
      posPMT.setZ(dcutHalfHeightCons); 
      pTopPTFE = new G4SubtractionSolid(hHoleName_3.str(),pTopPTFE,pcut_bottom1,0,posPMT);
      G4ThreeVector posPMT2 = GetPMTsPositionTopArray(iPMTNt);
      posPMT2.setZ(-dTopPTFEHeight*0.5+dcutHalfHeightCons);
      pTopPTFE = new G4SubtractionSolid(hHoleName_3.str(),pTopPTFE,pcut_bottomCons,0,posPMT2);


   }
  
  m_pTopPMTsHolderLogicalVolume = new G4LogicalVolume(pTopPmtHolder, Teflon, "TopPMTsHolderLogicalVolume", 0, 0, 0);
  m_pTopPMTsHolderPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopPmtHolderOffsetZ), m_pTopPMTsHolderLogicalVolume, 
  						     "Teflon_TopPmtHolder", m_pGXeLogicalVolume, false, 0);
  
  m_pTopPMTCopperLogicalVolume = new G4LogicalVolume(pTopPMTCopper, Copper, "TopPMTCopperLogicalVolume", 0, 0, 0);
  m_pTopPMTCopperPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopPMTCopperOffsetZ), m_pTopPMTCopperLogicalVolume, 
  						    "Copper_TopPMTplate", m_pGXeLogicalVolume, false, 0);
  
  m_pTopPTFELogicalVolume = new G4LogicalVolume(pTopPTFE, Teflon, "TopPTFELogicalVolume", 0, 0, 0);
  m_pTopPTFEPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopPTFEOffsetZ), m_pTopPTFELogicalVolume, 
  					       "Teflon_TopReflector", m_pGXeLogicalVolume, false, 0);

  //__________________________________ PTFE part around electrode rings  __________________________________________________________
  
  G4double dGridMeshThickness = GetGeometryParameter("GridMeshThickness");
  G4double dHeight_TopElectrodePTFEbelowAnode = GetGeometryParameter("Height_TopElectrodePTFEbelowAnode");
  
  G4double dTopElectrodePTFEInnRad      = GetGeometryParameter("TopElectrodePTFEInnRad");
  G4double dTopElectrodePTFEOutRad      = dTopElectrodePTFEInnRad + GetGeometryParameter("TopElectrodePTFEThikness");
  G4double dTopElectrodePTFEHeight      = GetGeometryParameter("TopElectrodePTFEHeight") + dHeight_TopElectrodePTFEbelowAnode*0.5;
  G4double dTopElectrodePTFEHeight_LXe  = dHeight_TopElectrodePTFEbelowAnode*0.5;                      
  G4double dTopElectrodePTFEOffsetZ     = dTopPTFEOffsetZ - dTopPTFEHeight*0.5 - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - dTopElectrodePTFEHeight*0.5;
  G4double dLXe_cutOffsetZ              = -dTopElectrodePTFEHeight*0.5 + dTopElectrodePTFEHeight_LXe*0.5;
  G4double dTopElectrodePTFE_LXeOffsetZ = dTopElectrodePTFEOffsetZ - dTopElectrodePTFEHeight*0.5 - dTopElectrodePTFEHeight_LXe + dHeight_TopElectrodePTFEbelowAnode*0.5 - 0.2*mm;
  
  G4double dTopMeshRingInnRad       = GetGeometryParameter("TopMeshRingInnRad");
  G4double dTopMeshRingOutRad       = dTopMeshRingInnRad + GetGeometryParameter("TopMeshRingThikness");
  G4double dTopMeshRingHeight       = GetGeometryParameter("TopMeshRingHeight");
  G4double dTopMeshRingOffsetZ      = dTopPTFEOffsetZ - dTopPTFEHeight*0.5 - dTopMeshRingHeight*0.5;
  
  G4double dAnodeRingInnRad_1       = GetGeometryParameter("AnodeRingInnRad_1");
  G4double dAnodeRingHeight_1       = GetGeometryParameter("AnodeRingHeight_1");
  G4double dAnodeRingCutHeight_1    = GetGeometryParameter("AnodeRingHeight_1");
  G4double dAnodeRingOutRad_1       = dAnodeRingInnRad_1 + GetGeometryParameter("AnodeRingThickness_1");
  G4double dAnodeRingCutOffsetZ_1   = -dTopElectrodePTFEHeight*0.5 + dHeight_TopElectrodePTFEbelowAnode*0.5 + dAnodeRingCutHeight_1*0.5;
  G4double dAnodeRingOffsetZ_1      = dTopElectrodePTFEOffsetZ - dTopElectrodePTFEHeight*0.5 + dHeight_TopElectrodePTFEbelowAnode*0.5 + dAnodeRingHeight_1*0.5;
  
  G4double dAnodeRingInnRad_2       = GetGeometryParameter("AnodeRingInnRad_2");
  G4double dAnodeRingHeight_2       = GetGeometryParameter("AnodeRingHeight_2");
  G4double dAnodeRingCutHeight_2    = GetGeometryParameter("AnodeRingHeight_2");
  G4double dAnodeRingOutRad_2       = dAnodeRingInnRad_2 + GetGeometryParameter("AnodeRingThickness_2");
  G4double dAnodeRingCutOffsetZ_2   = dAnodeRingCutOffsetZ_1 + dAnodeRingHeight_1*0.5 + dAnodeRingHeight_2*0.5;
  G4double dAnodeRingOffsetZ_2      = dAnodeRingOffsetZ_1 + dAnodeRingHeight_1*0.5 + dAnodeRingHeight_2*0.5;
  
  G4Tubs *pTopElectrodePTFE_1   = new G4Tubs("Tubs_1", dTopElectrodePTFEInnRad, dTopElectrodePTFEOutRad, dTopElectrodePTFEHeight*0.5, 0, 2*M_PI);
  G4Tubs *pTopElectrodePTFE_cut = new G4Tubs("Tubs_1cut", dTopElectrodePTFEInnRad, dTopElectrodePTFEOutRad, dTopElectrodePTFEHeight_LXe*0.5, 0, 2*M_PI);
  G4Tubs *pAnodeCut_1 = new G4Tubs("Anode_1_cut", dAnodeRingInnRad_1, dAnodeRingOutRad_1, dAnodeRingCutHeight_1*0.5, 0, 2*M_PI);
  G4Tubs *pAnodeCut_2 = new G4Tubs("Anode_2_cut", dAnodeRingInnRad_2, dAnodeRingOutRad_2, dAnodeRingCutHeight_2*0.5, 0, 2*M_PI);
  G4Tubs *pCut_a = new G4Tubs("cuta_tubs", 0., dHVFT_OuterSS_Radius, dTopElectrodePTFEHeight*0.5, 0, 2*M_PI);
  
  G4SubtractionSolid *pTopElectrodePTFE_3 = new G4SubtractionSolid("pTopElectrodePTFE_3", pTopElectrodePTFE_1, pAnodeCut_1, 0, 
  								   G4ThreeVector(0.,0.,dAnodeRingCutOffsetZ_1));
  G4SubtractionSolid *pTopElectrodePTFEtmp = new G4SubtractionSolid("pTopElectrodePTFEtmp", pTopElectrodePTFE_3, pAnodeCut_2, 0, 
  								    G4ThreeVector(0.,0.,dAnodeRingCutOffsetZ_2));
  // G4SubtractionSolid *pTopElectrodePTFEtmp2 = new G4SubtractionSolid("pTopElectrodePTFEtmp2", pTopElectrodePTFEtmp, pTopElectrodePTFE_cut, 0, 
  // 								     G4ThreeVector(0.,0.,dLXe_cutOffsetZ));
  G4SubtractionSolid *pTopElectrodePTFEtmp3 = new G4SubtractionSolid("pTopElectrodePTFEtmp3", pTopElectrodePTFEtmp/*2*/, pCut_a, 0, transCut);
  
  G4double ZZ[]     = {0., 63.*mm};
  G4double RRin[]   = {0, 0};
  G4double RRout[]  = {484.*mm, 510.5*mm};
  G4Polycone *p_polycone = new G4Polycone("Polycone", 0., 2*M_PI, 2, ZZ, RRin, RRout);
  G4SubtractionSolid *pTopElectrodePTFE = new G4SubtractionSolid("pTopElectrodePTFE", pTopElectrodePTFEtmp3, p_polycone, 0, G4ThreeVector(0,0,-28.*mm));
    
  m_pTopElectrodePTFELogicalVolume  = new G4LogicalVolume(pTopElectrodePTFE, Teflon, "TopElectrodePTFELogicalVolume", 0, 0, 0);
  m_pTopElectrodePTFEPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopElectrodePTFEOffsetZ), m_pTopElectrodePTFELogicalVolume, 
    							"Teflon_TopAroundElectrode_GXe", m_pGXeLogicalVolume, false, 0);
							
  //G4Tubs *pCut_TopRing = new G4Tubs("cut_tubs", 0., dHVFT_OuterSS_Radius, dTopMeshRingHeight*0.5, 0, 2*M_PI);
  // G4Tubs *pTopMeshRing_Tmp = new G4Tubs("TopRing_Tmp", dTopMeshRingInnRad, dTopMeshRingOutRad, dTopMeshRingHeight*0.5, 0, 2*M_PI);
  //G4SubtractionSolid *pTopMeshRing = new G4SubtractionSolid("TopRing", pTopMeshRing_Tmp, pCut_TopRing, 0, transCut);
  G4Tubs *pTopMeshRing = new G4Tubs("TopRing", dTopMeshRingInnRad, dTopMeshRingOutRad, dTopMeshRingHeight*0.5, 0, 2*M_PI);
  m_pTopMeshRingLogicalVolume  = new G4LogicalVolume(pTopMeshRing, SS316Ti, "TopMeshRingLogicalVolume", 0, 0, 0);
  m_pTopMeshRingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopMeshRingOffsetZ), m_pTopMeshRingLogicalVolume, 
  						   "SS_TopMeshRing", m_pGXeLogicalVolume, false, 0);
  
  G4Tubs *pAnodeRing_1 = new G4Tubs("AnodeRing_1", dAnodeRingInnRad_1, dAnodeRingOutRad_1, dAnodeRingHeight_1*0.5, 0, 2*M_PI);
  m_pAnodeRing_1LogicalVolume  = new G4LogicalVolume(pAnodeRing_1, SS316Ti, "pAnodeRing_1LogicalVolume", 0, 0, 0);
  m_pAnodeRing_1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dAnodeRingOffsetZ_1), m_pAnodeRing_1LogicalVolume, 
  						   "SS_AnodeRing_1", m_pGXeLogicalVolume, false, 0);
  
  G4Tubs *pAnodeRing_2 = new G4Tubs("AnodeRing_2", dAnodeRingInnRad_2, dAnodeRingOutRad_2, dAnodeRingHeight_2*0.5, 0, 2*M_PI);
  m_pAnodeRing_2LogicalVolume  = new G4LogicalVolume(pAnodeRing_2, SS316Ti, "pAnodeRing_2LogicalVolume", 0, 0, 0);
  m_pAnodeRing_2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dAnodeRingOffsetZ_2), m_pAnodeRing_2LogicalVolume, 
  						   "SS_AnodeRing_2", m_pGXeLogicalVolume, false, 0);
  
  G4Tubs *pTopElectrodePTFE_LXeTmp = new G4Tubs("Tubs_LXe", dTopElectrodePTFEInnRad, dTopElectrodePTFEOutRad, dTopElectrodePTFEHeight_LXe*0.5, 0, 2*M_PI);
  G4Tubs *pCut_4 = new G4Tubs("cut4_tubs", 0., dHVFT_OuterSS_Radius, dTopElectrodePTFEHeight_LXe*0.5, 0, 2*M_PI);
  G4SubtractionSolid *pTopElectrodePTFE_LXe = new G4SubtractionSolid("pTopElectrodePTFE_LXe", pTopElectrodePTFE_LXeTmp, pCut_4, 0, transCut);

  m_pTopElectrodePTFELXeLogicalVolume  = new G4LogicalVolume(pTopElectrodePTFE_LXe, Teflon, "TopElectrodePTFELXeLogicalVolume", 0, 0, 0);
  m_pTopElectrodePTFELXePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopElectrodePTFE_LXeOffsetZ-1.05*mm), 
   							   m_pTopElectrodePTFELXeLogicalVolume, 
   							   "Teflon_TopAroundElectrode_LXe", m_pMotherLogicalVolume, false, 0);

  // //____________________________ SS Plate + SS Ring _______________________________________________________________
  
  G4double dSSPlateInnRad     = GetGeometryParameter("SSPlateInnRad");
  G4double dSSPlateOutRad     = dSSPlateInnRad + GetGeometryParameter("SSPlateThickness");
  G4double dSSPlateHeight     = GetGeometryParameter("SSPlateHeight");
  G4double dSSPlateOffsetZ    = dTopElectrodePTFEOffsetZ - dTopElectrodePTFEHeight*0.5 - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5 - dSSPlateHeight*0.5;
  
  G4double dSSRingThickness   = GetGeometryParameter("SSRingThickness");
  G4double dSSRingInnRad      = dSSPlateOutRad - dSSRingThickness;
  G4double dSSRingOutRad      = dSSPlateOutRad;
  G4double dSSRingHeight_LXe  = GetGeometryParameter("SSRingHeight_LXe");
  G4double dSSRing_LXeOffsetZ = dSSPlateOffsetZ - dSSPlateHeight*0.5 - dSSRingHeight_LXe*0.5;
  
  G4double dGateRingInnRad        = GetGeometryParameter("GateRingInnRad");//GetGeometryParameter("TPCinnRadius") + GetGeometryParameter("TPCthikness");
  G4double dGateRingOutRad        = dGateRingInnRad + GetGeometryParameter("GateRingThickness");
  G4double dGateRingHeight        = GetGeometryParameter("GateRingHeight");
  G4double dCutOffsetZ            = dSSPlateHeight*0.5 - dGateRingHeight*0.5;
  G4double dGateRingOffsetZ       = dSSPlateOffsetZ + dSSPlateHeight*0.5 - dGateRingHeight*0.5;
   
  G4Tubs *pSSPlate_1 = new G4Tubs("ssTubs", dSSPlateInnRad, dSSPlateOutRad, dSSPlateHeight*0.5, 0, 2*M_PI);
  G4Tubs *pSSPlate_cut = new G4Tubs("ssTubscut", 0., dGateRingOutRad, dGateRingHeight*0.5, 0, 2*M_PI);
  // G4Tubs *pCut_9 = new G4Tubs("cut_9_tubs", 0., dHVFT_OuterSS_Radius, dSSPlateHeight*0.5, 0, 2*M_PI);
  G4SubtractionSolid *pSSPlateTmp = new G4SubtractionSolid("SSPlateTmpTubs", pSSPlate_1, pSSPlate_cut, 0, G4ThreeVector(0.,0.,dCutOffsetZ));
  //G4SubtractionSolid *pSSPlate = new G4SubtractionSolid("SSPlateTubs", pSSPlateTmp, pCut_9, 0, transCut);
  
  m_pSSPlateLogicalVolume = new G4LogicalVolume(pSSPlateTmp, SS316Ti, "SSPlateLogicalVolume", 0, 0, 0);
  m_pSSPlatePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dSSPlateOffsetZ), m_pSSPlateLogicalVolume, 
    						   "SS_Plate", m_pMotherLogicalVolume, false, 0);
  
  G4Tubs *pSSRing_LXe = new G4Tubs("ssRing_LXe", dSSRingInnRad, dSSRingOutRad, dSSRingHeight_LXe*0.5, 0, 2*M_PI);
  m_pSSRing_LXeLogicalVolume = new G4LogicalVolume(pSSRing_LXe, SS316Ti, "SSRing_LXeLogicalVolume", 0, 0, 0);
  m_pSSRing_LXePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dSSRing_LXeOffsetZ), m_pSSRing_LXeLogicalVolume, 
   						      "SS_Ring_LXe", m_pMotherLogicalVolume, false, 0);
  
  G4Tubs *pGateElectrodeRing = new G4Tubs("gateRingTubs", dGateRingInnRad, dGateRingOutRad, dGateRingHeight*0.5, 0, 2*M_PI);
  m_pGateElectrodeRingLogicalVolume = new G4LogicalVolume(pGateElectrodeRing, SS316Ti, "LogicalVolume", 0, 0, 0);
  m_pGateElectrodeRingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dGateRingOffsetZ), m_pGateElectrodeRingLogicalVolume, 
  							 "SS_GateRing", m_pMotherLogicalVolume, false, 0);
  
  //================================== attributes =================================
    
  G4Colour hCopperColor(1., 0.757, 0.24, 0.1);
  G4VisAttributes *pCopperVisAtt = new G4VisAttributes(hCopperColor);
  pCopperVisAtt->SetVisibility(true);
  m_pTopPlateLogicalVolume->SetVisAttributes(pCopperVisAtt);
  m_pTopPMTCopperLogicalVolume->SetVisAttributes(pCopperVisAtt);
  
  G4Colour hCirlexColor(0.2, 0.5, 0.8, 0.1);
  G4VisAttributes *pCirlexVisAtt = new G4VisAttributes(hCirlexColor);
  pCirlexVisAtt->SetVisibility(true);
  m_pPmtBasesLogicalVolume->SetVisAttributes(pCirlexVisAtt);
   
  G4Colour hSSColor(0.600, 0.600, 0.600, 0.1);
  G4VisAttributes *pSSVisAtt = new G4VisAttributes(hSSColor);
  pSSVisAtt->SetVisibility(true);
  m_pTopMeshRingLogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pAnodeRing_1LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pAnodeRing_2LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pGateElectrodeRingLogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pSSPlateLogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pSSRing_LXeLogicalVolume->SetVisAttributes(pSSVisAtt);

  G4Colour hTeflonColor(0.5, 0.3, 0.2, 0.01);
  G4VisAttributes *pTeflonVisAtt = new G4VisAttributes(hTeflonColor);
  pTeflonVisAtt->SetVisibility(true);
  m_pTopPTFELogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pTopElectrodePTFELogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pTopElectrodePTFELXeLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pTopPMTsHolderLogicalVolume->SetVisAttributes(pTeflonVisAtt);

}

void 
Xenon1tDetectorConstruction::ConstructTPC()
{
  G4Material *Teflon = G4Material::GetMaterial("Teflon");
  G4Material *Copper = G4Material::GetMaterial("Copper");
  G4Material *Acrylic  = G4Material::GetMaterial("Acrylic");
  G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");
  G4Material *GridMeshAluminium = G4Material::GetMaterial("GridMeshAluminium");
  G4Material *Vacuum = G4Material::GetMaterial("Vacuum");
  G4Material *CathodeMesh = G4Material::GetMaterial("CathodeMesh");
  G4Material *BottomScreeningMesh = G4Material::GetMaterial("BottomScreeningMesh");

  G4double dcutRadius  = GetGeometryParameter("cutRadius");
  
  G4RotationMatrix *pRotX180 = new G4RotationMatrix();
  pRotX180->rotateX(180.*deg);
  
  G4double dTopPlateOffsetZ = GetGeometryParameter("TopPlateOffsetZ");
  G4double dTopPmtHolderOffsetZ = dTopPlateOffsetZ - GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight")*0.5;
  G4double dTopPMTCopperOffsetZ = dTopPmtHolderOffsetZ - GetGeometryParameter("TopPmtHolderHeight")*0.5 - GetGeometryParameter("DistanceTopPmtHolderFromTopPMTCopper") - GetGeometryParameter("TopPMTCopperHeight")*0.5; 
  G4double dTopPTFEOffsetZ = dTopPMTCopperOffsetZ - GetGeometryParameter("TopPMTCopperHeight")*0.5 - GetGeometryParameter("DistanceTopPMTCopperFromTopPTFE") - GetGeometryParameter("TopPTFEHeight")*0.5; 
  G4double dTopElectrodePTFEOffsetZ     = dTopPTFEOffsetZ - GetGeometryParameter("TopPTFEHeight")*0.5 - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight")*0.5;
  G4double dSSPlateOffsetZ    = dTopElectrodePTFEOffsetZ - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5 - GetGeometryParameter("SSPlateHeight")*0.5;
  G4double dGateRingOffsetZ       = dSSPlateOffsetZ + GetGeometryParameter("SSPlateHeight")*0.5 - GetGeometryParameter("GateRingHeight")*0.5;

  // //_________________________________ TPC  ________________________________________________________
  G4double dGridHeight = GetGeometryParameter("GridMeshThickness");
  
  G4double dTpcInRadius  = GetGeometryParameter("TPCinnRadius");
  G4double dTpcOutRadius = dTpcInRadius+GetGeometryParameter("TPCthikness");
  G4double dTpcHeight    = GetGeometryParameter("TPCheight");
  G4double dTpcOffsetZ   = dGateRingOffsetZ + GetGeometryParameter("GateRingHeight")*0.5 - dTpcHeight*0.5 - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5 - dGridHeight;
  
  G4cout << "  tpc  " << dTpcInRadius<<"   "<<dTpcOutRadius<<"   "<<dTpcHeight<<"   "<<dTpcOffsetZ<<G4endl;
  
  G4double dcathodeRing_2_InnRad  = GetGeometryParameter("CathodeRing_2_inn_Radius");
  G4double dcathodeRing_2_OutRad  = dcathodeRing_2_InnRad + GetGeometryParameter("CathodeRing_2_thikness");
  G4double dcathodeThorus_2_Curv  = GetGeometryParameter("CathodeRing_2_thikness")*0.5;
  G4double dTpcCutHeight          = GetGeometryParameter("CathodeRing_2_Height");
  G4double dcathodeRing_2_Height  = GetGeometryParameter("CathodeRing_2_Height") - dcathodeThorus_2_Curv;
  G4double dTor_2_rad             = dcathodeRing_2_InnRad + dcathodeThorus_2_Curv;
  
  G4Tubs *pTpc_tmp = new G4Tubs("pTpc_tmp", dTpcInRadius, dTpcOutRadius, dTpcHeight*0.5, 0, 2*M_PI);
  G4Tubs *pTpc_cut = new G4Tubs("pTpc_cut", dcathodeRing_2_InnRad, dcathodeRing_2_OutRad, dTpcCutHeight*0.5, 0, 2*M_PI);
  
  G4ThreeVector TpcCutVect(0., 0., -dTpcHeight*0.5 + dTpcCutHeight*0.5);
  G4SubtractionSolid *pTpc = new G4SubtractionSolid("pTpc", pTpc_tmp, pTpc_cut, 0, TpcCutVect);
  
  m_pTpcLogicalVolume = new G4LogicalVolume(pTpc, Teflon, "TPCWallLogicalVolume", 0, 0, 0);
  m_pTpcPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTpcOffsetZ), m_pTpcLogicalVolume, "Teflon_Tpc",
   					   m_pMotherLogicalVolume, false, 0);
   
  // // //________________________________________ Outer TPC ring ________________________________________
   
  G4double dBelowTpcRingOffsetZ  = dTpcOffsetZ - GetGeometryParameter("TPCheight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5;
  G4double dOuterTpcRingOffsetZ  = dBelowTpcRingOffsetZ - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("OuterTpcRingHeight")*0.5;
  
  //_________________________________ Field rings _________________________________________________________________________________________
  
  G4double dHeight    = GetGeometryParameter("FieldShaperRingsHeight")*0.5;
  G4double dThickness = GetGeometryParameter("FieldShaperRingsThickness");
  G4double dCurvature = dThickness*0.5;
  G4double dSpaceTPC_fieldRing = 3.68*mm;
  G4double dRadius    = dTpcOutRadius + dCurvature + dSpaceTPC_fieldRing;
  G4double dRadiusMin = dRadius-dCurvature;
  G4double dRadiusMax = dRadius+dCurvature;
  G4double dStepZ     = GetGeometryParameter("FieldShaperRingsStep");
  G4double dOffsetZ   = dSSPlateOffsetZ - GetGeometryParameter("SSPlateHeight")*0.5 - dStepZ + GetGeometryParameter("FieldShaperRingsHeight");
  
  G4UnionSolid *pPTFEpillar = ConstructPillar();
  
  G4Torus *pTorus = new G4Torus("torus", 0.*mm, dCurvature, dRadius, 0, 2*M_PI);
  G4Tubs *pTube = new G4Tubs("tubs", dRadiusMin, dRadiusMax, dHeight, 0, 2*M_PI);
  G4UnionSolid *pRingTmp = new G4UnionSolid("pr1", pTube, pTorus, 0, G4ThreeVector(0.,0.,dHeight));
  G4UnionSolid *pRing = new G4UnionSolid("sRing", pRingTmp, pTorus, 0, G4ThreeVector(0.,0.,-dHeight));
  
  G4double dCutbase_x = GetGeometryParameter("BottomBoxBase_x");
  G4double dCutbase_y = GetGeometryParameter("Cutbase_y");
  G4double dCutbase_z = GetGeometryParameter("Cutbase_z");
  G4Box *pBox_cut = new G4Box("Box", dCutbase_x*0.5, dCutbase_y*0.5, dCutbase_z*0.5);
  
  G4double yPosCut = -(GetGeometryParameter("TopBoxBase_y") - dCutbase_y*0.5)*0.5;
  
  m_pFieldShaperRingLogicalVolume = new G4LogicalVolume(pRing, Copper, "FieldShaperRingLogicalVolume", 0, 0, 0);
  
  G4double dcutPillarOffsetZ      = GetGeometryParameter("TopBox_height")*0.5 + dCutbase_z*0.5 - dStepZ;
  
  stringstream name;
  G4int NumOfRings = GetGeometryParameter("FieldShaperRingsTotNum");

  for(int a=0; a<NumOfRings; ++a)
    {
      
      //pPTFEpillar = new G4SubtractionSolid("pillar", pPTFEpillar, pBox_cut, 0, G4ThreeVector(0.,yPosCut,dcutPillarOffsetZ));
     
      name.str("");
      name << "Copper_FieldShapingRing_" << a;
      m_pFieldShaperRingPhysicalVolumes.push_back(new G4PVPlacement(0, G4ThreeVector(0.,0.,dOffsetZ), m_pFieldShaperRingLogicalVolume, 
      								    name.str(), m_pMotherLogicalVolume, false, 0));
      
      dOffsetZ -= dStepZ;    
      //dcutPillarOffsetZ -= dStepZ;
    }
  
  //_________________________________________ cathode electrode ring ______________________________________  
  
  G4double dBelowTpcRingInRadius  = GetGeometryParameter("TPCinnRadius");
  G4double dBelowTpcRingOutRadius =  dBelowTpcRingInRadius + GetGeometryParameter("BelowTPCringThikness");
  G4double dBelowTpcRingHeight    = GetGeometryParameter("BelowTPCringHeight");
  
  G4double dcathodeRingInnRad     = GetGeometryParameter("CathodeRing_inn_Radius");
  G4double dcathodeRingOutRad     = GetGeometryParameter("CathodeRing_inn_Radius") + GetGeometryParameter("CathodeRing_thikness");
  G4double dcathodeThorusCurv     = GetGeometryParameter("CathodeRing_thikness")*0.5;
  G4double dcathodeRingHeight     = GetGeometryParameter("CathodeRingHeight") - dcathodeThorusCurv;
  G4double dTor_1_rad             = dcathodeRingInnRad + dcathodeThorusCurv;
 
  G4double dcathodeRingOffsetZ = dBelowTpcRingOffsetZ + dBelowTpcRingHeight*0.5 - GetGeometryParameter("CathodeRingHeight")*0.5 + dcathodeThorusCurv*0.5;
 
  G4Tubs *pCathodeRingTube_1 = new G4Tubs("TubeCathod_Tube_1", dcathodeRingInnRad, dcathodeRingOutRad, dcathodeRingHeight*0.5, 0, 2*M_PI);
  G4Torus *pCathodeTorus_1   = new G4Torus("torus_1", 0., dcathodeThorusCurv, dTor_1_rad, 0, 2*M_PI);
  G4Tubs *pCathodeRingTube_2 = new G4Tubs("TubeCathod_Tube_2", dcathodeRing_2_InnRad, dcathodeRing_2_OutRad, dcathodeRing_2_Height*0.5, 0, 2*M_PI);
  G4Torus *pCathodeTorus_2   = new G4Torus("torus_2", 0., dcathodeThorus_2_Curv, dTor_2_rad, 0, 2*M_PI);
  
  G4UnionSolid *pCathodeRingTube;
  G4ThreeVector cathVect_1(0., 0., -dcathodeRingHeight*0.5);
  pCathodeRingTube = new G4UnionSolid("cathodeRing", pCathodeRingTube_1, pCathodeTorus_1, 0, cathVect_1);
  G4ThreeVector cathVect_2(0., 0., dcathodeRingHeight*0.5 + dcathodeRing_2_Height*0.5);
  pCathodeRingTube = new G4UnionSolid("cathodeRing", pCathodeRingTube, pCathodeRingTube_2, 0, cathVect_2);
  G4ThreeVector cathVect_3(0., 0., dcathodeRingHeight*0.5 + dcathodeRing_2_Height);
  pCathodeRingTube = new G4UnionSolid("cathodeRing", pCathodeRingTube, pCathodeTorus_2, 0, cathVect_3);
  
  G4double dCathodeZ   = dcathodeRingOffsetZ + dcathodeRingHeight*0.5 + dGridHeight*0.5;
  
  G4Tubs *pCathode = new G4Tubs("TubeCathodemesh", 0., dBelowTpcRingInRadius, dGridHeight*0.5, 0, 2*M_PI);
  m_pCathodeMeshLogicalVolume = new G4LogicalVolume(pCathode, CathodeMesh, "CathodeMeshLogicalVolume", 0, 0, 0);
  m_pCathodeMeshPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dCathodeZ), m_pCathodeMeshLogicalVolume, 
  						   "GridMeshAluminium_Cathode", m_pMotherLogicalVolume, false, 0);

  //______________________________________________ ring Below TPC __________________________________________________ 

  G4cout <<" ************ Bottom TPC Wall (PTFE) ************ "<<G4endl;
  G4cout <<dBelowTpcRingInRadius<<"   "<<dBelowTpcRingOutRadius<<"   "<<dBelowTpcRingHeight<<"   "<<dBelowTpcRingOffsetZ<<G4endl;
  
  G4double dBottomRingHeight  = GetGeometryParameter("BottomRingHeight");
  G4double dBottomRingInnRad  = GetGeometryParameter("BottomRing_inn_Radius");
  G4double dBottomRingOutRad  = GetGeometryParameter("BottomRing_out_Radius");
  G4double dBottomRingOffsetZ = dBelowTpcRingOffsetZ - dBelowTpcRingHeight*0.5 + dBottomRingHeight*0.5 + GetGeometryParameter("DistanceBottomRingFromBottomPTFE");
  
  G4double dBottomRingCutOffsetZ  = -dBelowTpcRingHeight*0.5 + dBottomRingHeight*0.5 + GetGeometryParameter("DistanceBottomRingFromBottomPTFE");
  G4double dcathodeRingCutOffsetZ = dBelowTpcRingHeight*0.5 - GetGeometryParameter("CathodeRingHeight")*0.5 + dcathodeThorusCurv*0.5;
  
  G4Tubs *pBelowTpcRing_1 = new G4Tubs("pBelowTpcRing_1", dBelowTpcRingInRadius, dBelowTpcRingOutRadius, dBelowTpcRingHeight*0.5, 0, 2*M_PI);
  G4Tubs *BottomRing_hole = new G4Tubs("btubesbpttom", dBottomRingInnRad, dBottomRingOutRad, dBottomRingHeight*0.5, 0, 2*M_PI);
  
  G4SubtractionSolid *pBelowTpcRing_2 = new G4SubtractionSolid("pBelowTpcRing", pBelowTpcRing_1, BottomRing_hole, 0, 
							       G4ThreeVector(0.,0.,dBottomRingCutOffsetZ)); 
  G4SubtractionSolid *pBelowTpcRing = new G4SubtractionSolid("pBelowTpcRing", pBelowTpcRing_2, pCathodeRingTube, 0, 
							     G4ThreeVector(0.,0.,dcathodeRingCutOffsetZ));  
  
  m_pBelowTpcRingLogicalVolume = new G4LogicalVolume(pBelowTpcRing, Teflon, "BelowTPCRingLogicalVolume", 0, 0, 0);
  m_pBelowTpcRingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dBelowTpcRingOffsetZ), m_pBelowTpcRingLogicalVolume, 
  						    "Teflon_RingBelowTpc", m_pMotherLogicalVolume, false, 0); 
 
  m_pCathodeMesh_RingLogicalVolume = new G4LogicalVolume(pCathodeRingTube, SS316Ti, "CathodeMesh_RingLogicalVolume", 0, 0, 0);
  m_pCathodeMesh_RingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dcathodeRingOffsetZ), m_pCathodeMesh_RingLogicalVolume, 
  							"SS_RingCathode", m_pMotherLogicalVolume, false, 0);
  
  //_____________________________________________ Pillars _____________________________________________________________________  
  
  G4int dNbofPTFEpillar               = GetGeometryParameter("NbofPTFEpillar");
  G4double PTFEpillarCenterRadius     = dTpcInRadius + GetGeometryParameter("TPCthikness") + GetGeometryParameter("TopBoxBase_y")*0.5 + dSpaceTPC_fieldRing + 6.*mm;
  G4double PTFEpillarOffsetZ          = dSSPlateOffsetZ - GetGeometryParameter("SSPlateHeight")*0.5 - GetGeometryParameter("TopBox_height")*0.5 - 2.5*mm;
 
  stringstream pillar;
  G4double PTFEpillarAngularStep = GetGeometryParameter("deltaTheta");
  G4double AngularOffset         = 0.;

  m_pPTFEpillarLogicalVolume = new G4LogicalVolume(pPTFEpillar, Teflon, "PTFEpillarLogicalVolume", 0, 0, 0);
  
  for(int ii=0; ii<dNbofPTFEpillar; ii++)
    {
      
      G4RotationMatrix *zRot         = new G4RotationMatrix();
      zRot->rotateZ(PTFEpillarAngularStep*ii);
      
      G4double PTFEpillarCenter_x  = PTFEpillarCenterRadius * sin(AngularOffset); 
      G4double PTFEpillarCenter_y  = PTFEpillarCenterRadius * cos(AngularOffset); 
      
      pillar.str("");
      pillar << "Teflon_Pillar_" << ii;
      m_pPTFEpillarPhysicalVolume.push_back(new G4PVPlacement(zRot, G4ThreeVector(PTFEpillarCenter_x, PTFEpillarCenter_y, PTFEpillarOffsetZ), 
       							      m_pPTFEpillarLogicalVolume, pillar.str(), m_pMotherLogicalVolume, false, 0));
      
      AngularOffset += PTFEpillarAngularStep;
     
    }
   
  //________________________________________ bottom electrode ring ________________________________________ 
  
  G4Tubs *pBottomGridMesh_Ring = new G4Tubs("TubeBottomGrid_Ring", dBottomRingInnRad, dBottomRingOutRad, dBottomRingHeight*0.5, 0, 2*M_PI);
  m_pBottomGridMesh_RingLogicalVolume = new G4LogicalVolume(pBottomGridMesh_Ring, SS316Ti, "BottomGridMesh_RingLogicalVolume", 0, 0, 0);
  m_pBottomGridMesh_RingPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dBottomRingOffsetZ), 
  							   m_pBottomGridMesh_RingLogicalVolume,"SS_RingBottomMesh", 
  							   m_pMotherLogicalVolume, false, 0);
  
  G4double dBottomGridMeshZ = dBottomRingOffsetZ + dBottomRingHeight*0.5 + dGridHeight;
  G4Tubs *pBottomGridMesh = new G4Tubs("TubeBottomGrid", 0., dBelowTpcRingInRadius, dGridHeight*0.5, 0, 2*M_PI);
  m_pBottomGridMeshLogicalVolume = new G4LogicalVolume(pBottomGridMesh, BottomScreeningMesh, "BottomGridMeshLogicalVolume", 0, 0, 0);
  m_pBottomGridMeshPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dBottomGridMeshZ), m_pBottomGridMeshLogicalVolume, 
  						      "GridMeshAluminium_BottomMesh", m_pMotherLogicalVolume, false, 0);

  //________________________________________ Bottom PTFE reflector ________________________________________ 
  
  G4double dBottomReflectorRadius     = GetGeometryParameter("BottomReflectorRadius");
  G4double dBottomReflectorHeight     = GetGeometryParameter("ReflectorHeight");  
  G4double dBottomReflectorOffsetZ    = dBelowTpcRingOffsetZ - dBelowTpcRingHeight*0.5 - dBottomReflectorHeight*0.5; 
  
  G4Tubs *pfull_bottom = new G4Tubs("pfull_bottomTmp", 0., dBottomReflectorRadius, dBottomReflectorHeight*0.5, 0, 2*M_PI);
  G4Tubs *pcut_bottom = new G4Tubs("pcut_bottom", 0., dcutRadius, dBottomReflectorHeight*0.5, 0, 2*M_PI);

  G4double dcutRadius2 = GetGeometryParameter("TopPTFERadiusHoleCut"); // 32 or 33*mm;
  //G4double dcutRadius2 = 32.*mm;// 32 or 33*mm;
  G4double dcutHeight2 = 1*mm; // half-height of remaining PTFE above PMT window
  //G4Tubs *pcut_bottom1 = new G4Tubs("pcut_bottom1", 0., dcutRadius, dBottomReflectorHeight*0.5 - dcutHeight2, 0, 2*M_PI);
  G4double dcutHalfHeightCons = 2.5*mm;
  G4Tubs *pcut_bottom1 = new G4Tubs("pcut_bottom1", 0., dcutRadius, dBottomReflectorHeight*0.5 - dcutHalfHeightCons, 0, 2*M_PI);
  G4Tubs *pcut_bottom2 = new G4Tubs("pcut_bottom2", 0., dcutRadius2, dcutHeight2, 0, 2*M_PI);

  G4Cons *pcut_bottomCons = new G4Cons("pcut_bottomCons",
				       0., // Rmin at -Z
				       dcutRadius2, // Rmax at +Z
				       0., // Rmin at +Z
				       dcutRadius, // Rmax at +Z
				       dcutHalfHeightCons, //cone_half_z
				       0, //start_phi,
				       2*M_PI); // stop_phi);
  
  G4SubtractionSolid *pBottomReflector = (G4SubtractionSolid*) pfull_bottom;
  
  //___________________________ Bottom PMTs PTFE ________________________________________  

  G4double dBottomPTFEradius  = GetGeometryParameter("BottomPTFErad");
  G4double dBottomPTFEHeight  = GetGeometryParameter("BottomPTFEHeight");
  G4double dBottomPTFEOffsetZ = dBottomReflectorOffsetZ - dBottomReflectorHeight*0.5 - dBottomPTFEHeight*0.5 - GetGeometryParameter("DistanceBottomReflectorFromBottomPTFE");
  
  G4cout <<" ************ Bottom PTFE ************ "<<G4endl;
  G4cout <<dBottomPTFEradius<<"   "<<"   "  <<dBottomPTFEHeight<<"   "<<dBottomPTFEOffsetZ<<G4endl;
  
  G4Tubs *pFull_BottomPTFE = new G4Tubs("pFull_BottomPTFE", 0., dBottomPTFEradius, 
					dBottomPTFEHeight*0.5, 0, 2*M_PI);
  G4Tubs *pcut_bottomPTFE = new G4Tubs("pcut_bottom", 0., dcutRadius, dBottomPTFEHeight*0.5, 0, 2*M_PI);
  stringstream h_bottomPTFE_Name;
  
  G4SubtractionSolid *pBottomPTFE = (G4SubtractionSolid*) pFull_BottomPTFE;
  
  //___________________________ Bottom PMTs holder Plate (Copper) ________________________________________
  
  G4double dBottomHolderPlateRad     = GetGeometryParameter("BottomHolderPlateRad");
  G4double dBottomHolderPlateHeight  = GetGeometryParameter("BottomHolderPlateHeight");
  G4double dBottomHolderPlateOffsetZ = dBottomPTFEOffsetZ - dBottomPTFEHeight*0.5 - GetGeometryParameter("DistanceBottomPTFEFromBottomPMTHolder") - dBottomHolderPlateHeight*0.5;
  
  G4Tubs *pFull_BottomHolder = new G4Tubs("pFull_BottomHolder", 0., dBottomHolderPlateRad, 
					  dBottomHolderPlateHeight*0.5, 0, 2*M_PI);
  
  G4Tubs *pcut_bottomHolder = new G4Tubs("pcut_bottomPlate", 0., dcutRadius, dBottomHolderPlateHeight*0.5, 0, 2*M_PI);
  stringstream h_bottomHolder_Name;
  
  G4SubtractionSolid *pBottomHolder = (G4SubtractionSolid*) pFull_BottomHolder;
  
   //_______________________________________ Copper ring below pillars ____________________________________
  
  G4double dCopperRingInnRad              = GetGeometryParameter("CopperRingInnRad");
  G4double dCopperRingThickness           = GetGeometryParameter("CopperRingThickness");
  G4double dCopperRingOutRad              = dCopperRingInnRad + dCopperRingThickness;
  G4double dCopperRingHeight              = GetGeometryParameter("CopperRingHeight");
  G4double dCopperRingBelowPillarsOffsetZ = dBottomHolderPlateOffsetZ + dBottomHolderPlateHeight*0.5 + dCopperRingHeight*0.5; 
  
  G4Tubs *pCopperRingBelowPillars = new G4Tubs("CuBelowPillars", dCopperRingInnRad, dCopperRingOutRad, dCopperRingHeight*0.5, 0, 2*M_PI);
  m_pCopperRingBelowPillarsLogicalVolume  = new G4LogicalVolume(pCopperRingBelowPillars, Copper, "CopperRingBelowPillarsLogicalVolume", 0, 0, 0);
  m_pCopperRingBelowPillarsPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dCopperRingBelowPillarsOffsetZ), 
							      m_pCopperRingBelowPillarsLogicalVolume,"Copper_CopperRingBelowPillars", 
							      m_pMotherLogicalVolume, false, 0);
  
  // ---------- Bottom PMTs R11410  ----------
  G4int    TotNbOfTopPMTs   = G4int(GetGeometryParameter("NbOfTopPMTs"));
  G4int    TotNbOfPMTs      = G4int(GetGeometryParameter("NbOfPMTs"));
  G4double dPMTsOffsetZ     = dBottomReflectorOffsetZ - GetGeometryParameter("PMTHeight")*0.5;
  //G4double dPMTsOffsetZ     = dBottomReflectorOffsetZ - GetGeometryParameter("PMTHeight")*0.5 - dcutHeight2*2;

  G4double dBottomPmtBasesOffsetZ  = dPMTsOffsetZ - GetGeometryParameter("PMTHeight")*0.5 - GetGeometryParameter("PmtBasesHeight")*0.5 - GetGeometryParameter("DistancePmtFromPmtBase");
 
  stringstream h_bottom_Name;
  stringstream hVolumeName;
  
  for(G4int iPMTNt=TotNbOfTopPMTs+1; iPMTNt<=TotNbOfPMTs; ++iPMTNt)
    {
      
      hVolumeName.str(""); 
      hVolumeName << "PmtTpcBot_" << iPMTNt;
      m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(pRotX180, 
      							GetPMTsPositionBottomArray(iPMTNt)+G4ThreeVector(0.,0.,dPMTsOffsetZ), 
      							m_pPmtR11410LogicalVolume, hVolumeName.str(), 
      							m_pMotherLogicalVolume, false, iPMTNt));
      
      m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(0, GetPMTsPositionBottomArray(iPMTNt)+G4ThreeVector(0.,0.,dBottomPmtBasesOffsetZ),
      							     m_pPmtBasesLogicalVolume, "PmtBaseTpc", m_pMotherLogicalVolume, false, iPMTNt));
      
      h_bottom_Name.str(""); 
      h_bottom_Name<< "BottomReflectorWithCuts_" << iPMTNt;
      //pBottomReflector = new G4SubtractionSolid(h_bottom_Name.str(),pBottomReflector,pcut_bottom,0,GetPMTsPositionBottomArray(iPMTNt));
      G4ThreeVector posPMT = GetPMTsPositionBottomArray(iPMTNt);
      posPMT.setZ(-dcutHalfHeightCons);
      pBottomReflector = new G4SubtractionSolid(h_bottom_Name.str(),pBottomReflector,pcut_bottom1,0,posPMT);
      //posPMT.setZ(-dcutHeight2);
      //pBottomReflector = new G4SubtractionSolid(h_bottom_Name.str(),pBottomReflector,pcut_bottom1,0,posPMT);
      G4ThreeVector posPMT2 = GetPMTsPositionBottomArray(iPMTNt);
      //posPMT2.setZ(dBottomReflectorHeight*0.5-dcutHeight2);
      posPMT2.setZ(dBottomReflectorHeight*0.5-dcutHalfHeightCons);
      //pBottomReflector = new G4SubtractionSolid(h_bottom_Name.str(),pBottomReflector,pcut_bottom2,0,posPMT2);
      pBottomReflector = new G4SubtractionSolid(h_bottom_Name.str(),pBottomReflector,pcut_bottomCons,0,posPMT2);

      h_bottomPTFE_Name.str(""); 
      h_bottomPTFE_Name<< "BottomPTFEWithCuts_" << iPMTNt;
      pBottomPTFE = new G4SubtractionSolid(h_bottomPTFE_Name.str(),pBottomPTFE,pcut_bottomPTFE,0,GetPMTsPositionBottomArray(iPMTNt));
      
      h_bottomHolder_Name.str(""); 
      h_bottomHolder_Name<< "BottomPMTsHolderWithCuts_" << iPMTNt;
      pBottomHolder = new G4SubtractionSolid(h_bottomHolder_Name.str(),pBottomHolder,pcut_bottomHolder,
      					     0,GetPMTsPositionBottomArray(iPMTNt));
      
  }
  
  m_pBottomReflectorLogicalVolume = new G4LogicalVolume(pBottomReflector, Teflon, "BottomReflectorLogicalVolume", 0, 0, 0);
  m_pBottomReflectorPhysicalVolume = new G4PVPlacement(0,G4ThreeVector(0.,0.,dBottomReflectorOffsetZ),
  						       m_pBottomReflectorLogicalVolume,"Teflon_BottomReflectorPlate", m_pMotherLogicalVolume,false,0);
  
  m_pBottomPTFELogicalVolume = new G4LogicalVolume(pBottomPTFE, Teflon, "BottomPTFELogicalVolume", 0, 0, 0);
  m_pBottomPTFEPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dBottomPTFEOffsetZ), 
  						     m_pBottomPTFELogicalVolume, "Teflon_BottomPlate", m_pMotherLogicalVolume, false, 0);
    
  m_pBottomHolderLogicalVolume = new G4LogicalVolume(pBottomHolder, Copper, "BottomPmtsHolderLogicalVolume", 0, 0, 0);
  m_pBottomHolderPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dBottomHolderPlateOffsetZ), 
  						    m_pBottomHolderLogicalVolume, "Copper_BottomPmtHolder",
  						    m_pMotherLogicalVolume, false, 0);

  //____________________________________ Cathode support (PTFE) ____________________________________ 
  
  G4double dcathodeSupport_x      = GetGeometryParameter("cathodeSupport_x");
  G4double dcathodeSupport_y      = GetGeometryParameter("cathodeSupport_y");
  G4double dcathodeSupport_height = GetGeometryParameter("cathodeSupport_height");
 
  G4Box *pCathodeSupport = new G4Box("pCathodeSupp", dcathodeSupport_x*0.5, dcathodeSupport_y*0.5, dcathodeSupport_height*0.5);
  m_pCathodeSupportLogicalVolume = new G4LogicalVolume(pCathodeSupport, Teflon, "CathodeSupportLogicalVolume", 0, 0, 0);
   
  stringstream cathodeSupp;
  G4double CathodeSupportRadius   = dBottomPTFEradius + dcathodeSupport_y*0.5;
  G4double CathodeSupportOffsetZ  = dBottomHolderPlateOffsetZ + dBottomHolderPlateHeight*0.5 + dcathodeSupport_height*0.5 + GetGeometryParameter("CopperRingHeight");
  G4double cathodeSuppAngularStep = GetGeometryParameter("cathodeSuppDeltaTheta");
  G4double cathodeSuppAngOffset   = 7.5*deg;
  G4int    dNbofCathodeSupp       = GetGeometryParameter("NbofCathodeSupp");
  
  for(int j=0; j<dNbofCathodeSupp; j++)
    {
      
      G4RotationMatrix *Zrot = new G4RotationMatrix();
      Zrot->rotateZ(cathodeSuppAngOffset);
      
      G4double CathodeSupportCenter_x  = CathodeSupportRadius * sin(cathodeSuppAngOffset); 
      G4double CathodeSupportCenter_y  = CathodeSupportRadius * cos(cathodeSuppAngOffset); 
      
      //G4cout << CathodeSupportCenter_x << "  " << CathodeSupportCenter_y << G4endl;
      
      cathodeSupp.str("");
      cathodeSupp << "Teflon_cathodeSupp_" << j;
      m_pCathodeSupportPhysicalVolume.push_back(new G4PVPlacement(Zrot, G4ThreeVector(CathodeSupportCenter_x, 
      										      CathodeSupportCenter_y, CathodeSupportOffsetZ), 
      								  m_pCathodeSupportLogicalVolume, cathodeSupp.str(), 
      								  m_pLXeLogicalVolume, false, 0));
      
      cathodeSuppAngOffset += cathodeSuppAngularStep;
     
    }
  
    
  //________________________________________________________________________________________________ 
  
  // ====== paolo added optical surfaces (2013/07/17) ====== //
  //
  G4double dSigmaAlpha = 0.1;
  G4OpticalSurface *pTeflonOpticalSurface = new G4OpticalSurface("TeflonOpticalSurface", unified, groundbackpainted, dielectric_dielectric, dSigmaAlpha);

  pTeflonOpticalSurface->SetMaterialPropertiesTable(Teflon->GetMaterialPropertiesTable());
  
  new G4LogicalBorderSurface("TopPTFELogicalBorderSurface",    m_pGXePhysicalVolume, m_pTopPTFEPhysicalVolume, pTeflonOpticalSurface); // Teflon_TopPlate
  
  new G4LogicalBorderSurface("TopPMTHolderPTFELogicalBorderSurface",    m_pGXePhysicalVolume, m_pTopPMTsHolderPhysicalVolume, pTeflonOpticalSurface); // Teflon_TopPmtHolder

  new G4LogicalBorderSurface("TopElectrodePTFELogicalBorderSurface",    m_pGXePhysicalVolume, m_pTopElectrodePTFEPhysicalVolume,    pTeflonOpticalSurface); // Teflon_TopAroundElectrode_GXe
  
  new G4LogicalBorderSurface("TopElectrodePTFELXeLogicalBorderSurface", m_pLXePhysicalVolume, m_pTopElectrodePTFELXePhysicalVolume, pTeflonOpticalSurface); // Teflon_TopAroundElectrode_LXe

  new G4LogicalBorderSurface("BottomReflectorLogicalBorderSurface", m_pLXePhysicalVolume, m_pBottomReflectorPhysicalVolume, pTeflonOpticalSurface); // Teflon_BottomReflector
  
  new G4LogicalBorderSurface("TpcLogicalBorderSurface", m_pLXePhysicalVolume, m_pTpcPhysicalVolume, pTeflonOpticalSurface); // Teflon_Tpc
  new G4LogicalBorderSurface("BottomPTFERingLogicalBorderSurface", m_pLXePhysicalVolume, m_pBelowTpcRingPhysicalVolume, pTeflonOpticalSurface); // Teflon_RingBelowTpc
  
  new G4LogicalBorderSurface("BottomPTFELogicalBorderSurface", m_pLXePhysicalVolume, m_pBottomPTFEPhysicalVolume, pTeflonOpticalSurface); // Teflon_BottomPlate

  stringstream hVolumeNameCS;

  for(int id=0; id<dNbofCathodeSupp; id++){
    G4VPhysicalVolume *CathodeSupportPhysicalVolume = (G4VPhysicalVolume*)m_pCathodeSupportPhysicalVolume.at(id);
    hVolumeNameCS.str(""); 
    hVolumeNameCS << "CathodeSupportLogicalBorderSurface_" << id;
    new G4LogicalBorderSurface(hVolumeNameCS.str(),m_pLXePhysicalVolume,CathodeSupportPhysicalVolume ,pTeflonOpticalSurface );
  } 



  
  
  // ====== paolo added optical surfaces (2013/07/17) ====== //
  
  
  //____________________________________ bottom filler ________________________________________________________
  
  G4double dBottomFillerThickness = GetGeometryParameter("BottomFillerThickness");
  G4double dBottomFiller_PlateRad = GetGeometryParameter("BottomFiller_PlateRad");		  
  G4double dBottomFillerHeight    = GetGeometryParameter("BottomFillerHeight");
  G4double dBottomFillerCoverThickness = GetGeometryParameter("BottomFillerCoverThickness");
  
  G4double l     = GetGeometryParameter("InnerCryostatCylinderHeight");
  G4double d     = GetGeometryParameter("InnerCryostatOuterDiameter") - 2*GetGeometryParameter("InnerCryostatThickness");
  G4double r0top = GetGeometryParameter("InnerCryostatR0top") - GetGeometryParameter("InnerCryostatThickness");
  G4double r1top = GetGeometryParameter("InnerCryostatR1top") - GetGeometryParameter("InnerCryostatThickness");
  G4double r0bot = GetGeometryParameter("InnerCryostatR0bot") - GetGeometryParameter("InnerCryostatThickness");
  G4double r1bot = GetGeometryParameter("InnerCryostatR1bot") - GetGeometryParameter("InnerCryostatThickness");
  
  G4double l_1     = GetGeometryParameter("InnerCryostatCylinderHeight");
  G4double d_1     = GetGeometryParameter("InnerCryostatOuterDiameter") - (2*GetGeometryParameter("InnerCryostatThickness") + 2*dBottomFillerThickness);
  G4double r0top_1 = GetGeometryParameter("InnerCryostatR0top") - (GetGeometryParameter("InnerCryostatThickness") + dBottomFillerThickness);
  G4double r1top_1 = GetGeometryParameter("InnerCryostatR1top") - (GetGeometryParameter("InnerCryostatThickness") + dBottomFillerThickness);
  G4double r0bot_1 = GetGeometryParameter("InnerCryostatR0bot") - (GetGeometryParameter("InnerCryostatThickness") + dBottomFillerThickness);
  G4double r1bot_1 = GetGeometryParameter("InnerCryostatR1bot") - (GetGeometryParameter("InnerCryostatThickness") + dBottomFillerThickness);
  
  G4double dBottomFillerCutOffsetZ = dBottomHolderPlateOffsetZ - dBottomHolderPlateHeight*0.5 - GetGeometryParameter("DistanceBottomHolderPlateFromBottomFiller") + l;
  if(!pLXeVeto)    // if there is NO LXe Veto, then the LXe layer below the bottom PMT array is smaller (the bottom filler is 3 cm below the PMT bases)
    dBottomFillerCutOffsetZ += 40.*mm; 
  
  G4UnionSolid *pBottomFillerUnionSolid = ConstructVessel(d,l,r0top,r1top,r0bot,r1bot,0,0,0,0,0,true);

  G4Tubs *pCut;  
  pCut = new G4Tubs("pCut1", 0., d, l, 0., 2*M_PI);

  // solid SS bottom filler, the region inside it will be empty
  G4SubtractionSolid *pBottomFiller = new G4SubtractionSolid("pBottomFiller_tmp", pBottomFillerUnionSolid, pCut, 0,
							     G4ThreeVector(0.,0.,dBottomFillerCutOffsetZ));  
  m_pBottomFillerLogicalVolume = new G4LogicalVolume(pBottomFiller, SS316Ti, "BottomFillerLogicalVolume", 0, 0, 0);
  m_pBottomFillerPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pBottomFillerLogicalVolume, 
   						    "SS_BottomFiller", m_pMotherLogicalVolume, false, 0);


  // --- vacuum inside the SS bottom filler. Thickness: 5 mm along the shell, 10mm in the top cover
  G4double dVacuumBottomFillerCutOffsetZ = dBottomFillerCutOffsetZ - dBottomFillerCoverThickness;
  G4UnionSolid *pBottomFillerUnionSolid_2 = ConstructVessel(d_1,l_1,r0top_1,r1top_1,r0bot_1,r1bot_1,0,0,0,0,0,true);
  G4SubtractionSolid *pVacuumBottomFiller = new G4SubtractionSolid("pVacuumBottomFiller_tmp", pBottomFillerUnionSolid_2, pCut, 0,
							     G4ThreeVector(0.,0.,dVacuumBottomFillerCutOffsetZ));  

  m_pVacuumBottomFillerLogicalVolume = new G4LogicalVolume(pVacuumBottomFiller, Vacuum, "VacuumBottomFillerLogicalVolume", 0, 0, 0); 
  m_pVacuumBottomFillerPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0, 0, 0), m_pVacuumBottomFillerLogicalVolume, 
    							  "Vacuum_BottomFiller", m_pBottomFillerLogicalVolume, false, 0); 


  //================================== attributes =================================
  
  G4Colour hCopperColor(1., 0.757, 0.24, 0.1);
  G4VisAttributes *pCopperVisAtt = new G4VisAttributes(hCopperColor);
  pCopperVisAtt->SetVisibility(true);
  m_pFieldShaperRingLogicalVolume->SetVisAttributes(pCopperVisAtt);
  m_pBottomHolderLogicalVolume->SetVisAttributes(pCopperVisAtt);
  m_pCopperRingBelowPillarsLogicalVolume->SetVisAttributes(pCopperVisAtt);

  G4Colour hTeflonColor(0.5, 0.3, 0.2, 0.01);
  G4VisAttributes *pTeflonVisAtt = new G4VisAttributes(hTeflonColor);
  pTeflonVisAtt->SetVisibility(true);
  m_pTpcLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pBelowTpcRingLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pPTFEpillarLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pBottomReflectorLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pBottomPTFELogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pCathodeSupportLogicalVolume->SetVisAttributes(pTeflonVisAtt);
  
  G4Colour hSSColor(0.600, 0.600, 0.600, 0.1);
  G4VisAttributes *pSSVisAtt = new G4VisAttributes(hSSColor);
  pSSVisAtt->SetVisibility(true);
  m_pCathodeMesh_RingLogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pBottomGridMesh_RingLogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pBottomFillerLogicalVolume->SetVisAttributes(pSSVisAtt);
  
  G4Colour hGridColor(0.4, 0.5, 0.7, 0.01);
  G4VisAttributes *pGridVisAtt = new G4VisAttributes(hGridColor);
  pGridVisAtt->SetVisibility(true);
  m_pCathodeMeshLogicalVolume->SetVisAttributes(pGridVisAtt);
  m_pBottomGridMeshLogicalVolume->SetVisAttributes(pGridVisAtt);
  
  G4Colour hVacuumColor(0, 1., 1.);
  G4VisAttributes *pVacuumVisAtt = new G4VisAttributes(hVacuumColor);
  pVacuumVisAtt->SetVisibility(false);
  m_pVacuumBottomFillerLogicalVolume->SetVisAttributes(pVacuumVisAtt);
  
}

void
Xenon1tDetectorConstruction::ConstructGrids() 
{
  G4Material *GridMeshAluminium = G4Material::GetMaterial("GridMeshAluminium");
  G4Material *AnodeMesh = G4Material::GetMaterial("AnodeMesh");
  G4Material *TopScreeningMesh = G4Material::GetMaterial(G4String("TopScreeningMesh"));
  G4Material *GateMesh = G4Material::GetMaterial("GateMesh");

  G4double dGridRadius = GetGeometryParameter("TPCinnRadius");
  G4double dGridHeight = GetGeometryParameter("GridMeshThickness");
  
  G4double dTopPlateOffsetZ = GetGeometryParameter("TopPlateOffsetZ");
  G4double dTopPmtHolderOffsetZ = dTopPlateOffsetZ - GetGeometryParameter("TopPlateHeight")*0.5 - GetGeometryParameter("DistanceTopPlateFromTopPmtHolder") - GetGeometryParameter("TopPmtHolderHeight")*0.5;
  G4double dTopPMTCopperOffsetZ = dTopPmtHolderOffsetZ - GetGeometryParameter("TopPmtHolderHeight")*0.5 - GetGeometryParameter("DistanceTopPmtHolderFromTopPMTCopper") - GetGeometryParameter("TopPMTCopperHeight")*0.5; 
  G4double dTopPTFEOffsetZ = dTopPMTCopperOffsetZ - GetGeometryParameter("TopPMTCopperHeight")*0.5 - GetGeometryParameter("DistanceTopPMTCopperFromTopPTFE") - GetGeometryParameter("TopPTFEHeight")*0.5; 
  G4double dTopElectrodePTFEOffsetZ     = dTopPTFEOffsetZ - GetGeometryParameter("TopPTFEHeight")*0.5 - GetGeometryParameter("DistanceTopPTFEFromTopElectrodePTFE") - GetGeometryParameter("TopElectrodePTFEHeight")*0.5;
  G4double dSSPlateOffsetZ    = dTopElectrodePTFEOffsetZ - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5 - GetGeometryParameter("SSPlateHeight")*0.5;
 
  G4double dTopMeshRingOffsetZ      = dTopPTFEOffsetZ - GetGeometryParameter("TopPTFEHeight")*0.5 - GetGeometryParameter("TopMeshRingHeight")*0.5;
  G4double dAnodeRingOffsetZ_1      = dTopElectrodePTFEOffsetZ - GetGeometryParameter("TopElectrodePTFEHeight")*0.5 + GetGeometryParameter("dHeight_TopElectrodePTFEbelowAnode")*0.5 + GetGeometryParameter("dAnodeRingHeight_1")*0.5;
  G4double dAnodeRingOffsetZ_2      = dAnodeRingOffsetZ_1 + GetGeometryParameter("AnodeRingHeight_1")*0.5 + GetGeometryParameter("AnodeRingHeight_2")*0.5;
  G4double dGateRingOffsetZ       = dSSPlateOffsetZ + GetGeometryParameter("SSPlateHeight")*0.5 - GetGeometryParameter("GateRingHeight")*0.5;
   
  G4double dTopGridMeshZ    = dTopMeshRingOffsetZ - GetGeometryParameter("TopMeshRingHeight")*0.5 + dGridHeight*0.5;
  G4double dAnodeZ          = dAnodeRingOffsetZ_1 - GetGeometryParameter("AnodeRingHeight_1")*0.5 + GetGeometryParameter("dHeight_TopElectrodePTFEbelowAnode") + dGridHeight*0.5 + 2.*mm;
  G4double dGroundZ         = dGateRingOffsetZ + GetGeometryParameter("GateRingHeight")*0.5 - dGridHeight*0.5 - GetGeometryParameter("Height_TopElectrodePTFEbelowAnode")*0.5;
  
  G4Tubs *pTopGridMesh = new G4Tubs("TubeTopGrid", 0., dGridRadius, dGridHeight*0.5, 0, 2*M_PI);
  m_pTopGridMeshLogicalVolume = new G4LogicalVolume(pTopGridMesh,TopScreeningMesh , "TopGridMeshLogicalVolume", 0, 0, 0);
  m_pTopGridMeshPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTopGridMeshZ), 
  						   m_pTopGridMeshLogicalVolume, "GridMeshAluminium_TopMesh",
  						   m_pGXeLogicalVolume, false, 0);

  G4Tubs *pAnode = new G4Tubs("TubeAnode", 0., dGridRadius, dGridHeight*0.5, 0, 2*M_PI);
  m_pAnodeMeshLogicalVolume = new G4LogicalVolume(pAnode, AnodeMesh, "AnodeMeshLogicalVolume", 0, 0, 0);
  m_pAnodeMeshPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dAnodeZ), 
						 m_pAnodeMeshLogicalVolume, "GridMeshAluminium_Anode",
						 m_pGXeLogicalVolume, false, 0);

  G4Tubs *pGround = new G4Tubs("TubeGround", 0., dGridRadius, dGridHeight*0.5, 0, 2*M_PI);
  m_pGroundMeshLogicalVolume = new G4LogicalVolume(pGround, GateMesh, "GroundMeshLogicalVolume", 0, 0, 0);
  m_pGroundMeshPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dGroundZ), 
   						  m_pGroundMeshLogicalVolume, "GridMeshAluminium_Ground", m_pLXeLogicalVolume, false, 0);

  G4Colour hGridColor(0.4, 0.5, 0.7, 0.01);
  G4VisAttributes *pGridVisAtt = new G4VisAttributes(hGridColor);
  pGridVisAtt->SetVisibility(false);
  m_pTopGridMeshLogicalVolume->SetVisAttributes(pGridVisAtt);
  m_pAnodeMeshLogicalVolume->SetVisAttributes(pGridVisAtt);
  m_pGroundMeshLogicalVolume->SetVisAttributes(pGridVisAtt);
 
}


void
Xenon1tDetectorConstruction::ConstructHVFT()
{

  G4Material *SS316Ti = G4Material::GetMaterial("SS316Ti");
  G4Material *poly = G4Material::GetMaterial("poly");  
  G4Material *Air = G4Material::GetMaterial("G4_AIR");
  
  G4double HVFT_center_position = /*( GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness") - ( GetGeometryParameter("TPCinnRadius") + GetGeometryParameter("TPCthikness") + GetGeometryParameter("FieldShaperRingsThickness") ) )*0.5;*/ GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness") - 17.*mm;// - GetGeometryParameter("HVFT_OuterSS_Radius") - GetGeometryParameter("HVFTdistanceFromInnerCryostat");
  G4double dHVFT_angular_Offset = GetGeometryParameter("HVFT_angular_Offset");  
  G4double HVFT_x_Offset = HVFT_center_position * cos(dHVFT_angular_Offset);
  G4double HVFT_y_Offset = HVFT_center_position * sin(dHVFT_angular_Offset);// + 12.5*mm;
  
  G4double dHVFT_OuterSS_Radius    = GetGeometryParameter("HVFT_OuterSS_Radius");
  G4double dHVFT_InnerPoly_Radius  = GetGeometryParameter("HVFT_InnerPoly_Radius");
  G4double dHVFT_BottInnSS_Radius  = GetGeometryParameter("HVFT_BottInnSS_Radius");
  G4double dHVFT_lastBottSS_Radius = GetGeometryParameter("HVFT_lastBottSS_Radius");
  
  G4double Tot_hvft_height_LXe    = 478.*mm;
  G4double dHVFT_InnerPoly_Height = GetGeometryParameter("HVFT_InnerPoly_Height");
  G4double OuterSS_height_LXe     = Tot_hvft_height_LXe - dHVFT_InnerPoly_Height;
  G4double HVFT_OffsetZ           = 301.782*mm;
  G4double BottomHVFT_OffsetZ     = HVFT_OffsetZ - OuterSS_height_LXe*0.5 - dHVFT_InnerPoly_Height*0.5;
  G4double dlastSShvft_height     = GetGeometryParameter("lastSShvft_height"); 
  G4double lastHVFT_OffsetZ       = BottomHVFT_OffsetZ - dHVFT_InnerPoly_Height*0.5 - dlastSShvft_height*0.5;
  
  G4double OuterSS_height_GXe     = 241*mm;
  G4double HVFT_GXe_OffsetZ       = HVFT_OffsetZ + OuterSS_height_LXe*0.5 + OuterSS_height_GXe*0.5;
  //____________________________________________________ GXe HVFT ___________________________________________________________________
  G4Tubs *pOuterSS_GXeHVFT = new G4Tubs("OuterSSGXe", 0., dHVFT_OuterSS_Radius, OuterSS_height_GXe*0.5, 0, 2*M_PI);
  m_pOuterSS_GXeHVFT_LogicalVolume = new G4LogicalVolume(pOuterSS_GXeHVFT, SS316Ti, "OuterSS_GXeHVFT_LogicalVolume", 0, 0, 0);
  m_pOuterSS_GXeHVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(HVFT_x_Offset,HVFT_y_Offset,HVFT_GXe_OffsetZ), 
  							m_pOuterSS_GXeHVFT_LogicalVolume, "SS_HVFT_GXeOuter", m_pGXeLogicalVolume, false, 0);
  
  G4Tubs *pInnerPoly_GXeHVFT = new G4Tubs("InnerPolyGXeHVFT", 0., dHVFT_InnerPoly_Radius, OuterSS_height_GXe*0.5, 0, 2*M_PI);
  m_pInnerPoly_GXeHVFT_LogicalVolume = new G4LogicalVolume(pInnerPoly_GXeHVFT, poly, "InnerPoly_GXeHVFT_LogicalVolume", 0, 0, 0);
  m_pInnerPoly_GXeHVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerPoly_GXeHVFT_LogicalVolume, "poly_HVFT_GXe_Inner", 
  							  m_pOuterSS_GXeHVFT_LogicalVolume, false, 0);
  
  G4Tubs *pInnerAir_GXeHVFT = new G4Tubs("InnerAir_GXeHVFT", 0., dHVFT_lastBottSS_Radius, OuterSS_height_GXe*0.5, 0, 2*M_PI);
  m_pInnerAir_GXeHVFT_LogicalVolume = new G4LogicalVolume(pInnerAir_GXeHVFT, Air, "InnerAir_GXeHVFT_LogicalVolume", 0, 0, 0);
  m_pInnerAir_GXeHVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerAir_GXeHVFT_LogicalVolume, 
  							 "Air_HVFT_GXeInner_HVFT", m_pInnerPoly_GXeHVFT_LogicalVolume, false, 0);
  
  G4Tubs *pInnerSS_GXeHVFT = new G4Tubs("InnerSS_HVFT", 0., dHVFT_BottInnSS_Radius, OuterSS_height_GXe*0.5, 0, 2*M_PI);
  m_pInnerSS_GXeHVFT_LogicalVolume = new G4LogicalVolume(pInnerSS_GXeHVFT, SS316Ti, "InnerSS_GXeHVFT_LogicalVolume", 0, 0, 0);
  m_pInnerSS_GXeHVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerSS_GXeHVFT_LogicalVolume, "SS_HVFT_GXeInnerSS", 
  							m_pInnerAir_GXeHVFT_LogicalVolume, false, 0);
  
  G4Tubs *pInnerInAir_GXeHVFT = new G4Tubs("InnerInAir_HVFT", 0., 5.5*mm, OuterSS_height_GXe*0.5, 0, 2*M_PI);
  m_pInnerInAir_GXeHVFT_LogicalVolume = new G4LogicalVolume(pInnerInAir_GXeHVFT, Air, "InnerInAir_GXeHVFT_LogicalVolume", 0, 0, 0);
  m_pInnerInAir_GXeHVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerInAir_GXeHVFT_LogicalVolume, 
  							   "Air_HVFT_InnerIn_GXeHVFT", m_pInnerSS_GXeHVFT_LogicalVolume, false, 0);
  
  //____________________________________________________ LXe HVFT ___________________________________________________________________
  G4Tubs *pOuterSS_HVFT = new G4Tubs("OuterSS", 0., dHVFT_OuterSS_Radius, OuterSS_height_LXe*0.5, 0, 2*M_PI);
  m_pOuterSS_HVFT_LogicalVolume = new G4LogicalVolume(pOuterSS_HVFT, SS316Ti, "OuterSS_HVFT_LogicalVolume", 0, 0, 0);
  m_pOuterSS_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(HVFT_x_Offset,HVFT_y_Offset,HVFT_OffsetZ), 
						     m_pOuterSS_HVFT_LogicalVolume, "SS_HVFT_Outer", m_pMotherLogicalVolume, false, 0);

  G4Tubs *pInnerPoly_HVFT = new G4Tubs("InnerPolyHVFT", 0., dHVFT_InnerPoly_Radius, OuterSS_height_LXe*0.5, 0, 2*M_PI);
  m_pInnerPoly_HVFT_LogicalVolume = new G4LogicalVolume(pInnerPoly_HVFT, poly, "InnerPoly_HVFT_LogicalVolume", 0, 0, 0);
  m_pInnerPoly_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerPoly_HVFT_LogicalVolume, "poly_HVFT_Inner", 
						       m_pOuterSS_HVFT_LogicalVolume, false, 0);

  G4Tubs *pInnerAir_HVFT = new G4Tubs("InnerAir_HVFT", 0., dHVFT_lastBottSS_Radius, OuterSS_height_LXe*0.5, 0, 2*M_PI);
  m_pInnerAir_HVFT_LogicalVolume = new G4LogicalVolume(pInnerAir_HVFT, Air, "InnerAir_HVFT_LogicalVolume", 0, 0, 0);
  m_pInnerAir_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerAir_HVFT_LogicalVolume, "Air_HVFT_Inner_HVFT", 
						      m_pInnerPoly_HVFT_LogicalVolume, false, 0);

  G4Tubs *pInnerSS_HVFT = new G4Tubs("InnerSS_HVFT", 0., dHVFT_BottInnSS_Radius, OuterSS_height_LXe*0.5, 0, 2*M_PI);
  m_pInnerSS_HVFT_LogicalVolume = new G4LogicalVolume(pInnerSS_HVFT, SS316Ti, "InnerSS_HVFT_LogicalVolume", 0, 0, 0);
  m_pInnerSS_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerSS_HVFT_LogicalVolume, "SS_HVFT_InnerSS", 
						     m_pInnerAir_HVFT_LogicalVolume, false, 0);
  
  G4Tubs *pInnerInAir_HVFT = new G4Tubs("InnerInAir_HVFT", 0., 5.5*mm, OuterSS_height_LXe*0.5, 0, 2*M_PI);
  m_pInnerInAir_HVFT_LogicalVolume = new G4LogicalVolume(pInnerInAir_HVFT, Air, "InnerInAir_HVFT_LogicalVolume", 0, 0, 0);
  m_pInnerInAir_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pInnerInAir_HVFT_LogicalVolume, "Air_HVFT_InnerIn_HVFT", 
							m_pInnerSS_HVFT_LogicalVolume, false, 0);
  
  //________________________________________________ lower HVFT ___________________________________________________________________________
  G4Tubs *pBottom_Poly_HVFT = new G4Tubs("Bottom_Poly_HVFT", 0., dHVFT_InnerPoly_Radius, dHVFT_InnerPoly_Height*0.5, 0, 2*M_PI);
  m_pBottom_Poly_HVFT_LogicalVolume = new G4LogicalVolume(pBottom_Poly_HVFT, poly, "Bottom_Poly_HVFT_LogicalVolume", 0, 0, 0);
  m_pBottom_Poly_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(HVFT_x_Offset,HVFT_y_Offset,BottomHVFT_OffsetZ), 
							 m_pBottom_Poly_HVFT_LogicalVolume, "poly_HVFT_Bottom", m_pLXeLogicalVolume , false, 0);

  G4Tubs *pBottom_InnerAir_HVFT = new G4Tubs("Bottom_InnerAir_HVFT", 0., dHVFT_lastBottSS_Radius, dHVFT_InnerPoly_Height*0.5, 0, 2*M_PI);
  m_pBottom_InnerAir_HVFT_LogicalVolume = new G4LogicalVolume(pBottom_InnerAir_HVFT, Air, "Bottom_InnerAir_HVFT_LogicalVolume", 0, 0, 0);
  m_pBottom_InnerAir_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pBottom_InnerAir_HVFT_LogicalVolume, 
							     "Air_HVFT_Bottom_Inner", m_pBottom_Poly_HVFT_LogicalVolume, false, 0);

  G4Tubs *pBottom_InnerSS_HVFT = new G4Tubs("Bottom_InnerSS_HVFT", 0., dHVFT_BottInnSS_Radius, dHVFT_InnerPoly_Height*0.5, 0, 2*M_PI);
  m_pBottom_InnerSS_HVFT_LogicalVolume = new G4LogicalVolume(pBottom_InnerSS_HVFT, SS316Ti, "Bottom_InnerSS_HVFT_LogicalVolume", 0, 0, 0);
  m_pBottom_InnerSS_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pBottom_InnerSS_HVFT_LogicalVolume, 
							    "SS_HVFT_Bottom_InnerSS", m_pBottom_InnerAir_HVFT_LogicalVolume, false, 0);
  
  G4Tubs *pBottom_InnerInAir_HVFT = new G4Tubs("Bottom_InnerInAir_HVFT", 0., 5.5*mm, dHVFT_InnerPoly_Height*0.5, 0, 2*M_PI);
  m_pBottom_InnerInAir_HVFT_LogicalVolume = new G4LogicalVolume(pBottom_InnerInAir_HVFT, Air, "Bottom_InnerInAir_HVFT_LogicalVolume", 0, 0, 0);
  m_pBottom_InnerInAir_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_pBottom_InnerInAir_HVFT_LogicalVolume, 
							       "Air_HVFT_Bottom_InnerIn", m_pBottom_InnerSS_HVFT_LogicalVolume, false, 0);
  
  // // //________________ lowest HVFT _________________________________________________________
  G4Tubs *plast_bottom_SS_HVFT = new G4Tubs("last_bottom_SS_HVFT", 0., dHVFT_lastBottSS_Radius, dlastSShvft_height*0.5, 0, 2*M_PI);
  m_plast_bottom_SS_HVFT_LogicalVolume = new G4LogicalVolume(plast_bottom_SS_HVFT, SS316Ti, "last_bottom_SS_HVFT_LogicalVolume", 0, 0, 0);
  m_plast_bottom_SS_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(HVFT_x_Offset,HVFT_y_Offset,lastHVFT_OffsetZ), 
							    m_plast_bottom_SS_HVFT_LogicalVolume, "SS_HVFT_last_bottom", 
							    m_pLXeLogicalVolume, false, 0);
  
  G4Tubs *plast_bottom_Air_HVFT = new G4Tubs("last_bottom_Air_HVFT", 0., 5.85*mm, dlastSShvft_height*0.5, 0, 2*M_PI);
  m_plast_bottom_Air_HVFT_LogicalVolume = new G4LogicalVolume(plast_bottom_Air_HVFT, SS316Ti, "last_bottom_Air_HVFT_LogicalVolume", 0, 0, 0);
  m_plast_bottom_Air_HVFT_PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,0.), m_plast_bottom_Air_HVFT_LogicalVolume, 
							     "Air_HVFT_last_bottom", m_plast_bottom_SS_HVFT_LogicalVolume, false, 0);

  G4Colour hTeflonColor(0.5, 0.3, 0.2, 0.01);
  G4VisAttributes *pTeflonVisAtt = new G4VisAttributes(hTeflonColor);
  pTeflonVisAtt->SetVisibility(true);
  m_pInnerPoly_GXeHVFT_LogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pInnerPoly_HVFT_LogicalVolume->SetVisAttributes(pTeflonVisAtt);
  m_pBottom_Poly_HVFT_LogicalVolume->SetVisAttributes(pTeflonVisAtt);
  
  G4Colour hSSColor(0.600, 0.600, 0.600, 0.1);
  G4VisAttributes *pSSVisAtt = new G4VisAttributes(hSSColor);
  pSSVisAtt->SetVisibility(true);
  m_pOuterSS_GXeHVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pInnerSS_GXeHVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pOuterSS_HVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pInnerSS_HVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_pBottom_InnerSS_HVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);
  m_plast_bottom_SS_HVFT_LogicalVolume->SetVisAttributes(pSSVisAtt);

}


void
Xenon1tDetectorConstruction::ConstructVetoPMTArrays()
{
  G4Material *Quartz = G4Material::GetMaterial("Quartz");
  G4Material *SS304LSteel = G4Material::GetMaterial("SS304LSteel");
  G4Material *Vacuum = G4Material::GetMaterial("Vacuum");
  G4Material *PhotoCathodeAluminium = G4Material::GetMaterial("PhotoCathodeAluminium");
  
  //==================================== 10" PMTs ===================================== (Hamamatsu R7081MOD-ASSY)
  const G4double dPMTWindowOuterRadius = GetGeometryParameter("PMTWindowOuterRadius");
  const G4double dPMTWindowOuterHalfZ = GetGeometryParameter("PMTWindowOuterHalfZ");
  const G4double dPMTWindowTopZ = GetGeometryParameter("PMTWindowTopZ");
  const G4double dPMTPhotocathodeOuterRadius = GetGeometryParameter("PMTPhotocathodeOuterRadius");
  const G4double dPMTPhotocathodeOuterHalfZ = GetGeometryParameter("PMTPhotocathodeOuterHalfZ");
  const G4double dPMTPhotocathodeTopZ = GetGeometryParameter("PMTPhotocathodeTopZ");
  const G4double dPMTPhotocathodeInnerRadius = GetGeometryParameter("PMTPhotocathodeInnerRadius");
  const G4double dPMTPhotocathodeInnerHalfZ = GetGeometryParameter("PMTPhotocathodeInnerHalfZ");
  const G4double dPMTBodyOuterRadius = GetGeometryParameter("PMTBodyOuterRadius");
  const G4double dPMTBodyInnerRadius = GetGeometryParameter("PMTBodyInnerRadius");
  const G4double dPMTBodyHeight = GetGeometryParameter("PMTBodyHeight");
  const G4double dPMTBaseOuterRadius = GetGeometryParameter("PMTBaseOuterRadius");
  const G4double dPMTBaseInnerRadius = GetGeometryParameter("PMTBaseInnerRadius");
  const G4double dPMTBaseHeight = GetGeometryParameter("PMTBaseHeight");
  const G4double dPMTBaseInteriorHeight = GetGeometryParameter("PMTBaseInteriorHeight");
  
  //--------------------------------- PMT window ----------------------------------
  G4Ellipsoid *pPMTWindowEllipsoid = new G4Ellipsoid("PMTWindowEllipsoid", dPMTWindowOuterRadius, dPMTWindowOuterRadius, dPMTWindowOuterHalfZ, -dPMTWindowOuterHalfZ, dPMTWindowTopZ);
  
  m_pPMTWindowLogicalVolume = new G4LogicalVolume(pPMTWindowEllipsoid, Quartz, "PMTWindowVolume", 0, 0, 0);
  
  //--------------------------------- PMT photocathode ----------------------------------
  G4Ellipsoid *pPMTPhotocathodeEllipsoid = new G4Ellipsoid("PMTPhotocathodeEllipsoid", dPMTPhotocathodeOuterRadius, dPMTPhotocathodeOuterRadius, dPMTPhotocathodeOuterHalfZ, -dPMTPhotocathodeOuterHalfZ, dPMTPhotocathodeTopZ);
  
  m_pPMTPhotocathodeLogicalVolume = new G4LogicalVolume(pPMTPhotocathodeEllipsoid, PhotoCathodeAluminium, "PMTPhotocathodeVolume", 0, 0, 0);
  
  m_pPMTPhotocathodePhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
                                                       m_pPMTPhotocathodeLogicalVolume, "PMTPhotocathode", m_pPMTWindowLogicalVolume, false, 0);
  
  //--------------------------------- PMT photocathode interior 1 ----------------------------------
  G4Ellipsoid *pPMTPhotocathodeInterior1Ellipsoid = new G4Ellipsoid("PMTPhotocathodeInterior1Ellipsoid", dPMTPhotocathodeInnerRadius, dPMTPhotocathodeInnerRadius, dPMTPhotocathodeInnerHalfZ, -dPMTPhotocathodeInnerHalfZ, dPMTPhotocathodeTopZ);
  
  m_pPMTPhotocathodeInterior1LogicalVolume = new G4LogicalVolume(pPMTPhotocathodeInterior1Ellipsoid, Vacuum, "PMTPhotocathodeInterior1LogicalVolume", 0, 0, 0);
  
  m_pPMTPhotocathodeInterior1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
                                                                m_pPMTPhotocathodeInterior1LogicalVolume, "PMTPhotocathodeInterior1", m_pPMTPhotocathodeLogicalVolume, false, 0);
  
  //--------------------------------- PMT photocathode interior 2 ----------------------------------
  G4Ellipsoid *pPMTPhotocathodeInterior2Ellipsoid = new G4Ellipsoid("PMTPhotocathodeInterior2Ellipsoid", dPMTPhotocathodeInnerRadius, dPMTPhotocathodeInnerRadius, dPMTPhotocathodeInnerHalfZ, dPMTPhotocathodeTopZ, dPMTWindowTopZ);
  
  m_pPMTPhotocathodeInterior2LogicalVolume = new G4LogicalVolume(pPMTPhotocathodeInterior2Ellipsoid, Vacuum, "PMTPhotocathodeInterior2LogicalVolume", 0, 0, 0);
  
  m_pPMTPhotocathodeInterior2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
                                                                m_pPMTPhotocathodeInterior2LogicalVolume, "PMTPhotocathodeInterior2", m_pPMTWindowLogicalVolume, false, 0);
  
  //--------------------------------- PMT body ----------------------------------
  const G4double dPMTBodyHalfZ = 0.5*dPMTBodyHeight;
  
  G4Tubs *pPMTBodyTubs = new G4Tubs("PMTBodyTubs", 0, dPMTBodyOuterRadius, dPMTBodyHalfZ, 0.*deg, 360.*deg);
  
  m_pPMTBodyLogicalVolume = new G4LogicalVolume(pPMTBodyTubs, SS304LSteel, "PMTBodyVolume", 0, 0, 0);
  
  //--------------------------------- PMT body interior ----------------------------------
  G4Tubs *pPMTBodyInteriorTubs = new G4Tubs("PMTBodyInteriorTubs", 0, dPMTBodyInnerRadius, dPMTBodyHalfZ, 0.*deg, 360.*deg);
  
  m_pPMTBodyInteriorLogicalVolume = new G4LogicalVolume(pPMTBodyInteriorTubs, Vacuum, "PMTBodyInteriorVolume", 0, 0, 0);
  
  m_pPMTBodyInteriorPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
                                                       m_pPMTBodyInteriorLogicalVolume, "PMTBodyInterior", m_pPMTBodyLogicalVolume, false, 0);
  
  //--------------------------------- PMT base (not really the base but the bottom part of the pmt)----------------------------------
  const G4double dPMTBaseHalfZ = 0.5*dPMTBaseHeight;
  
  G4Tubs *pPMTBaseTubs = new G4Tubs("PMTBaseTubs", 0, dPMTBaseOuterRadius, dPMTBaseHalfZ, 0.*deg, 360.*deg);
  
  m_pPMTBaseLogicalVolume = new G4LogicalVolume(pPMTBaseTubs, SS304LSteel, "PMTBaseVolume", 0, 0, 0);
  
  //--------------------------------- PMT base interior ----------------------------------
  const G4double dPMTBaseInteriorHalfZ = 0.5*dPMTBaseInteriorHeight;
  
  G4Tubs *pPMTBaseInteriorTubs = new G4Tubs("PMTBaseInteriorTubs", 0, dPMTBaseInnerRadius, dPMTBaseInteriorHalfZ, 0.*deg, 360.*deg);
  
  m_pPMTBaseInteriorLogicalVolume = new G4LogicalVolume(pPMTBaseInteriorTubs, Vacuum, "PMTBaseInteriorVolume", 0, 0, 0);
  
  m_pPMTBaseInteriorPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0., 0., 0.),
                                                       m_pPMTBaseInteriorLogicalVolume, "PMTBaseInterior", m_pPMTBaseLogicalVolume, false, 0);
  
  //================================== Liquid scintillator arrays ==================================
  G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  G4int iNbBottomPMTs = (G4int) GetGeometryParameter("NbBottomPMTs");
  G4int iNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  
  stringstream hVolumeName;
  
  for(G4int iPMTNb=iNbTopPMTs+iNbBottomPMTs; iPMTNb<iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs; iPMTNb++)
    {
      // -----------------------   MS to remove the LS PMTs
      // 		hVolumeName.str(""); hVolumeName << "LSPMTWindowNo" << iPMTNb;
    
      // 		m_hPMTWindowPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
      // 			GetPMTPosition(iPMTNb, PMT_WINDOW), m_pPMTWindowLogicalVolume,
      // 			hVolumeName.str(), m_pLSLogicalVolume, false, iPMTNb));
    
      // 		hVolumeName.str(""); hVolumeName << "LSPMTBodyNo" << iPMTNb;
    
      // 		m_hPMTBodyPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
      // 			GetPMTPosition(iPMTNb, PMT_BODY), m_pPMTBodyLogicalVolume,
      // 			hVolumeName.str(), m_pLSLogicalVolume, false, iPMTNb));
    
      // 		hVolumeName.str(""); hVolumeName << "LSPMTBaseNo" << iPMTNb;
    
      // 		m_hPMTBasePhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
      // 			GetPMTPosition(iPMTNb, PMT_BASE), m_pPMTBaseLogicalVolume,
      // 			hVolumeName.str(), m_pLSLogicalVolume, false, iPMTNb));
    }
  
  //================================== Water arrays ==================================
  G4int iNbWaterPMTs = (G4int) GetGeometryParameter("NbWaterPMTs");
	
 
  for(G4int iPMTNb=iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs; iPMTNb<iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs+iNbWaterPMTs; iPMTNb++){
    //   /*	if(iPMTNb<=265){														// SERENA***********************************
     
    //    hVolumeName.str(""); hVolumeName << "WaterPMTWindowNo" << iPMTNb;
     
    //    m_hPMTWindowPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
    //    GetPMTPosition(iPMTNb, PMT_WINDOW), m_pPMTWindowLogicalVolume,
    //    hVolumeName.str(), m_pWaterConsLogicalVolume, false, iPMTNb));
     
    //    hVolumeName.str(""); hVolumeName << "WaterPMTBodyNo" << iPMTNb;
     
    //    m_hPMTBodyPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
    //    GetPMTPosition(iPMTNb, PMT_BODY), m_pPMTBodyLogicalVolume,
    //    hVolumeName.str(), m_pWaterConsLogicalVolume, false, iPMTNb));
     
    //    hVolumeName.str(""); hVolumeName << "WaterPMTBaseNo" << iPMTNb;
     
    //    m_hPMTBasePhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
    //    GetPMTPosition(iPMTNb, PMT_BASE), m_pPMTBaseLogicalVolume,
    //    hVolumeName.str(), m_pWaterConsLogicalVolume, false, iPMTNb));
    //    }
    //    */
    
    //   //	else{																	// *******************************************
    
    hVolumeName.str(""); hVolumeName << "WaterPMTWindowNo" << iPMTNb;
    
    m_hPMTWindowPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
                                                            GetPMTPosition(iPMTNb, PMT_WINDOW), m_pPMTWindowLogicalVolume,
                                                            hVolumeName.str(), m_pWaterLogicalVolume, false, iPMTNb));
		
    hVolumeName.str(""); hVolumeName << "WaterPMTBodyNo" << iPMTNb;
    
    m_hPMTBodyPhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
                                                          GetPMTPosition(iPMTNb, PMT_BODY), m_pPMTBodyLogicalVolume,
                                                          hVolumeName.str(), m_pWaterLogicalVolume, false, iPMTNb));
    
    hVolumeName.str(""); hVolumeName << "WaterPMTBaseNo" << iPMTNb;
    
    m_hPMTBasePhysicalVolumes.push_back(new G4PVPlacement(GetPMTRotation(iPMTNb),
                                                          GetPMTPosition(iPMTNb, PMT_BASE), m_pPMTBaseLogicalVolume,
                                                          hVolumeName.str(), m_pWaterLogicalVolume, false, iPMTNb));
    
    //}
    
  }
  
  
  
  //------------------------------- PMT sensitivity -------------------------------
  // Paolo, Cyril for else part
  G4SDManager *pSDManager = G4SDManager::GetSDMpointer();
 
  if(pSDManager->GetCollectionID("PmtHitsCollection")==-1)
    {
      // Add new sensitive det
      pPmtSD = new Xenon1tPmtSensitiveDetector("Xenon1t/PmtSD");
      pSDManager->AddNewDetector(pPmtSD);
      m_pPMTPhotocathodeLogicalVolume->SetSensitiveDetector(pPmtSD);
    }
  else
    {
      // use old sensitive det
      G4VSensitiveDetector *pPmtSD = pSDManager->FindSensitiveDetector("Xenon1t/PmtSD", true);
      m_pPMTPhotocathodeLogicalVolume->SetSensitiveDetector(pPmtSD);
    }	
	
  
  //------------------------------- PMT sensitivity -------------------------------
  //m_pPMTPhotocathodeLogicalVolume->SetSensitiveDetector(pPmtSD);

  //---------------------------------- attributes ---------------------------------
  
  m_pPMTPhotocathodeInterior1LogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  m_pPMTPhotocathodeInterior2LogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  m_pPMTBodyInteriorLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  m_pPMTBaseInteriorLogicalVolume->SetVisAttributes(G4VisAttributes::Invisible);
  
  G4Colour hPMTWindowColor(1., 0.757, 0.024);
  G4VisAttributes *pPMTWindowVisAtt = new G4VisAttributes(hPMTWindowColor);
  pPMTWindowVisAtt->SetVisibility(true);
  m_pPMTWindowLogicalVolume->SetVisAttributes(pPMTWindowVisAtt);
  
  G4Colour hPMTPhotocathodeColor(1., 0.082, 0.011);
  G4VisAttributes *pPMTPhotocathodeVisAtt = new G4VisAttributes(hPMTPhotocathodeColor);
  pPMTPhotocathodeVisAtt->SetVisibility(true);
  m_pPMTPhotocathodeLogicalVolume->SetVisAttributes(pPMTPhotocathodeVisAtt);
  
  G4Colour hPMTCasingColor(1., 0.486, 0.027);
  G4VisAttributes *pPMTCasingVisAtt = new G4VisAttributes(hPMTCasingColor);
  pPMTCasingVisAtt->SetVisibility(true);
  m_pPMTBodyLogicalVolume->SetVisAttributes(pPMTCasingVisAtt);
  m_pPMTBaseLogicalVolume->SetVisAttributes(pPMTCasingVisAtt);
}

void
Xenon1tDetectorConstruction::ConstructLXeVetoPMTArrays()
{
  // Cyril, 2013/10/16 for version 1

  G4Material *Cirlex  = G4Material::GetMaterial("Cirlex");
  G4Material *Teflon = G4Material::GetMaterial("Teflon");

  //----- PTFE outer layer (Cyril, 2013/10/17)
  G4double dTpcHeight    = GetGeometryParameter("TPCheight");
  G4double dTpcOffsetZ   =  GetGeometryParameter("TpcOffsetZ");
  G4double dTeflonOuterLayerRadius = GetGeometryParameter("InnerCryostatOuterDiameter")*0.5-GetGeometryParameter("InnerCryostatThickness")- 0.5*mm;//GetGeometryParameter("TeflonOuterLayerRadius");
  G4double dTeflonOuterLayerThickness = GetGeometryParameter("TeflonOuterLayerThickness");
  G4double dTeflonOuterLayerHeight = GetGeometryParameter("TeflonOuterLayerHeight");
  G4double dTeflonOuterLayerOffsetZ = dTpcOffsetZ - (dTeflonOuterLayerHeight - dTpcHeight) * 0.5;
  
  G4Tubs *pTeflonLayerTubs = new G4Tubs("TeflonLayer", dTeflonOuterLayerRadius-0.5*dTeflonOuterLayerThickness,  
					dTeflonOuterLayerRadius+0.5*dTeflonOuterLayerThickness,dTeflonOuterLayerHeight*0.5 , 0.*deg, 360.*deg);
  
  m_pPTFELayerCryoLogicalVolume = new G4LogicalVolume(pTeflonLayerTubs, Teflon, "PTFELayerLogicalVolume", 0, 0, 0);
  m_pPTFELayerCryoPhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dTeflonOuterLayerOffsetZ), m_pPTFELayerCryoLogicalVolume, 
  						     "Teflon_LayerCryo",m_pMotherLogicalVolume, false, 0);
  
   
  G4double dSigmaAlpha = 0.1;
  G4OpticalSurface *pTeflonOpticalSurface = new G4OpticalSurface("TeflonOpticalSurface", unified, groundbackpainted, dielectric_dielectric, dSigmaAlpha);
  pTeflonOpticalSurface->SetMaterialPropertiesTable(Teflon->GetMaterialPropertiesTable());
  new G4LogicalBorderSurface("TeflonLayerCryoLogicalBorderSurface",    m_pLXePhysicalVolume, m_pPTFELayerCryoPhysicalVolume, pTeflonOpticalSurface); // Teflon_OuterLayer
     


  //----- PTFE inner layer (Cyril, 2013/10/22)

  G4double dTpcInRadius  = GetGeometryParameter("TPCinnRadius");
  G4int dNbofPTFEpillar               = GetGeometryParameter("NbofPTFEpillar");
  G4double ddSpaceTPC_fieldRing = 3.68*mm;
					  
  G4double PTFEpillarCenterRadius = GetGeometryParameter("SSPlateInnRad") + GetGeometryParameter("SSPlateThickness") + 0.5*mm;    //GetGeometryParameter("BottomPTFErad") + GetGeometryParameter("cathodeSupport_y") + 1.*mm;//dTpcInRadius + GetGeometryParameter("TPCthikness") + GetGeometryParameter("TopBoxBase_y") + ddSpaceTPC_fieldRing;//dTpcInRadius + GetGeometryParameter("TPCthikness") + GetGeometryParameter("TopBoxBase_y")*0.5;
  
  G4double PTFEpillarAngularStep = GetGeometryParameter("deltaTheta");
  
  G4double dBelowTpcRingOffsetZ  = dTpcOffsetZ - GetGeometryParameter("TPCheight")*0.5 - GetGeometryParameter("BelowTPCringHeight")*0.5;
  G4double dOuterTpcRingOffsetZ  = dBelowTpcRingOffsetZ - GetGeometryParameter("BelowTPCringHeight")*0.5 - GetGeometryParameter("OuterTpcRingHeight")*0.5;
  G4double dTeflonInnerLayerHeight    =  GetGeometryParameter("TeflonInnerLayerHeight");
  G4double dTeflonInnerLayerOffsetZ   = dTpcOffsetZ - (dTeflonInnerLayerHeight - dTpcHeight) * 0.5;
  G4double dTeflonInnerLayerThickness = GetGeometryParameter("TeflonInnerLayerThickness");
  G4double PTFEpillarCenterRadius_1   = GetGeometryParameter("TPCinnRadius") + GetGeometryParameter("TPCthikness") + 3.68*mm + GetGeometryParameter("FieldShaperRingsThickness") + 2.*mm;

  G4double AngularOffset         = GetGeometryParameter("TeflonInnerLayerAngularOffset"); 
  G4Tubs *pPTFEInWall = new G4Tubs("pPTFEInWall",PTFEpillarCenterRadius_1,PTFEpillarCenterRadius_1+dTeflonInnerLayerThickness,
				   dTeflonInnerLayerHeight*0.5, -6.3*deg, 12.6*deg);

  // G4Tubs *pPTFEInWall = new G4Tubs("pPTFEInWall", GetGeometryParameter("CopperRingInnRad")-dTeflonInnerLayerThickness,
  // 				   GetGeometryParameter("CopperRingInnRad"),
  // 				   dTeflonInnerLayerHeight*0.48, -6.3*deg, 12.6*deg);
  m_pPTFEInWallLogicalVolume = new G4LogicalVolume(pPTFEInWall, Teflon, "PTFEInWallLogicalVolume", 0, 0, 0);
  
  G4double PTFEplateCenter_x = 0;
  G4double PTFEplateCenter_y = 0;
  
  stringstream hVolumeName;

  for(int id=0; id<dNbofPTFEpillar; id++)
    {
      G4RotationMatrix *zRot         = new G4RotationMatrix();
      zRot->rotateZ(AngularOffset);   
     
      hVolumeName.str("");
      hVolumeName << "Teflon_InWall_" << id;
      m_pPTFEInWallPhysicalVolume.push_back(new G4PVPlacement(zRot, G4ThreeVector(PTFEplateCenter_x, PTFEplateCenter_y, 
										  dTeflonInnerLayerOffsetZ-13.*mm),m_pPTFEInWallLogicalVolume, 
							      hVolumeName.str(), m_pMotherLogicalVolume, false, 0));
      
      G4VPhysicalVolume *PTFEPlatePhysicalVolume = (G4VPhysicalVolume*)m_pPTFEInWallPhysicalVolume.at(id);
      hVolumeName.str(""); 
      hVolumeName << "Teflon_PlateLogicalBorderSurface_" << id;
      new G4LogicalBorderSurface(hVolumeName.str(),m_pLXePhysicalVolume,PTFEPlatePhysicalVolume ,pTeflonOpticalSurface );
      
      
      G4VPhysicalVolume *PTFEPillarPhysicalVolume = (G4VPhysicalVolume*)m_pPTFEpillarPhysicalVolume.at(id);
      hVolumeName.str(""); 
      hVolumeName << "Teflon_PillarLogicalBorderSurface_" << id;
      new G4LogicalBorderSurface(hVolumeName.str(),m_pLXePhysicalVolume,PTFEPillarPhysicalVolume,pTeflonOpticalSurface );

      AngularOffset += PTFEpillarAngularStep;
    }
  
  
  
  //----------  PTFE Layer Above TPC (v4) ----------
  // in the LXe layer above the gas phase
  
  G4double dTeflonAboveTPCRadius1 = GetGeometryParameter("LXeTopRadius"); 
  G4double dPTFEAboveTPCHeight1 = GetGeometryParameter("TeflonPlateAboveTPCThickness"); 
  G4double dLXeTopCutShiftZ       = GetGeometryParameter("TopPlateOffsetZ") + GetGeometryParameter("TopPlateHeight")*0.5 + 0.5*GetGeometryParameter("LXeTopHeight");
  G4double dPTFEAboveTPCOffsetZ1 = dLXeTopCutShiftZ-0.5*GetGeometryParameter("LXeTopHeight") + 0.5*dPTFEAboveTPCHeight1;
  G4double dPTFEAboveTPCOffsetZ2 =  dLXeTopCutShiftZ + 0.5*GetGeometryParameter("LXeTopHeight") - 0.5*dPTFEAboveTPCHeight1; 
    
  //G4double abovePMTOffsetZ = GetGeometryParameter("LXeVetoAbovePmtZOffset"); //cMS
  //G4double abovePMTOffsetZ = dLXeTopCutShiftZ-5.*mm - 10.7*mm;
  
  if(pTpcWithBell){        
    G4Tubs *pTeflonAboveTPCTubs1 = new G4Tubs("TeflonAboveTPC1", 0,dTeflonAboveTPCRadius1,dPTFEAboveTPCHeight1*0.5 , 0.*deg, 360.*deg);
    
    m_pPTFEAboveTPC1LogicalVolume = new G4LogicalVolume(pTeflonAboveTPCTubs1, Teflon, "Teflon_PlateAboveTPC1LogicalVolume", 0, 0, 0);
    m_pPTFEAboveTPC1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dPTFEAboveTPCOffsetZ1), m_pPTFEAboveTPC1LogicalVolume, "Teflon_PlateAboveTPC1",m_pLXeTopLogicalVolume, false, 0);
    
    new G4LogicalBorderSurface("TeflonAboveTPC1LogicalBorderSurface",    m_pLXeTopPhysicalVolume, m_pPTFEAboveTPC1PhysicalVolume, pTeflonOpticalSurface); // Teflon_OuterLayer
        
    
    G4double dTeflonAboveTPCRadius2 = GetGeometryParameter("LXeTopRadius");
    G4double dPTFEAboveTPCHeight2 = GetGeometryParameter("TeflonPlateAboveTPCThickness"); // 
    //G4double dPTFEAboveTPCOffsetZ2 = abovePMTOffsetZ +  0.5*GetGeometryParameter("LXeVetoPmtWidth") + 0.5*dPTFEAboveTPCHeight2 + 5*mm;
    
    G4Tubs *pTeflonAboveTPCTubs2 = new G4Tubs("TeflonAboveTPC2", 0,dTeflonAboveTPCRadius2,dPTFEAboveTPCHeight2*0.5 , 0.*deg, 360.*deg);
    
    m_pPTFEAboveTPC2LogicalVolume = new G4LogicalVolume(pTeflonAboveTPCTubs2, Teflon, "Teflon_PlateAboveTPC2LogicalVolume", 0, 0, 0);
    m_pPTFEAboveTPC2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dPTFEAboveTPCOffsetZ2), m_pPTFEAboveTPC2LogicalVolume, "Teflon_PlateAboveTPC2",m_pLXeTopLogicalVolume, false, 0);
    
    new G4LogicalBorderSurface("TeflonAboveTPC2LogicalBorderSurface",    m_pLXeTopPhysicalVolume, m_pPTFEAboveTPC2PhysicalVolume, pTeflonOpticalSurface); // Teflon_OuterLayer
  }
  
  G4double abovePMTOffsetZ = (dPTFEAboveTPCOffsetZ1 + dPTFEAboveTPCOffsetZ2)*0.5;
  
  //----------  PTFE Layer Below TPC (v4) ----------
  G4double dTeflonBelowTPCRadius1 = GetGeometryParameter("LXeTopRadius");
  G4double dPTFEBelowTPCHeight1 = GetGeometryParameter("TeflonPlateAboveTPCThickness"); // 
  //G4double dPTFEBelowTPCOffsetZ1 = GetGeometryParameter("LXeVetoBelowPmtZOffset")-0.5*GetGeometryParameter("LXeVetoPmtWidth")-0.5*dPTFEBelowTPCHeight1 - GetGeometryParameter("LXeVetoThicknessBottomVeto");
  G4double dPTFEBelowTPCOffsetZ1 = GetGeometryParameter("LXeVetoBelowPmtZOffset") - 0.5*dPTFEBelowTPCHeight1 - 0.5*GetGeometryParameter("LXeVetoThicknessBottomVeto") + 56.95*mm;

  G4Tubs *pTeflonBelowTPCTubs1 = new G4Tubs("TeflonBelowTPC1", 0,425.*mm,dPTFEBelowTPCHeight1*0.5 , 0.*deg, 360.*deg);
  m_pPTFEBelowTPC1LogicalVolume = new G4LogicalVolume(pTeflonBelowTPCTubs1, Teflon, "PTFEBelowTPC1LogicalVolume", 0, 0, 0);
  m_pPTFEBelowTPC1PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dPTFEBelowTPCOffsetZ1), m_pPTFEBelowTPC1LogicalVolume, 
						     "Teflon_PlateBelowTPC1",m_pLXeLogicalVolume, false, 0); // this is the bottom one
  
  new G4LogicalBorderSurface("TeflonBelowTPC1LogicalBorderSurface",    m_pLXePhysicalVolume, m_pPTFEBelowTPC1PhysicalVolume, pTeflonOpticalSurface); // Teflon_OuterLayer
    
  //  G4double dPTFEBelowTPCOffsetZ2 = GetGeometryParameter("LXeVetoBelowPmtZOffset")+0.5*GetGeometryParameter("LXeVetoPmtWidth")-0.5*dPTFEBelowTPCHeight1+10*mm;
  G4double dPTFEBelowTPCOffsetZ2 = dPTFEBelowTPCOffsetZ1 + GetGeometryParameter("LXeVetoThicknessBottomVeto") - 1.*mm;
  G4Tubs *pTeflonBelowTPCTubs2 = new G4Tubs("TeflonBelowTPC2", 0,465.*mm,dPTFEBelowTPCHeight1*0.5 , 0.*deg, 360.*deg);
  
  m_pPTFEBelowTPC2LogicalVolume = new G4LogicalVolume(pTeflonBelowTPCTubs2, Teflon, "PTFEBelowTPC2LogicalVolume", 0, 0, 0);
  m_pPTFEBelowTPC2PhysicalVolume = new G4PVPlacement(0, G4ThreeVector(0.,0.,dPTFEBelowTPCOffsetZ2), m_pPTFEBelowTPC2LogicalVolume, "Teflon_PlateBelowTPC2",m_pMotherLogicalVolume, false, 0); // this is the top one
  
  new G4LogicalBorderSurface("TeflonBelowTPC2LogicalBorderSurface",    m_pLXePhysicalVolume, m_pPTFEBelowTPC2PhysicalVolume, pTeflonOpticalSurface); // Teflon_OuterLayer


  // ---------- Define PMTs R8520  ----------
  
  G4RotationMatrix *pRotX180 = new G4RotationMatrix();
  pRotX180->rotateX(180.*deg);
  
  const G4double dVetoPmtBaseHalfX = 0.5*GetGeometryParameter("LXeVetoPmtCasingWidth"); 
  const G4double dVetoPmtBaseHalfZ = 0.5*GetGeometryParameter("LXeVetoPmtBaseThickness");
  const G4double dVetoPmtToPmtBase = GetGeometryParameter("LXeVetoPmtToPmtBase");
  const G4double dVetoPmtHalfZ = 0.5*(GetGeometryParameter("LXeVetoPmtWindowThickness")+GetGeometryParameter("LXeVetoPmtCasingHeight"));
  const G4double dVetoBaseOffset = dVetoPmtHalfZ+dVetoPmtToPmtBase+dVetoPmtBaseHalfZ;
  
  G4Box *pPMTBaseBox = new G4Box("LXeVetoPMTBaseBox", dVetoPmtBaseHalfX, dVetoPmtBaseHalfX, dVetoPmtBaseHalfZ);
  m_pVetoPMTBaseLogicalVolume = new G4LogicalVolume(pPMTBaseBox, Cirlex, "LXeVetoPMTBaseLogicalVolume", 0, 0, 0);

  G4int TotNbOfTopPMTs   = G4int(GetGeometryParameter("NbOfTopPMTs"));
  G4int TotNbBottomPMTs = (G4int) GetGeometryParameter("NbOfBottomPMTs");
  G4int TotNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  G4int TotNbWaterPMTs = (G4int) GetGeometryParameter("NbWaterPMTs");
  
  G4int TotNbTopLXeVetoPMTs   = G4int(GetGeometryParameter("NbTopLXeVetoPMTs"));
  G4int TotNbBottomLXeVetoPMTs   = G4int(GetGeometryParameter("NbBottomLXeVetoPMTs"));
  G4int TotNbAboveLXeVetoPMTs = (G4int)GetGeometryParameter("NbAboveLXeVetoPMTs");
  G4int TotNbBelowLXeVetoPMTs = (G4int)GetGeometryParameter("NbBelowLXeVetoPMTs");
  G4int TotNbCenterLXeVetoPMTs = (G4int)GetGeometryParameter("NbCenterLXeVetoPMTs");
				      
  // G4double dRadiusLXeVetoTopPmt    = ((GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness")) + (GetGeometryParameter("SSPlateInnRad") + GetGeometryParameter("SSPlateThickness")))*0.5;//GetGeometryParameter("LXeVetoTopPmtRadius"); 
  
  // G4double dRadiusLXeVetoBottomPmt = ((GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness")) + PTFEpillarCenterRadius)*0.5;//GetGeometryParameter("BottomHolderPlateRad"))*0.5;//GetGeometryParameter("LXeVetoBottomPmtRadius"); 
  
  G4double dRadiusLXeVetoTopPmt    = ((GetGeometryParameter("InnerCryostatOuterDiameter")*0.5 - GetGeometryParameter("InnerCryostatThickness") - dTeflonOuterLayerThickness) + (PTFEpillarCenterRadius_1+dTeflonInnerLayerThickness) )*0.5;
  G4double dRadiusLXeVetoBottomPmt = dRadiusLXeVetoTopPmt;
    
  G4double dRadiusLXeVetoAbovePmt  = GetGeometryParameter("LXeVetoAbovePmtRadius"); 
  G4double dRadiusLXeVetoBelowPmt  = GetGeometryParameter("LXeVetoBelowPmtRadius"); 
			      
  G4double bottomPMTOffsetZ = GetGeometryParameter("LXeVetoBottomPmtZOffset") + 13.*mm; 
  G4double topPMTOffsetZ = GetGeometryParameter("LXeVetoTopPmtZOffset");
  G4double dAngularStepAbove = GetGeometryParameter("LXeVetoAboveAngularStep");


  G4double dAngularStepPmts = GetGeometryParameter("LXeVetoAngularStepPMTs"); 
  G4double dAngularOffsetBunch = GetGeometryParameter("LXeVetoAngularOffsetBunch"); 
  G4int iNumberPMTsBunch = (G4int)GetGeometryParameter("LXeVetoNumberPMTsBunchTop");
  
  G4double dAngularStepBelowPmts = GetGeometryParameter("LXeVetoBelowAngularStepPMTs");
  //G4double belowPMTOffsetZ = GetGeometryParameter("LXeVetoBelowPmtZOffset")+40.2*mm;
  G4double belowPMTOffsetZ = (dPTFEBelowTPCOffsetZ1 + dPTFEBelowTPCOffsetZ2)*0.5;
    
  G4double centerPMTOffsetZ = GetGeometryParameter("LXeVetoCenterPmtZOffset");

  G4double dHVFTAngularOffset = GetGeometryParameter("HVFT_angular_Offset");
  G4double dThetaPMT = 0.;

  G4bool lxeVetoPmtOverlapHVFT = false;

  G4int ii = 0;
  
  // 1" PMTs are placed by bunches of iNumberPMTsBunch between the 24 PTFE pillars
  
  AngularOffset = dAngularOffsetBunch;
  
  // ---------- Lateral Bottom PMTs R8520  ----------
  G4double dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y;
  for(G4int iPMTNt=TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs; iPMTNt<TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs; ++iPMTNt)
    {
      // pmt0
      dThetaPMT = AngularOffset-dAngularStepPmts;
      G4RotationMatrix *zRot0         = new G4RotationMatrix();
      zRot0->rotateZ(180*deg-dThetaPMT);  
      zRot0->rotateX(180.*deg);  

      dLXeVetoPMTCenter_x  = dRadiusLXeVetoBottomPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoBottomPmt * sin(dThetaPMT); 
      //G4cout << "veto lat bot  " << dLXeVetoPMTCenter_x << "  "  << dLXeVetoPMTCenter_y << G4endl;
      hVolumeName.str(""); 
      hVolumeName << "PmtVetoLatBot_" << iPMTNt;
      
      m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,bottomPMTOffsetZ), 
      							m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
     
      hVolumeName.str(""); 
      hVolumeName << "PmtBaseVeto_" << iPMTNt;
      
      m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)
      							     -G4ThreeVector(0,0,dVetoBaseOffset),m_pVetoPMTBaseLogicalVolume, 
      							     hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
      
      iPMTNt++;

      if(iNumberPMTsBunch == 3){
	if(ii%4 != 0){
	  // pmt1
	  dThetaPMT = AngularOffset;
	  G4RotationMatrix *zRot1         = new G4RotationMatrix();
	  zRot1->rotateZ(180*deg-dThetaPMT);  
	  zRot1->rotateX(180.*deg);  
	  
	  dLXeVetoPMTCenter_x  = dRadiusLXeVetoBottomPmt * cos(dThetaPMT); 
	  dLXeVetoPMTCenter_y  = dRadiusLXeVetoBottomPmt * sin(dThetaPMT); 

  
	  hVolumeName.str(""); 
	  hVolumeName << "PmtVetoLatBot_" << iPMTNt;
	  
	  m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,bottomPMTOffsetZ), 
	  						    m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
	  
	  hVolumeName.str(""); 
	  hVolumeName << "PmtBaseVeto_" << iPMTNt;
	  
	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)-
	  							 G4ThreeVector(0,0,dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, 
	  							 hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	  
	}
	iPMTNt++;
      }

      // pmt2
      dThetaPMT = AngularOffset+dAngularStepPmts;
      G4RotationMatrix *zRot2         = new G4RotationMatrix();
      zRot2->rotateZ(180*deg-dThetaPMT);  
      zRot2->rotateX(180.*deg);  

      dLXeVetoPMTCenter_x  = dRadiusLXeVetoBottomPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoBottomPmt * sin(dThetaPMT); 
                    
      hVolumeName.str(""); 
      hVolumeName << "PmtVetoLatBot_" << iPMTNt;
      
      m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,bottomPMTOffsetZ), 
      							m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
    
      hVolumeName.str(""); 
      hVolumeName << "PmtBaseVeto_" << iPMTNt;
      
      m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)-
      							     G4ThreeVector(0,0,dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, 
      							     hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
     
      
      AngularOffset += PTFEpillarAngularStep;
      ii++;
    }
 
 
  ii = 0;
  AngularOffset         =  dAngularOffsetBunch;

  // ---------- Lateral Top PMTs R8520  ----------
  for(G4int iPMTNt=TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs; iPMTNt<TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs; ++iPMTNt)
    {
      // pmt0
      dThetaPMT = AngularOffset-dAngularStepPmts;

      G4RotationMatrix *zRot0         = new G4RotationMatrix();
      zRot0->rotateZ(180*deg-dThetaPMT);  
       
      dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
    
      hVolumeName.str(""); 
      hVolumeName << "PmtVetoLatTop_" << iPMTNt;
      //G4cout << "veto lat top  " << dLXeVetoPMTCenter_x << "  "  << dLXeVetoPMTCenter_y << G4endl;
      if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	lxeVetoPmtOverlapHVFT = true;
      }

      if(!lxeVetoPmtOverlapHVFT){
	m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,topPMTOffsetZ), 
							  m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
	
	hVolumeName.str(""); 
	hVolumeName << "PmtBaseVeto_" << iPMTNt;

	m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,topPMTOffsetZ)-
							       G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, 
							       hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
      
      }
      
      iPMTNt++;
      lxeVetoPmtOverlapHVFT = false;


      // pmt1
      if(iNumberPMTsBunch == 3){
  	dThetaPMT = AngularOffset;
	G4RotationMatrix *zRot1         = new G4RotationMatrix();
	zRot1->rotateZ(180*deg-dThetaPMT);  

	dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
	dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
      
	hVolumeName.str(""); 
	hVolumeName << "PmtVetoLatTop_" << iPMTNt;
      
	
	if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	  lxeVetoPmtOverlapHVFT = true;
	}
 
	if(!lxeVetoPmtOverlapHVFT){
	  m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,topPMTOffsetZ), 
							    m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
     
	  hVolumeName.str(""); 
	  hVolumeName << "PmtBaseVeto_" << iPMTNt;

	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,topPMTOffsetZ)-G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	}
	
	iPMTNt++;
	lxeVetoPmtOverlapHVFT = false;
      }

      // pmt2
      dThetaPMT = AngularOffset+dAngularStepPmts;
      G4RotationMatrix *zRot2         = new G4RotationMatrix();
      zRot2->rotateZ(180*deg-dThetaPMT);  

      dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
      
      if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	lxeVetoPmtOverlapHVFT = true;
      }

      if(!lxeVetoPmtOverlapHVFT){
    
	hVolumeName.str(""); 
	hVolumeName << "PmtVetoLatTop_" << iPMTNt;
       
	m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,topPMTOffsetZ), 
							  m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
     
	hVolumeName.str(""); 
	hVolumeName << "PmtBaseVeto_" << iPMTNt;
      
	m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,topPMTOffsetZ)-G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
      }
      
      AngularOffset += PTFEpillarAngularStep;
      ii++;
      lxeVetoPmtOverlapHVFT = false;
   }

  
  // ---------- PMTs R8520, Below the Bottom 3" PMT array   ----------
  AngularOffset = 0.;
  for(G4int iPMTNt=TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs; iPMTNt<TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs+TotNbBelowLXeVetoPMTs; ++iPMTNt)
    {
      G4RotationMatrix *zRot0         = new G4RotationMatrix();
      zRot0->rotateZ(180*deg-AngularOffset);  
      zRot0->rotateY(90.*deg);
    
      dLXeVetoPMTCenter_x  = dRadiusLXeVetoBelowPmt * cos(AngularOffset); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoBelowPmt * sin(AngularOffset); 

      hVolumeName.str(""); 
      hVolumeName << "PmtVetoBot_" << iPMTNt;
      
      m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,belowPMTOffsetZ), 
      							m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
      
      hVolumeName.str(""); 
      hVolumeName << "PmtBaseVeto_" << iPMTNt;
      
      AngularOffset += dAngularStepBelowPmts;				      

    }

  // ---------- LXeVeto TOP, Above Bell PMTs R8520  ----------
  if(pTpcWithBell){    
    AngularOffset = 0.;
    
    for(G4int iPMTNt=TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs+TotNbBelowLXeVetoPMTs; iPMTNt<TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs+TotNbBelowLXeVetoPMTs+TotNbAboveLXeVetoPMTs; ++iPMTNt)
      {
	
	G4RotationMatrix *zRot0         = new G4RotationMatrix();
	zRot0->rotateZ(180*deg-AngularOffset);  
	zRot0->rotateY(90.*deg);
	
	dLXeVetoPMTCenter_x  = dRadiusLXeVetoAbovePmt * cos(AngularOffset); 
	dLXeVetoPMTCenter_y  = dRadiusLXeVetoAbovePmt * sin(AngularOffset); 
	
	hVolumeName.str(""); 
	hVolumeName << "PmtVetoTop_" << iPMTNt;
	m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,abovePMTOffsetZ), 
							  m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pLXeTopLogicalVolume, false, iPMTNt));
	
	hVolumeName.str(""); 
	hVolumeName << "PmtBaseVeto_" << iPMTNt;
	
	// m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,abovePMTOffsetZ)
	// 						       -G4ThreeVector(0,0,dVetoBaseOffset+10.*mm),
	// 						       m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pLXeTopLogicalVolume, false, iPMTNt));
	
	AngularOffset += dAngularStepAbove;
	
      }
  }//endif pTpcWithBell


  ii = 0;
  AngularOffset         =  dAngularOffsetBunch;
  lxeVetoPmtOverlapHVFT = false;

  // ---------- Lateral Center PMTs R8520  ----------
  for(G4int iPMTNt=TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs+TotNbBelowLXeVetoPMTs+TotNbAboveLXeVetoPMTs; iPMTNt<TotNbOfTopPMTs+TotNbBottomPMTs+TotNbLSPMTs+TotNbWaterPMTs+TotNbBottomLXeVetoPMTs+TotNbTopLXeVetoPMTs+TotNbBelowLXeVetoPMTs+TotNbAboveLXeVetoPMTs+TotNbCenterLXeVetoPMTs; ++iPMTNt)
    {
      // pmt0
      dThetaPMT = AngularOffset-dAngularStepPmts;

      G4RotationMatrix *zRot0         = new G4RotationMatrix();
      zRot0->rotateZ(180*deg-dThetaPMT);  
      if(iPMTNt%2) zRot0->rotateX(180.*deg);  
      
      dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
      
      hVolumeName.str(""); 
      hVolumeName << "PmtVetoLatCen_" << iPMTNt;
      
      if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	lxeVetoPmtOverlapHVFT = true;
      }

      if(!lxeVetoPmtOverlapHVFT){

	m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,centerPMTOffsetZ), 
							  m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
	
	hVolumeName.str(""); 
	hVolumeName << "PmtBaseVeto_" << iPMTNt;

	if(iPMTNt%2)
	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)-G4ThreeVector(0,0,dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	else
	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot0,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,centerPMTOffsetZ)-G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
    
  
      }
      
      iPMTNt++;
      lxeVetoPmtOverlapHVFT = false;


      // pmt1
      if(iNumberPMTsBunch == 3){
	dThetaPMT = AngularOffset;
	G4RotationMatrix *zRot1         = new G4RotationMatrix();
	zRot1->rotateZ(180*deg-dThetaPMT);  
	if(iPMTNt%2) zRot1->rotateX(180.*deg);  
	
	dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
	dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
	
	hVolumeName.str(""); 
	hVolumeName << "PmtVetoLatCen_" << iPMTNt;
	
   
	if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	  lxeVetoPmtOverlapHVFT = true;
	}
 
	if(!lxeVetoPmtOverlapHVFT){
	  m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,centerPMTOffsetZ), 
							    m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
	  
	  hVolumeName.str(""); 
	  hVolumeName << "PmtBaseVeto_" << iPMTNt;

	  if(iPMTNt%2)
	    m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)-G4ThreeVector(0,0,dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	  else
	    m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot1,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,centerPMTOffsetZ)-G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	}
	
	iPMTNt++;
	lxeVetoPmtOverlapHVFT = false;
      }


      // pmt2
      dThetaPMT = AngularOffset+dAngularStepPmts;
      G4RotationMatrix *zRot2         = new G4RotationMatrix();
      zRot2->rotateZ(180*deg-dThetaPMT);  
      if(iPMTNt%2) zRot2->rotateX(180.*deg);  

      dLXeVetoPMTCenter_x  = dRadiusLXeVetoTopPmt * cos(dThetaPMT); 
      dLXeVetoPMTCenter_y  = dRadiusLXeVetoTopPmt * sin(dThetaPMT); 
      
      if(dThetaPMT > dHVFTAngularOffset-dAngularStepPmts && dThetaPMT  < dHVFTAngularOffset+dAngularStepPmts){
	lxeVetoPmtOverlapHVFT = true;
	G4cout << "BAD" << G4endl;
      }

      if(!lxeVetoPmtOverlapHVFT){
    
	hVolumeName.str(""); 
	hVolumeName << "PmtVetoLatCen_" << iPMTNt;
       
	m_pPMTPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x, dLXeVetoPMTCenter_y,centerPMTOffsetZ), 
							  m_pPmtR8520LogicalVolume, hVolumeName.str(),m_pMotherLogicalVolume, false, iPMTNt));
     
	hVolumeName.str(""); 
	hVolumeName << "PmtBaseVeto_" << iPMTNt;
	
	if(iPMTNt%2)
	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,bottomPMTOffsetZ)-G4ThreeVector(0,0,dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
	else
	  m_pPmtBasesPhysicalVolumes.push_back(new G4PVPlacement(zRot2,G4ThreeVector(dLXeVetoPMTCenter_x,dLXeVetoPMTCenter_y,centerPMTOffsetZ)-G4ThreeVector(0,0,-dVetoBaseOffset) ,m_pVetoPMTBaseLogicalVolume, hVolumeName.str(), m_pMotherLogicalVolume, false, iPMTNt));
  
      }
      
      AngularOffset += PTFEpillarAngularStep;
      ii++;
      lxeVetoPmtOverlapHVFT = false;
   }
 
 
  
}

void
Xenon1tDetectorConstruction::CheckOverlapping()
{
  G4cout << "Checking for overlapping... " << G4endl;
  int iOverlapped = 0;
  
  G4int res = 100000;
  G4bool verbose = true;
  
  iOverlapped += m_pLabPhysicalVolume->CheckOverlaps(res, 0, verbose);
  
  iOverlapped += m_pWaterTankTubePhysicalVolume->CheckOverlaps(res, 0, verbose);  // SERENA REPLACEMENT
  iOverlapped += m_pTankConsPhysicalVolume->CheckOverlaps(res, 0, verbose);  // SERENA 
  iOverlapped += m_pWaterPhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pWaterConsPhysicalVolume->CheckOverlaps(res, 0, verbose);  // SERENA
  iOverlapped += m_pAirConsPhysicalVolume->CheckOverlaps(res, 0, verbose);  // SERENA
  
  //	iOverlapped += m_pLSVesselPhysicalVolume->CheckOverlaps(res, 0, verbose);
  //iOverlapped += m_pLSPhysicalVolume->CheckOverlaps(res, 0, verbose);
  
  /*iOverlapped += m_pHexapodPlatformPhysicalVolume->CheckOverlaps(res, 0, verbose);// SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_1->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_2->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_3->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_4->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_5->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
    iOverlapped += m_pHexapodLegPhysicalVolume_6->CheckOverlaps(res, 0, verbose); // SERENA HEXAPOD
  */

  iOverlapped += m_pLegFloor1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegFloor2PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegFloor3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegFloor4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegConnection1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegConnection2PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegConnection3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegConnection4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTiltedCons1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTiltedCons2PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTiltedCons3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTiltedCons4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume1->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume2->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume3->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume4->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume5->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume6->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegTopPhysicalVolume7->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegMedium1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegMedium2PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegMedium3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegMedium4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal2PhysicalVolume->CheckOverlaps(res, 0, verbose);      
  iOverlapped +=m_pLegHorizontal3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal5PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal6PhysicalVolume->CheckOverlaps(res, 0, verbose);      
  iOverlapped +=m_pLegHorizontal7PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped +=m_pLegHorizontal8PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTilted1PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTilted2PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTilted3PhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLegTilted4PhysicalVolume->CheckOverlaps(res, 0, verbose);
	
  /*iOverlapped += m_pCablesPipeBasePhysicalVolume->CheckOverlaps(res, 0, verbose); // SERENA CABLES PIPE
    iOverlapped += m_pCablesPipePhysicalVolume->CheckOverlaps(res, 0, verbose); // SERENA CABLES PIPE
    iOverlapped += m_pCablesPipeAirPhysicalVolume->CheckOverlaps(res, 0, verbose); // SERENA CABLES PIPE
  */
  iOverlapped += m_pOuterCryostatPhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pOuterCryostatVacuumPhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pInnerCryostatPhysicalVolume->CheckOverlaps(res, 0, verbose);
	
	
	
  if (pCryostatType == "standard"){
    iOverlapped += m_pFlangePhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pFlangePart1PhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pFlangePart2PhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pFlangePart3PhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pFlangePart4PhysicalVolume->CheckOverlaps(res, 0, verbose);
  }
  
  iOverlapped += m_pLXeVacuumPhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pGXePhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pLXePhysicalVolume->CheckOverlaps(res, 0, verbose);
  iOverlapped += m_pBottomFillerPhysicalVolume->CheckOverlaps(res, 0, verbose);

  if(pTPC){ 
    iOverlapped += m_pSidePTFEPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pTopPTFEPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pBottomPTFEPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pTopCopperPlatePhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pBottomCopperPlatePhysicalVolume->CheckOverlaps(res, 0, verbose);
    
    iOverlapped += m_pSideAcrylicPhysicalVolume->CheckOverlaps(res, 0, verbose);
    
    iOverlapped += m_pTopGridMeshPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pAnodeMeshPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pCathodeMeshPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pBottomGridMeshPhysicalVolume->CheckOverlaps(res, 0, verbose);
    
    iOverlapped += m_pQUPIDPhotocathodePhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pQUPIDPhotocathodeInteriorPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pQUPIDBodyAluminiumCoatingPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pQUPIDBodyInteriorPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pQUPIDAPDPhysicalVolume->CheckOverlaps(res, 0, verbose);
    iOverlapped += m_pQUPIDBaseAluminiumCoatingPhysicalVolume->CheckOverlaps(res, 0, verbose);
    
    /*
      iOverlapped += m_pPMTPhotocathodePhysicalVolume->CheckOverlaps(res, 0, verbose);
      iOverlapped += m_pPMTPhotocathodeInterior1PhysicalVolume->CheckOverlaps(res, 0, verbose);
      iOverlapped += m_pPMTPhotocathodeInterior2PhysicalVolume->CheckOverlaps(res, 0, verbose);
      iOverlapped += m_pPMTBodyInteriorPhysicalVolume->CheckOverlaps(res, 0, verbose);
      iOverlapped += m_pPMTBaseInteriorPhysicalVolume->CheckOverlaps(res, 0, verbose);
    */
    
    const G4int iNbQUPIDs = (G4int) (GetGeometryParameter("NbTopPMTs") + GetGeometryParameter("NbBottomPMTs"));
    for(G4int iPMTNb=0; iPMTNb<iNbQUPIDs; iPMTNb++) iOverlapped += m_hQUPIDWindowPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbQUPIDs; iPMTNb++) iOverlapped += m_hQUPIDBodyPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbQUPIDs; iPMTNb++) iOverlapped += m_hQUPIDBasePhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    
    const G4int iNbPMTs = (G4int) GetGeometryParameter("NbPMTs");
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTWindowPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTBodyPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTBasePhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    
    
  } 
  
  else {
    const G4int iNbQUPIDs = (G4int) (GetGeometryParameter("NbTopPMTs") + GetGeometryParameter("NbBottomPMTs"));
    const G4int iNbPMTs = (G4int) GetGeometryParameter("NbPMTs");
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTWindowPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTBodyPhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
    for(G4int iPMTNb=0; iPMTNb<iNbPMTs-iNbQUPIDs; iPMTNb++) iOverlapped += m_hPMTBasePhysicalVolumes[iPMTNb]->CheckOverlaps(res, 0, verbose);
  }
  
  
  
  G4cout << "Done." << G4endl << G4endl;
  assert(iOverlapped==0);
}


void
Xenon1tDetectorConstruction::SecondOverlapCheck()
{
  // ******************************************************************************************************************
  // CHECK 4 OVERLAPS
	
  G4PhysicalVolumeStore* thePVStore = G4PhysicalVolumeStore::GetInstance();		// viene istanziato un puntatore
  // della classe G4PhysicalVolumeStore
  G4cout << "\n" << "******************************" << G4endl;
  G4cout << "\n" << "CHECK FOR OVERLAPS" << G4endl;
  G4cout << "\n" << "******************************" << G4endl;
  G4cout <<"\n" << G4endl;
  
  G4cout << thePVStore->size() << " physical volumes are defined" << G4endl;	// ci dice a video quanti sono i 
  // volumi fisici definiti
  
  G4bool overlapFlag = false;	   // la variabile booleana overlapFlag
                                   // e' inizializzata a "falso"
  
  for (size_t i=0; i<thePVStore->size();i++) {		   
    // looppiamo su tutti i volumi 
    // fisici definiti
    
    overlapFlag = (*thePVStore)[i]->CheckOverlaps(5000) | overlapFlag;		
    // la variabile overlapFlag ha 
    // contenuto "vero" se almeno un 
    // volume fisico ha overlap
    
    //    G4cout << overlapFlag << "\n" << G4endl;	    // il contenuto di overlapFlag e'
    //    if(overlapFlag) 
    //  G4Exception("XenonDetectorConstruction::SecondOverlapCheck()","DetectorConstruction",FatalException,"overlapping volume(s)");

  }																		// stampato a video
  
  // ******************************************************************************************************************x
}


void
Xenon1tDetectorConstruction::PrintGeometryInformation()
{
  //================================== Water tank =================================
  const G4double dWaterTankMass = m_pWaterTankTubLogicalVolume->GetMass(false, false)/(1000.*kg) + m_pTankConsLogicalVolume->GetMass(false, false)/(1000.*kg);  // SERENA REPLACEMENT
  G4cout << "Water Tank Mass:                          " << dWaterTankMass << " ton" << G4endl << G4endl;
  //================================== Water =================================
  const G4double dWaterMass = m_pWaterLogicalVolume->GetMass(false, false)/(1000.*kg);
  G4cout << "Water Mass:                               " << dWaterMass << " ton" << G4endl << G4endl;
  //================================== support structure =================================

  const G4double dlegfloorMass1 = m_pLegFloor1LogicalVolume->GetMass(false, false)/kg;
  G4cout << "FloorLeg 1:                  " << dlegfloorMass1 << " kg" << G4endl << G4endl;
  const G4double dlegmediumMass1 = m_pLegMedium1LogicalVolume->GetMass(false, false)/kg;
  G4cout << "MediumLeg 1:                  " << dlegmediumMass1 << " kg" << G4endl << G4endl;
  const G4double dlegmediumMass2 = m_pLegMedium2LogicalVolume->GetMass(false, false)/kg;
  G4cout << "MediumLeg 2:                  " << dlegmediumMass2 << " kg" << G4endl << G4endl;
  const G4double dlegmediumMass3 = m_pLegMedium3LogicalVolume->GetMass(false, false)/kg;
  G4cout << "MediumLeg 3:                  " << dlegmediumMass3 << " kg" << G4endl << G4endl;
  const G4double dlegmediumMass4 = m_pLegMedium4LogicalVolume->GetMass(false, false)/kg;
  G4cout << "MediumLeg 4:                  " << dlegmediumMass4 << " kg" << G4endl << G4endl;
  const G4double dleghoriMass1 = m_pLegHorizontal1LogicalVolume->GetMass(false, false)/kg;
  G4cout << "horiLeg 1:                  " << dleghoriMass1 << " kg" << G4endl << G4endl;	
  const G4double dlegtiltconsMass1 = m_pLegTiltedCons1LogicalVolume->GetMass(false, false)/kg;
  G4cout << "tiltconsLeg 1:                  " << dlegtiltconsMass1 << " kg" << G4endl << G4endl;	
  const G4double dlegtiltconsMass2 = m_pLegTiltedCons2LogicalVolume->GetMass(false, false)/kg;
  G4cout << "tiltconsLeg 2:                  " << dlegtiltconsMass2 << " kg" << G4endl << G4endl;				
  const G4double dlegtiltconsMass3 = m_pLegTiltedCons3LogicalVolume->GetMass(false, false)/kg;
  G4cout << "tiltconsLeg 3:                  " << dlegtiltconsMass3 << " kg" << G4endl << G4endl;	
  const G4double dlegtiltconsMass4 = m_pLegTiltedCons4LogicalVolume->GetMass(false, false)/kg;
  G4cout << "tiltconsLeg 4:                  " << dlegtiltconsMass4 << " kg" << G4endl << G4endl;
  const G4double dlegtopMass1 = m_pLegTopLogicalVolume1->GetMass(false, false)/kg;
  G4cout << "topMass 1:                  " << dlegtopMass1 << " kg" << G4endl << G4endl;
  const G4double dlegtopMass2 = m_pLegTopLogicalVolume2->GetMass(false, false)/kg;
  G4cout << "topMass 2:                  " << dlegtopMass2 << " kg" << G4endl << G4endl;
  const G4double dlegtopMass3 = m_pLegTopLogicalVolume3->GetMass(false, false)/kg;
  G4cout << "topMass 3:                  " << dlegtopMass3 << " kg" << G4endl << G4endl;
  const G4double dlegtopMass4 = m_pLegTopLogicalVolume4->GetMass(false, false)/kg;
  G4cout << "topMass 4:                  " << dlegtopMass4 << " kg" << G4endl << G4endl;
  const G4double dlegconMass1 = m_pLegConnection1LogicalVolume->GetMass(false, false)/kg;
  G4cout << "conMass 1:                  " << dlegconMass1 << " kg" << G4endl << G4endl;
  const G4double dlegtiltMass1 = m_pLegTiltedLogicalVolume->GetMass(false, false)/kg;
  G4cout << "tiltMass 1:                  " << dlegtiltMass1 << " kg" << G4endl << G4endl;
  const G4double dtotalmass = dlegfloorMass1*4.+dlegmediumMass1+dlegmediumMass2+dlegmediumMass3+dlegmediumMass4+dleghoriMass1*8.+dlegtiltconsMass1+dlegtiltconsMass2+dlegtiltconsMass3+dlegtiltconsMass4+dlegtopMass1+dlegtopMass2+dlegtopMass3+dlegtopMass4*4.+dlegconMass1*4.+dlegtiltMass1*4.;
  G4cout << "total mass support structure:                  " << dtotalmass << " kg" << G4endl << G4endl;
    
    //spreader
    
    const G4double dspreader = m_pLegSpreaderLogicalVolume->GetMass(false, false)/kg;
    const G4double dtrianglespreader = m_pLegSpreaderPlatLogicalVolume->GetMass(false, false)/kg;
    
    
    G4cout << "Spreader:                  " << dspreader*3.+dtrianglespreader*2. << " kg" << G4endl << G4endl;
    
    const G4double dtie = m_pTieRodLogicalVolume->GetMass(false, false)/kg;
    G4cout << "Tie:                  " << dtie << " kg" << G4endl << G4endl;


    //pipes
    
    const G4double dcylpipe = m_pPipeCylinderSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipeext:                  " << dcylpipe << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal = m_pPipeCylinderInternalSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipeint:                  " << dcylpipeinternal << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal1 = m_pPipeCylinderInternalSSLogicalVolume_1->GetMass(false, false)/kg;
    G4cout << "cylpipeint1:                  " << dcylpipeinternal1 << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal2 = m_pPipeCylinderInternalSSLogicalVolume_2->GetMass(false, false)/kg;
    G4cout << "cylpipeint2:                  " << dcylpipeinternal2 << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal3 = m_pPipeCylinderInternalSSLogicalVolume_3->GetMass(false, false)/kg;
    G4cout << "cylpipeint3:                  " << dcylpipeinternal3 << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal4 = m_pPipeCylinderInternalSSLogicalVolume_4->GetMass(false, false)/kg;
    G4cout << "cylpipeint4:                  " << dcylpipeinternal4 << " kg" << G4endl << G4endl;
    const G4double dcylpipeinternal5 = m_pPipeCylinderInternalSSLogicalVolume_5->GetMass(false, false)/kg;
    G4cout << "cylpipeint5:                  " << dcylpipeinternal5 << " kg" << G4endl << G4endl;
    
    const G4double dcylpipeair = m_pPipeCylinderAirLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipeair:                  " << dcylpipeair << " kg" << G4endl << G4endl;
    
    const G4double dcylpipelow = m_pPipeCylinderLowSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelowext:                  " << dcylpipelow << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal = m_pPipeCylinderInternalLowSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelowint:                  " << dcylpipelowinternal << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal1 = m_pPipeCylinderInternalLowSSLogicalVolume_1->GetMass(false, false)/kg;
    G4cout << "cylpipelowint1:                  " << dcylpipelowinternal1 << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal2 = m_pPipeCylinderInternalLowSSLogicalVolume_2->GetMass(false, false)/kg;
    G4cout << "cylpipelowint2:                  " << dcylpipelowinternal2 << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal3 = m_pPipeCylinderInternalLowSSLogicalVolume_3->GetMass(false, false)/kg;
    G4cout << "cylpipelowint3:                  " << dcylpipelowinternal3 << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal4 = m_pPipeCylinderInternalSSLogicalVolume_4->GetMass(false, false)/kg;
    G4cout << "cylpipelowint4:                  " << dcylpipelowinternal4 << " kg" << G4endl << G4endl;
    const G4double dcylpipelowinternal5 = m_pPipeCylinderInternalSSLogicalVolume_5->GetMass(false, false)/kg;
    G4cout << "cylpipelowint5:                  " << dcylpipelowinternal5 << " kg" << G4endl << G4endl;
    
    const G4double dcylpipelowair = m_pPipeCylinderLowAirLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelowair:                  " << dcylpipelowair << " kg" << G4endl << G4endl;
    
    const G4double dtoruspipe = m_pPipeTorusSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "toruspipeext:                  " << dtoruspipe << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal = m_pPipeTorusInternalSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "toruspipeint:                  " << dtoruspipeinternal << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal1 = m_pPipeTorusInternalSSLogicalVolume_1->GetMass(false, false)/kg;
    G4cout << "toruspipeint1:                  " << dtoruspipeinternal1 << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal2 = m_pPipeTorusInternalSSLogicalVolume_2->GetMass(false, false)/kg;
    G4cout << "toruspipeint2:                  " << dtoruspipeinternal2 << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal3 = m_pPipeTorusInternalSSLogicalVolume_3->GetMass(false, false)/kg;
    G4cout << "toruspipeint3:                  " << dtoruspipeinternal3 << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal4 = m_pPipeTorusInternalSSLogicalVolume_4->GetMass(false, false)/kg;
    G4cout << "toruspipeint4:                  " << dtoruspipeinternal4 << " kg" << G4endl << G4endl;
    const G4double dtoruspipeinternal5 = m_pPipeTorusInternalSSLogicalVolume_5->GetMass(false, false)/kg;
    G4cout << "toruspipeint5:                  " << dtoruspipeinternal5 << " kg" << G4endl << G4endl;

    const G4double dtoruspipeair = m_pPipeTorusAirLogicalVolume->GetMass(false, false)/kg;
    G4cout << "toruspipeair:                  " << dtoruspipeair << " kg" << G4endl << G4endl;

    
    const G4double dcylpipelong = m_pPipeCylinderTiltedLongSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelongext:                  " << dcylpipelong << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal = m_pPipeCylinderTiltedLongInternalSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelongint:                  " << dcylpipelonginternal << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal1 = m_pPipeCylinderTiltedLongInternalSSLogicalVolume_1->GetMass(false, false)/kg;
    G4cout << "cylpipelongint1:                  " << dcylpipelonginternal1 << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal2 = m_pPipeCylinderTiltedLongInternalSSLogicalVolume_2->GetMass(false, false)/kg;
    G4cout << "cylpipelongint2:                  " << dcylpipelonginternal2 << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal3 = m_pPipeCylinderTiltedLongInternalSSLogicalVolume_3->GetMass(false, false)/kg;
    G4cout << "cylpipelongint3:                  " << dcylpipelonginternal3 << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal4 = m_pPipeCylinderTiltedLongInternalSSLogicalVolume_4->GetMass(false, false)/kg;
    G4cout << "cylpipelongint4:                  " << dcylpipelonginternal4 << " kg" << G4endl << G4endl;
    const G4double dcylpipelonginternal5 = m_pPipeCylinderTiltedLongInternalSSLogicalVolume_5->GetMass(false, false)/kg;
    G4cout << "cylpipelongint5:                  " << dcylpipelonginternal5 << " kg" << G4endl << G4endl;
    
    const G4double dcylpipelongair = m_pPipeCylinderTiltedLongAirLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipelongair:                  " << dcylpipelongair << " kg" << G4endl << G4endl;
    
    const G4double flange = m_pPipeBaseLogicalVolume->GetMass(false, false)/kg;
    G4cout << "flange:                  " << flange << " kg" << G4endl << G4endl;
    
    const G4double flangeint = m_pPipeBaseInternalLogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint:                  " << flangeint << " kg" << G4endl << G4endl;
    
    const G4double flangeint1 = m_pPipeBaseInternal1LogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint1:                  " << flangeint1 << " kg" << G4endl << G4endl;
    
    const G4double flangeint2 = m_pPipeBaseInternal2LogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint2:                  " << flangeint2 << " kg" << G4endl << G4endl;
    
    const G4double flangeint3 = m_pPipeBaseInternal3LogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint3:                  " << flangeint3 << " kg" << G4endl << G4endl;
    
    const G4double flangeint4 = m_pPipeBaseInternal4LogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint4:                  " << flangeint4 << " kg" << G4endl << G4endl;
    
    const G4double flangeint5 = m_pPipeBaseInternal5LogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangeint5:                  " << flangeint5 << " kg" << G4endl << G4endl;
    
    const G4double  masscentralpipe = 2.*flange+dcylpipe+dcylpipeinternal+dcylpipeinternal1+dcylpipeinternal2+dcylpipeinternal3+dcylpipeinternal4+dcylpipeinternal5+dcylpipelow+dcylpipelowinternal+dcylpipelowinternal1+dcylpipelowinternal2+dcylpipelowinternal3+dcylpipelowinternal4+dcylpipelowinternal5+dtoruspipe+dtoruspipeinternal+dtoruspipeinternal1+dtoruspipeinternal2+dtoruspipeinternal3+dtoruspipeinternal4+dtoruspipeinternal5+dcylpipelong+dcylpipelonginternal+dcylpipelonginternal1+dcylpipelonginternal2+dcylpipelonginternal3+dcylpipelonginternal4+dcylpipelonginternal5;
    
    G4cout << "masstotal:                  " << masscentralpipe << " kg" << G4endl << G4endl;
    
    
    const G4double dcylpipesmall = m_pPipeCylinderSmallSSLogicalVolume ->GetMass(false, false)/kg;
    G4cout << "cylpipesmall:                  " << dcylpipesmall << " kg" << G4endl << G4endl;
    const G4double dcylpipeairsmall =  m_pPipeCylinderAirSmallLogicalVolume ->GetMass(false, false)/kg;
    G4cout << "cylpipeairsmall:                  " << dcylpipeairsmall << " kg" << G4endl << G4endl;
    const G4double dtoruspipesmall = m_pPipeTorusSmallSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "toruspipesmallext:                  " << dtoruspipesmall << " kg" << G4endl << G4endl;
    const G4double dtoruspipeairsmall = m_pPipeTorusAirSmallLogicalVolume->GetMass(false, false)/kg;
    G4cout << "toruspipesmallairext:                  " << dtoruspipeairsmall << " kg" << G4endl << G4endl;
    
    const G4double dcylpipelongsmall = m_pPipeCylinderTiltedLongSmallSSLogicalVolume->GetMass(false, false)/kg;
    G4cout << "cylpipesmall:                  " << dcylpipelongsmall << " kg" << G4endl << G4endl;
    const G4double dcylpipeairlongsmall =  m_pPipeCylinderTiltedLongAirSmallLogicalVolume ->GetMass(false, false)/kg;
    G4cout << "cylpipeairlongsmall:                  " << dcylpipeairlongsmall << " kg" << G4endl << G4endl;
    const G4double dflangesmall = m_pPipeBaseSmallLogicalVolume->GetMass(false, false)/kg;
    G4cout << "flangesmall:                  " << dflangesmall << " kg" << G4endl << G4endl;

    const G4double  masssmallpipe = dflangesmall+dcylpipesmall+dtoruspipesmall+dcylpipelongsmall;
    
    G4cout << "masssmalltotal:                  " << masssmallpipe << " kg" << G4endl << G4endl;
    
    
    const G4double dtolon = m_pPipeTolonLogicalVolume ->GetMass(false, false)/kg;
    G4cout << "tolon:                  " << dtolon << " kg" << G4endl << G4endl;


    

  
  //================================== Xenon =================================
  const G4double dLXeMass = m_pLXeLogicalVolume->GetMass(false, false)/kg;
  G4cout << "LXe Mass:                                 " << dLXeMass << " kg" << G4endl;
  const G4double dGXeMass = m_pGXeLogicalVolume->GetMass(false, false)/kg;
  G4cout << "GXe Mass:                                 " << dGXeMass << " kg" << G4endl;
  const G4double dTotalXenonMass = dLXeMass + dGXeMass;
  G4cout << "Total Xenon Mass:                         " << dTotalXenonMass << " kg" << G4endl;
  
  //======================================= new detector design =============================================== //Fabio Valerio
  //================================== Cryostats ============================================================== 
  const G4double dOuterCryostatMass = m_pOuterCryostatLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Outer Cryostat Mass:                      " << dOuterCryostatMass << " kg" << G4endl;
  
  const G4double dInnerCryostatMass = m_pInnerCryostatLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Inner Cryostat Mass:                      " << dInnerCryostatMass << " kg" << G4endl;
  
  const G4double dTotalCryostatMass = dOuterCryostatMass + dInnerCryostatMass;
  G4cout << "Total Cryostat Mass:                      " << dTotalCryostatMass << " kg" << G4endl;
  
  //================================== Top Plate ============================================================== 
  
  const G4double dTopPlateMass = m_pTopPlateLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Top Copper Plate Mass:                      " << dTopPlateMass << " kg" << G4endl;
  
  //  ================================= PmtBases =================================
  const G4double dPMTsBases = (m_pPmtBasesLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("NbOfPMTs");
  const G4double dPMTsBasesTop = (m_pPmtBasesLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("NbTopPMTs");
  const G4double dPMTsBasesBottom = (m_pPmtBasesLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("NbBottomPMTs");
  const G4double numbot=GetGeometryParameter("NbBottomPMTs");
  const G4double numtop=GetGeometryParameter("NbTopPMTs");
  const G4double numtot=GetGeometryParameter("NbOfPMTs");
  G4cout << "num tot (cirlex):                         " <<numtot<<G4endl<<G4endl;
  G4cout << "num bot (cirlex):                         " <<numbot<<G4endl<<G4endl;
  G4cout << "num top (cirlex):                         " <<numtop<<G4endl<<G4endl;
  G4cout << "PMTs Bases (cirlex):                      " <<dPMTsBases<<" kg"<<G4endl<<G4endl;
  G4cout << "Top PMT Bases (cirlex):                   " <<dPMTsBasesTop<<" kg"<<G4endl<<G4endl;
  G4cout << "Bottom PMT Bases (cirlex):                " <<dPMTsBasesBottom<<" kg"<<G4endl<<G4endl;

  //================================== Top PMTs Holder ============================================================== 
  
  const G4double dTopPMTsHolderMass = m_pTopPMTsHolderLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Top PMTs Holder  Mass:              " << dTopPMTsHolderMass << " kg" << G4endl;

  //================================== Top PMTs Copper ==============================================================
  
  const G4double dTopPMTCopperMass = m_pTopPMTCopperLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Top PMTs Copper Mass:                   " << dTopPMTCopperMass << " kg" << G4endl;
    
  //================================== Top PTFE ============================================================== 
  
  const G4double dTopPTFEMass = m_pTopPTFELogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Top PTFE Mass:                      " << dTopPTFEMass << " kg" << G4endl;
  
  //================================== Top PTFE around electrodes =====================================================
  
  const G4double dTopElectrodePTFE_GXeMass = m_pTopElectrodePTFELogicalVolume->GetMass(false, false)/kg;
  const G4double dTopElectrodePTFE_LXeMass = m_pTopElectrodePTFELXeLogicalVolume->GetMass(false, false)/kg;
  const G4double dTotaldTopElectrodePTFE   = dTopElectrodePTFE_GXeMass + dTopElectrodePTFE_LXeMass;
  
  G4cout << "Total Top PTFE around electrodes Mass:    " << dTotaldTopElectrodePTFE << " kg" << G4endl; 
  
  //================================== Top Mesh electrode Ring  =============================================================
  
  const G4double dTopMeshRingMass = m_pTopMeshRingLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Top Mesh electrode Ring Mass:       " << dTopMeshRingMass << " kg" << G4endl;
  
  //================================== Anode electrode Ring ============================================================== 
  
  const G4double dAnodeRing_1Mass = m_pAnodeRing_1LogicalVolume->GetMass(false, false)/kg;
  const G4double dAnodeRing_2Mass = m_pAnodeRing_2LogicalVolume->GetMass(false, false)/kg;
  const G4double dAnodeRingMass   = dAnodeRing_1Mass + dAnodeRing_2Mass;
  
  G4cout << "Total Anode electrode Ring  Mass:         " << dAnodeRingMass << " kg" << G4endl;
  
  //================================== Gate electrode Ring ============================================================== 
  
  const G4double dGateElectrodeRingMass = m_pGateElectrodeRingLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Gate electrode Ring Mass:           " << dGateElectrodeRingMass << " kg" << G4endl;
  
  //================================ Grid Meshes ================================================================== 
  
  const G4double  dTopMesheMass     = m_pTopGridMeshLogicalVolume->GetMass(false, false)/kg;
  const G4double  dAnodeMesheMass   = m_pAnodeMeshLogicalVolume->GetMass(false, false)/kg;
  const G4double  dGateMesheMass    = m_pGroundMeshLogicalVolume->GetMass(false, false)/kg;
  const G4double  dCathodeMesheMass = m_pCathodeMeshLogicalVolume->GetMass(false, false)/kg;
  const G4double  dBottomMesheMass  = m_pBottomGridMeshLogicalVolume->GetMass(false, false)/kg;

  G4cout << " Top     Mesh  Mass:                     " << dTopMesheMass     << " kg" << G4endl;
  G4cout << " Anode   Mesh  Mass:                     " << dAnodeMesheMass   << " kg" << G4endl;
  G4cout << " Gate    Mesh  Mass:                     " << dGateMesheMass    << " kg" << G4endl;
  G4cout << " Cathode Mesh  Mass:                     " << dCathodeMesheMass << " kg" << G4endl;
  G4cout << " Bottom  Mesh  Mass:                     " << dBottomMesheMass  << " kg" << G4endl;
  
  //================================== SS plate (+ ext ring) ============================================================== 
  
  const G4double dSSPlateMass    = m_pSSPlateLogicalVolume->GetMass(false, false)/kg;
  const G4double dSSRingLXeMass  = m_pSSRing_LXeLogicalVolume->GetMass(false, false)/kg;
   
  const G4double dSSPlateTotMass = dSSPlateMass + dSSRingLXeMass;
  
  G4cout << "Total SS plate Mass:                 " << dSSPlateTotMass << " kg" << G4endl;
  G4cout << "SS plate Mass:                 " << dSSPlateMass << " kg" << G4endl;
  G4cout << "SS external ring Mass:                 " << dSSRingLXeMass << " kg" << G4endl;
  
  //================================== TPC ==============================================================
  
  const G4double dTpcMass = m_pTpcLogicalVolume->GetMass(false, false)/kg;
  const G4double dBelowTpcRingMass = m_pBelowTpcRingLogicalVolume->GetMass(false, false)/kg;
  G4cout << "TPC Mass:                                 " << dTpcMass << " kg" << G4endl;
  G4cout << "Below TPC ring Mass:                      " << dBelowTpcRingMass  << " kg" << G4endl;
 
  //================================== Field Shaper Rings ==============================================================
  
  const G4double dFieldShaperRingsMass = (m_pFieldShaperRingLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("FieldShaperRingsTotNum");
  G4cout << "Total Field Shaper Rings Mass (single):   " << dFieldShaperRingsMass << " kg" << "( " << dFieldShaperRingsMass/GetGeometryParameter("FieldShaperRingsTotNum") << " )"<<G4endl;
  
  //================================== PTFE pillars =============================================================
  
  const G4double dpPTFEpillarMass = (m_pPTFEpillarLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("NbofPTFEpillar");
  G4cout << "Total ptfe pillars Mass (single):         " << dpPTFEpillarMass << " kg" << "( " << dpPTFEpillarMass/GetGeometryParameter("NbofPTFEpillar") << " )" << G4endl;
  
  //================================== Holder pillars ring =============================================================
  
  const G4double dCopperRingBelowPillarsMass = m_pCopperRingBelowPillarsLogicalVolume->GetMass(false, false)/kg;
  G4cout << " Copper Holder pillars ring Mass:                                 " << dCopperRingBelowPillarsMass << " kg" << G4endl;
  
  //================================== cathode electrode ring =============================================================
  
  const G4double dCathodeElectrodeRingMass = m_pCathodeMesh_RingLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total cathode electrode ring Mass:        " << dCathodeElectrodeRingMass << " kg" << G4endl;
  
  //================================== bottom electrode ring ==============================================================
  
  const G4double dBottomGridElectrodeMass = m_pBottomGridMesh_RingLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total bottom electrode ring Mass:         " << dBottomGridElectrodeMass << " kg" << G4endl;
  
  //================================== Bottom PTFE Reflector ==============================================================   
  
  const G4double dBottomReflectorMass = m_pBottomReflectorLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Bottom Reflector Mass:                   " << dBottomReflectorMass << " kg" << G4endl;
  
  //================================== Bottom PTFE ==============================================================
  
  const G4double dBottomPTFEMass = m_pBottomPTFELogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Bottom PTFE Mass:                " << dBottomPTFEMass << " kg" << G4endl;

  //================================== Bottom Holder ============================================================== 
  
  const G4double dBottomHolderMass = m_pBottomHolderLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Bottom Holder Mass:                  " << dBottomHolderMass << " kg" << G4endl;
  
  //================================== Cathode Support ============================================================== 
  
  const G4double dCathodeSupportMass =  (m_pCathodeSupportLogicalVolume->GetMass(false, false)/kg)*GetGeometryParameter("NbofCathodeSupp");
  G4cout << "Total Cathode Supprot Mass (single):   " << dCathodeSupportMass << " kg" << "( " << dCathodeSupportMass/GetGeometryParameter("NbofCathodeSupp") << " )"<<G4endl;
  
  //================================== Bottom Filler ============================================================== 
  
  const G4double dBottomFillerMass = m_pBottomFillerLogicalVolume->GetMass(false, false)/kg;
  G4cout << "Total Bottom Filler Mass:                  " << dBottomFillerMass << " kg" << G4endl;
  
  // //==================================  HVFT  ======================================================== 

  if(pFlagHVFT){ 
    const G4double outer_SS_GXe    = m_pOuterSS_GXeHVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double inner_poly_GXe  = m_pInnerPoly_GXeHVFT_LogicalVolume->GetMass(false, false)/kg;
    //const G4double inner_SS_GXe    = m_pInnerSS_GXeHVFT_LogicalVolume->GetMass(false, false)/kg;//da vedere se c'è
    
    const G4double outer_SS       = m_pOuterSS_HVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double inner_poly     = m_pInnerPoly_HVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double inner_SS       = m_pInnerSS_HVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double bottom_poly    = m_pBottom_Poly_HVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double bottom_SS      = m_pBottom_InnerSS_HVFT_LogicalVolume->GetMass(false, false)/kg;
    const G4double last_bottom_SS = m_plast_bottom_SS_HVFT_LogicalVolume->GetMass(false, false)/kg;
    
    const G4double SS_total_Mass   = outer_SS + inner_SS + bottom_SS + last_bottom_SS + outer_SS_GXe;// + inner_SS_GXe;
    const G4double poly_total_Mass = inner_poly + bottom_poly + inner_poly_GXe;
    
    G4cout << "HVFT SS components total Mass :             " << SS_total_Mass   <<" kg" << G4endl << G4endl;
    G4cout << "HVFT poly components total Mass :           " << poly_total_Mass <<" kg" << G4endl << G4endl;
  }

  //================================== LXeVeto =================================
  if(pLXeVeto){
    // Mass of PTFE added for LXe Veto
    G4double ptfeLayerCryo = m_pPTFELayerCryoLogicalVolume->GetMass(false, false)/kg;
    G4double ptfeInnerWall = m_pPTFEInWallLogicalVolume->GetMass(false, false)/kg;
    G4cout << "PTFE Cryostat Layer Mass:                   " << ptfeLayerCryo << " kg" << G4endl;
    G4cout << "PTFE Inner Wall total Mass (single):        " <<  ptfeInnerWall*GetGeometryParameter("NbofPTFEpillar")<< " kg (" << ptfeInnerWall << ")" <<G4endl;

    if(pTpcWithBell){
      G4double ptfeAbove = m_pPTFEAboveTPC1LogicalVolume->GetMass(false, false)/kg+m_pPTFEAboveTPC2LogicalVolume->GetMass(false, false)/kg;
      G4cout << "PTFE Plates above TPC Mass (single)         " << m_pPTFEAboveTPC1LogicalVolume->GetMass(false, false)/kg << " (" << ptfeAbove << ")kg" << G4endl;
    }
    G4double ptfeBelow = m_pPTFEBelowTPC1LogicalVolume->GetMass(false, false)/kg+m_pPTFEBelowTPC2LogicalVolume->GetMass(false, false)/kg;
    G4cout << "PTFE Plates below TPC Mass (single)         " << m_pPTFEBelowTPC1LogicalVolume->GetMass(false, false)/kg << " (" << ptfeBelow << ")kg" << G4endl;

    const G4int numtoplxeveto   = G4int(GetGeometryParameter("NbTopLXeVetoPMTs"));
    const G4int numbottomlxeveto  = G4int(GetGeometryParameter("NbBottomLXeVetoPMTs"));
    const G4int numabovelxeveto  = (G4int)GetGeometryParameter("NbAboveLXeVetoPMTs");
    const G4int numbelowlxeveto  = (G4int)GetGeometryParameter("NbBelowLXeVetoPMTs");
    const G4int numtotlxeveto = (G4int)GetGeometryParameter("NbLXeVetoPMTs");
    const G4double dLXeVetoPMTBase =  (m_pVetoPMTBaseLogicalVolume->GetMass(false, false)/kg);
    const G4double dLXeVetoPMTsBasesTop = dLXeVetoPMTBase*numtoplxeveto;
  
    G4cout << "LXe Veto Top PMTs Bases :                   " << dLXeVetoPMTBase*numtoplxeveto <<" kg"<<G4endl;
    G4cout << "LXe Veto Bottom PMTs Bases :                " << dLXeVetoPMTBase*numbottomlxeveto <<" kg"<<G4endl;
    G4cout << "LXe Veto Above PMTs Bases :                 " << dLXeVetoPMTBase*numbelowlxeveto <<" kg"<<G4endl;
    G4cout << "LXe Veto Below PMTs Bases :                 " << dLXeVetoPMTBase*numabovelxeveto <<" kg"<<G4endl;
    G4cout << "LXe Veto Total PMTs Bases :                 " << dLXeVetoPMTBase*numtotlxeveto <<" kg"<<G4endl << G4endl;
    
     /*
       // comment this if no surface informations needed
     G4cout << "PTFE Cryostat Layer Surface                 " << m_pPTFELayerCryoLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << G4endl;
       G4cout << "PTFE Inner Wall Surface (single)            " << GetGeometryParameter("NbofPTFEpillar")*m_pPTFEInWallLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << " cm2 ("<< m_pPTFEInWallLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << ")"<< G4endl;
       G4cout << "PTFE Plates above TPC Surface (single)      " << m_pPTFEAboveTPC1LogicalVolume->GetSolid()->GetSurfaceArea()/cm2+m_pPTFEAboveTPC2LogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << " cm2 (" <<  m_pPTFEAboveTPC1LogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << ")"<<G4endl;
    G4cout << "PTFE Plates below TPC Surface (single)      " << m_pPTFEBelowTPC1LogicalVolume->GetSolid()->GetSurfaceArea()/cm2+m_pPTFEBelowTPC2LogicalVolume->GetSolid()->GetSurfaceArea()/cm2<< " cm2 (" <<    m_pPTFEBelowTPC1LogicalVolume->GetSolid()->GetSurfaceArea()/cm2 <<")"<< G4endl;
  
  
    G4cout << "PTFE From TPC: " << G4endl;
    G4cout << "Total Top PTFE Surface :                   " <<  m_pTopPTFELogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << G4endl;
    G4cout << "Total Top PTFE around electrodes Surface:  " <<  m_pTopElectrodePTFELXeLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 + m_pTopElectrodePTFELogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << G4endl;
    G4cout << "Total Top external PTFE ring Surface:      " <<m_pTopPTFERingLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 +  m_pTopPTFERing_LXeLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << G4endl;
    G4cout << "TPC Surface:                               " <<m_pTpcLogicalVolume->GetSolid()->GetSurfaceArea()/cm2  << G4endl;
    G4cout << "Below TPC ring Surface :                   " << m_pBelowTpcRingLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << G4endl;
    G4cout << "Total ptfe pillars Surface (single):       " << (m_pPTFEpillarLogicalVolume->GetSolid()->GetSurfaceArea()/cm2)*GetGeometryParameter("NbofPTFEpillar") << " cm2 " << "( " << m_pPTFEpillarLogicalVolume->GetSolid()->GetSurfaceArea()/cm2 << " )" << G4endl;
    G4cout << "Total Bottom PTFE Surface:                 " <<m_pBottomPTFELogicalVolume->GetSolid()->GetSurfaceArea()/cm2  << " kg" << G4endl;
    */
    
}


  //================================== PMTs =================================
  const G4int iNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  G4cout << "Number of LS PMTs:                    " << iNbLSPMTs << G4endl;
  const G4int iNbWaterPMTs = (G4int) GetGeometryParameter("NbWaterPMTs");
  G4cout << "Number of Water PMTs:                 " << iNbWaterPMTs << G4endl;
  const G4int iNbVetoPMTs = iNbLSPMTs + iNbWaterPMTs;
  G4cout << "Total Number of Veto PMTs:            " << iNbVetoPMTs << G4endl << G4endl;

}

G4ThreeVector 
Xenon1tDetectorConstruction::GetPMTsPositionTopArray(G4int iPMTNb)
{
  G4double dPMTDistance = GetGeometryParameter("PMTDistance_TPCtop");
  //   G4int iNbPMTRows = G4int(GetGeometryParameter("NbOfTopPMTsRow"));
  //   G4int iNbfPMTs   = G4int(GetGeometryParameter("NbOfTopPMTs"));
  G4int array[7] = {1, 6, 12, 18, 24, 30, 36};
  G4double radius[7] = {0.,dPMTDistance,dPMTDistance*2,dPMTDistance*3,dPMTDistance*4,dPMTDistance*5,dPMTDistance*6};
  
  G4int index1 = 0;
  G4int iTotal = array[0];
  //   while(iPMTNb+1>iTotal)
  while(iPMTNb>iTotal)
    iTotal += array[++index1];
  G4int index2 = iPMTNb + array[index1] - iTotal;
  
  G4cout <<"------------------- TOP PMTs --------------------------"<<G4endl;
  G4cout << "iPMTNb  "<< iPMTNb<< "  iTotal  "<< iTotal << "  index1  "<< index1 << "  index2  "<<index2<<"   "<<radius[index1]*cos(0.+(index2*2*M_PI/array[index1]))<<"   "<<radius[index1]*sin(0.+(index2*2*M_PI/array[index1]))<<G4endl;
  
  G4ThreeVector hPos;
  hPos.setZ(0.*cm);
  hPos.setX(radius[index1]*cos(0.+(index2*2*M_PI/array[index1])));
  hPos.setY(radius[index1]*sin(0.+(index2*2*M_PI/array[index1])));
  
  return hPos;
}

G4ThreeVector 
Xenon1tDetectorConstruction::GetPMTsPositionBottomArray(G4int iPMTNb)
{
  G4double dPMTDistance    = GetGeometryParameter("PMTDistance_TPCbottom");
  G4int iNbOfTopPMTs       = G4int(GetGeometryParameter("NbOfTopPMTs"));
  G4double dPMTRowDistance = sqrt(3.)/2.*dPMTDistance;
  const int iNbPMTRows     = 13;
  G4ThreeVector hPos;
  hPos.setZ(0.*cm);
  
  int array[13] = {5, 8, 9, 10, 11, 12, 11, 12, 11, 10, 9, 8, 5};
  vector<G4double> hPMTsRowOffset;
  for(G4int iPMTRowNb=0; iPMTRowNb<iNbPMTRows; iPMTRowNb++)
    {
      //G4cout <<iPMTRowNb<<"  "<<(-0.5*(hPMTsPerRow[iPMTRowNb]-1)*dPMTDistance)<<G4endl;
      hPMTsRowOffset.push_back((G4double)(-0.5*(array[iPMTRowNb]-1)*dPMTDistance));
    }
  
  G4int index1 = 0;
  G4int iTotal = array[0];
  while(iPMTNb>iNbOfTopPMTs+iTotal)
    iTotal += array[++index1];
  
  G4int index2 = iPMTNb + array[index1] - iTotal -(iNbOfTopPMTs+1);
  
  //  G4cout <<"---------------------------------------------"<<G4endl;
  //  G4cout <<iPMTNb<<"  "<<index2<<"   "<<hPMTsRowOffset[index1]<<"   "<<index2*dPMTDistance<<"   "<<(0.5*(iNbPMTRows-1)-index1)*dPMTRowDistance<<"   "<<hPMTsRowOffset[index1]<<G4endl;
  
  hPos.setX(hPMTsRowOffset[index1] + index2*dPMTDistance);
  hPos.setY((0.5*(iNbPMTRows-1)-index1)*dPMTRowDistance);
  
  return hPos;
}

G4ThreeVector
Xenon1tDetectorConstruction::GetPMTPosition(G4int iPMTNb, PMTPart ePMTPart)
{
  const G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  const G4int iNbBottomPMTs = (G4int) GetGeometryParameter("NbBottomPMTs");
  const G4int iNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  const G4int iNbWaterPMTs = (G4int) GetGeometryParameter("NbWaterPMTs");
  
  G4ThreeVector hPos;
  
  if(iPMTNb < iNbTopPMTs)
    hPos = GetQUPIDPositionTopArray(iPMTNb, ePMTPart);
  else if(iPMTNb < iNbTopPMTs+iNbBottomPMTs)
    hPos = GetQUPIDPositionBottomArray(iPMTNb, ePMTPart);
  else if(iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs)
    hPos = GetPMTPositionLSArray(iPMTNb, ePMTPart);
  else if(iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs+iNbWaterPMTs)
    hPos = GetPMTPositionWaterArray(iPMTNb, ePMTPart);
  
  //G4double PmtRadius = sqrt( pow(hPos.x(),2) + pow(hPos.y(),2) );
  //if(ePMTPart == PMT_WINDOW)
  //	G4cout << "iPMTNb " << iPMTNb << " position " << hPos << " Radius " << PmtRadius <<  G4endl;
  
  return hPos;
}

G4ThreeVector
Xenon1tDetectorConstruction::GetQUPIDPositionTopArray(G4int iPMTNb, PMTPart ePMTPart)
{
  const G4double dQUPIDWindowZ = GetGeometryParameter("TopQUPIDWindowZ");
  
  const G4double dQUPIDBodyOffsetZ = GetGeometryParameter("QUPIDWindowOuterRadius")-GetGeometryParameter("QUPIDWindowOuterHeight")-0.5*GetGeometryParameter("QUPIDBodyHeight");
  const G4double dQUPIDBaseOffsetZ = dQUPIDBodyOffsetZ-0.5*(GetGeometryParameter("QUPIDBodyHeight")+GetGeometryParameter("QUPIDBaseThickness"));
  
  const G4double dQUPIDDistance = GetGeometryParameter("QUPIDDistance");
  const G4double dQUPIDRowDistance = sqrt(3.)/2.*dQUPIDDistance;
  
  G4ThreeVector hPos;
  
  switch(ePMTPart)
    {
    case PMT_WINDOW:
      hPos.setZ(dQUPIDWindowZ);
      break;
      
    case PMT_BODY:
      hPos.setZ(dQUPIDWindowZ - dQUPIDBodyOffsetZ);
      break;
      
    case PMT_BASE:
      hPos.setZ(dQUPIDWindowZ - dQUPIDBaseOffsetZ);
      break;
    }
  
  const G4int iNbQUPIDRows = 13;
  const G4int hQUPIDsPerRow[iNbQUPIDRows] = {5, 8, 9, 10, 11, 12, 11, 12, 11, 10, 9, 8, 5};
  
  vector<G4double> hQUPIDsRowOffset;
  for(G4int iQUPIDRowNb=0; iQUPIDRowNb<iNbQUPIDRows; iQUPIDRowNb++)
    hQUPIDsRowOffset.push_back((G4double)(-0.5*(hQUPIDsPerRow[iQUPIDRowNb]-1)*dQUPIDDistance));
  
  G4int iPMTNb1 = 0;
  G4int iTotal = hQUPIDsPerRow[0];
  while(iPMTNb+1>iTotal)
    iTotal += hQUPIDsPerRow[++iPMTNb1];
  
  G4int iPMTNb2 = iPMTNb + hQUPIDsPerRow[iPMTNb1] - iTotal;
  
  hPos.setX(hQUPIDsRowOffset[iPMTNb1] + iPMTNb2*dQUPIDDistance);
  hPos.setY((0.5*(iNbQUPIDRows-1)-iPMTNb1)*dQUPIDRowDistance);
  
  return hPos;
}

G4ThreeVector
Xenon1tDetectorConstruction::GetQUPIDPositionBottomArray(G4int iPMTNb, PMTPart ePMTPart)
{
  const G4double dQUPIDWindowZ = GetGeometryParameter("BottomQUPIDWindowZ");
  
  const G4double dQUPIDBodyOffsetZ = GetGeometryParameter("QUPIDWindowOuterRadius")-GetGeometryParameter("QUPIDWindowOuterHeight")-0.5*GetGeometryParameter("QUPIDBodyHeight");
  const G4double dQUPIDBaseOffsetZ = dQUPIDBodyOffsetZ-0.5*(GetGeometryParameter("QUPIDBodyHeight")+GetGeometryParameter("QUPIDBaseThickness"));
  
  const G4double dQUPIDDistance = GetGeometryParameter("QUPIDDistance");
  const G4double dQUPIDRowDistance = sqrt(3.)/2.*dQUPIDDistance;
  
  G4ThreeVector hPos;
  
  switch(ePMTPart)
    {
    case PMT_WINDOW:
      hPos.setZ(dQUPIDWindowZ);
      break;
      
    case PMT_BODY:
      hPos.setZ(dQUPIDWindowZ + dQUPIDBodyOffsetZ);
      break;
      
    case PMT_BASE:
      hPos.setZ(dQUPIDWindowZ + dQUPIDBaseOffsetZ);
      break;
    }
  
  const G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  iPMTNb -= iNbTopPMTs;
  
  const G4int iNbQUPIDRows = 13;
  const G4int hQUPIDsPerRow[iNbQUPIDRows] = {5, 8, 9, 10, 11, 12, 11, 12, 11, 10, 9, 8, 5};
  
  vector<G4double> hQUPIDsRowOffset;
  for(G4int iQUPIDRowNb=0; iQUPIDRowNb<iNbQUPIDRows; iQUPIDRowNb++)
    hQUPIDsRowOffset.push_back((G4double)(-0.5*(hQUPIDsPerRow[iQUPIDRowNb]-1)*dQUPIDDistance));
  
  G4int iPMTNb1 = 0;
  G4int iTotal = hQUPIDsPerRow[0];
  while(iPMTNb+1>iTotal)
    iTotal += hQUPIDsPerRow[++iPMTNb1];
  
  G4int iPMTNb2 = iPMTNb + hQUPIDsPerRow[iPMTNb1] - iTotal;
  
  hPos.setX(hQUPIDsRowOffset[iPMTNb1] + iPMTNb2*dQUPIDDistance);
  hPos.setY((0.5*(iNbQUPIDRows-1)-iPMTNb1)*dQUPIDRowDistance);
  
  return hPos;
}

G4ThreeVector
Xenon1tDetectorConstruction::GetPMTPositionLSArray(G4int iPMTNb, PMTPart ePMTPart)
{
  const G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  const G4int iNbBottomPMTs = (G4int) GetGeometryParameter("NbBottomPMTs");
  const G4int iNbLSTopPMTs = (G4int) GetGeometryParameter("NbLSTopPMTs");
  const G4int iNbLSBottomPMTs = (G4int) GetGeometryParameter("NbLSBottomPMTs");
  const G4int iNbLSSidePMTColumns = (G4int) GetGeometryParameter("NbLSSidePMTColumns");
  const G4int iNbLSSidePMTRows = (G4int) GetGeometryParameter("NbLSSidePMTRows");
  
  const G4double dLSTopPMTWindowZ = GetGeometryParameter("LSTopPMTWindowZ");
  const G4double dLSBottomPMTWindowZ = GetGeometryParameter("LSBottomPMTWindowZ");
  const G4double dLSSidePMTWindowR = GetGeometryParameter("LSSidePMTWindowR");
  const G4double dPMTBodyOffset = GetGeometryParameter("PMTWindowTopZ") + 0.5*GetGeometryParameter("PMTBodyHeight");
  const G4double dPMTBaseOffset = GetGeometryParameter("PMTWindowTopZ") + GetGeometryParameter("PMTBodyHeight") + 0.5*GetGeometryParameter("PMTBaseHeight");
  
  const G4double dLSTopPMTDistance = GetGeometryParameter("LSTopPMTDistance");
  const G4double dLSBottomPMTDistance = GetGeometryParameter("LSBottomPMTDistance");
  const G4double dLSSidePMTRowDistance = GetGeometryParameter("LSSidePMTRowDistance");
  //  const G4double dLSSidePMTColumnDistance = 2.*M_PI * dLSSidePMTWindowR / iNbLSSidePMTColumns;
  
  const G4int iNbLSTopPMTRows = 3;
  const G4int hLSTopPMTsPerRow[iNbLSTopPMTRows] = {3, 3, 3};
  const G4int iNbLSBottomPMTRows = 3;
  const G4int hLSBottomPMTsPerRow[iNbLSBottomPMTRows] = {3, 3, 3};
  
  G4ThreeVector hPos;
  
  iPMTNb -= iNbTopPMTs + iNbBottomPMTs;
  
  if (iPMTNb<iNbLSTopPMTs) {
    switch(ePMTPart){
    case PMT_WINDOW:
      hPos.setZ(dLSTopPMTWindowZ);
      break;
        
    case PMT_BODY:
      hPos.setZ(dLSTopPMTWindowZ + dPMTBodyOffset);
      break;
        
    case PMT_BASE:
      hPos.setZ(dLSTopPMTWindowZ + dPMTBaseOffset);
      break;
    }
    
    vector<G4double> hLSTopPMTsRowOffset;
    for(G4int iLSTopPMTRowNb=0; iLSTopPMTRowNb<iNbLSTopPMTRows; iLSTopPMTRowNb++)
      hLSTopPMTsRowOffset.push_back((G4double)(-0.5*(hLSTopPMTsPerRow[iLSTopPMTRowNb]-1)*dLSTopPMTDistance));
    
    G4int iPMTNb1 = 0;
    G4int iTotal = hLSTopPMTsPerRow[0];
    while(iPMTNb+1>iTotal)
      iTotal += hLSTopPMTsPerRow[++iPMTNb1];
    
    G4int iPMTNb2 = iPMTNb + hLSTopPMTsPerRow[iPMTNb1] - iTotal;
    
    hPos.setX(hLSTopPMTsRowOffset[iPMTNb1] + iPMTNb2*dLSTopPMTDistance);
    hPos.setY((0.5*(iNbLSTopPMTRows-1)-iPMTNb1)*dLSTopPMTDistance);
  }
  
  else if (iPMTNb<iNbLSTopPMTs+iNbLSBottomPMTs)
    {
      iPMTNb -= iNbLSTopPMTs;
    
      switch(ePMTPart)
	{
	case PMT_WINDOW:
	  hPos.setZ(dLSBottomPMTWindowZ);
	  break;
        
	case PMT_BODY:
	  hPos.setZ(dLSBottomPMTWindowZ - dPMTBodyOffset);
	  break;
        
	case PMT_BASE:
	  hPos.setZ(dLSBottomPMTWindowZ - dPMTBaseOffset);
	  break;
	}
    
      vector<G4double> hLSBottomPMTsRowOffset;
      for(G4int iLSBottomPMTRowNb=0; iLSBottomPMTRowNb<iNbLSBottomPMTRows; iLSBottomPMTRowNb++)
	hLSBottomPMTsRowOffset.push_back((G4double)(-0.5*(hLSBottomPMTsPerRow[iLSBottomPMTRowNb]-1)*dLSBottomPMTDistance));
    
      G4int iPMTNb1 = 0;
      G4int iTotal = hLSBottomPMTsPerRow[0];
      while(iPMTNb+1>iTotal)
	iTotal += hLSBottomPMTsPerRow[++iPMTNb1];
    
      G4int iPMTNb2 = iPMTNb + hLSBottomPMTsPerRow[iPMTNb1] - iTotal;
    
      hPos.setX(hLSBottomPMTsRowOffset[iPMTNb1] + iPMTNb2*dLSBottomPMTDistance);
      hPos.setY((0.5*(iNbLSBottomPMTRows-1)-iPMTNb1)*dLSBottomPMTDistance);
    }
  
  else
    {
      iPMTNb -= iNbLSTopPMTs+iNbLSBottomPMTs;
    
      switch(ePMTPart)
	{
	case PMT_WINDOW:
	  hPos.setX(dLSSidePMTWindowR);
	  break;
        
	case PMT_BODY:
	  hPos.setX(dLSSidePMTWindowR + dPMTBodyOffset);
	  break;
        
	case PMT_BASE:
	  hPos.setX(dLSSidePMTWindowR + dPMTBaseOffset);
	  break;
	}
    
      hPos.setY(0);
      hPos.setZ((0.5*(iNbLSSidePMTRows-1)-(iPMTNb/iNbLSSidePMTColumns))*dLSSidePMTRowDistance);
      hPos.rotateZ((iPMTNb%iNbLSSidePMTColumns)*(360./iNbLSSidePMTColumns)*deg);
    }
  
  return hPos;
}





G4ThreeVector
Xenon1tDetectorConstruction::GetPMTPositionWaterArray(G4int iPMTNb, PMTPart ePMTPart)
{
  const G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  const G4int iNbBottomPMTs = (G4int) GetGeometryParameter("NbBottomPMTs");
  const G4int iNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  const G4int iNbWaterTopPMTs = (G4int) GetGeometryParameter("NbWaterTopPMTs");
  const G4int iNbWaterBottomPMTs = (G4int) GetGeometryParameter("NbWaterBottomPMTs");
  const G4int iNbWaterSidePMTColumns = (G4int) GetGeometryParameter("NbWaterSidePMTColumns");
  const G4int iNbWaterSidePMTRows = (G4int) GetGeometryParameter("NbWaterSidePMTRows");
  
  const G4double dWaterTopPMTWindowZ = GetGeometryParameter("WaterTopPMTWindowZ");
  const G4double dWaterBottomPMTWindowZ = GetGeometryParameter("WaterBottomPMTWindowZ");
  const G4double dWaterSidePMTWindowR = GetGeometryParameter("WaterSidePMTWindowR");
  const G4double dPMTBodyOffset = GetGeometryParameter("PMTWindowTopZ") + 0.5*GetGeometryParameter("PMTBodyHeight");
  const G4double dPMTBaseOffset = GetGeometryParameter("PMTWindowTopZ") + GetGeometryParameter("PMTBodyHeight") + 0.5*GetGeometryParameter("PMTBaseHeight");
  
  //	const G4double dWaterTopPMTDistance = GetGeometryParameter("WaterTopPMTDistance");			//unused variable
  //	const G4double dWaterBottomPMTDistance = GetGeometryParameter("WaterBottomPMTDistance");	//unused variable
  const G4double dWaterSidePMTRowDistance = GetGeometryParameter("WaterSidePMTRowDistance");
  //	const G4double dWaterSidePMTColumnDistance = 2.*M_PI * dWaterSidePMTWindowR / iNbWaterSidePMTColumns;
  
  //	const G4int iNbWaterTopPMTRows = 3;															//unused variable
  //	const G4int hWaterTopPMTsPerRow[iNbWaterTopPMTRows] = {3, 3, 3};							//unused variable
  //	const G4int iNbWaterBottomPMTRows = 5;														//unused variable
  //	const G4int hWaterBottomPMTsPerRow[iNbWaterBottomPMTRows] = {5, 5, 5, 5, 5};				//unused variable
	
  
	
  G4ThreeVector hPos;
  
  iPMTNb -= iNbTopPMTs + iNbBottomPMTs + iNbLSPMTs;
  
  
  //*** TOP WATER PMTs *************************************************************************************************************************
      if (iPMTNb<iNbWaterTopPMTs)	
      {
	switch(ePMTPart)
	  {
	  case PMT_WINDOW:
	    hPos.setZ(dWaterTopPMTWindowZ);
	    break;
        
	  case PMT_BODY:
	    hPos.setZ(dWaterTopPMTWindowZ + dPMTBodyOffset);	// Serena's comment
	    //				hPos.setZ(dWaterTopPMTWindowZ - dPMTBodyOffset);	// SERENA
	    break;
        
	  case PMT_BASE:
	    hPos.setZ(dWaterTopPMTWindowZ + dPMTBaseOffset);	// Serena's comment
	    //				hPos.setZ(dWaterTopPMTWindowZ - dPMTBaseOffset);	// SERENA
	    break;
	  }
		
	// TO BE CHANGED T1 <--> T2	TOP PMTs @top cylinder (9010)
	const G4int hWaterTopPMTsX[24] = {4462, 4157, 3570, 2739, 1722, 587, -588, -1723, -2740, -3571, -4158, -4462,
					  -4462, -4158, -3571, -2740, -1723, -588, 587, 1722, 2739, 3570, 4157, 4462}; // SERENA // final Tank R = 4.8m
    
	const G4int hWaterTopPMTsY[24] = {587, 1722, 2739, 3570, 4157, 4462, 4462, 4157, 3570, 2739, 1722, 587, -588,
					  -1723, -2740, -3571, -4158, -4462, -4462, -4158, -3571, -2740, -1723, -588}; // SERENA // final Tank R = 4.8m
    
		
		
    
	hPos.setX(hWaterTopPMTsX[iPMTNb]);			// SERENA
	hPos.setY(hWaterTopPMTsY[iPMTNb]);			// SERENA
	//G4cout << iPMTNb << G4endl;
		
      }
  
  
  //*** BOTTOM WATER PMTs *************************************************************************************************************************
  else if (iPMTNb<iNbWaterTopPMTs+iNbWaterBottomPMTs) 
    {
      iPMTNb -= iNbWaterTopPMTs;
		
      switch(ePMTPart)
	{
	case PMT_WINDOW:
	  hPos.setZ(dWaterBottomPMTWindowZ);
	  break;
        
	case PMT_BODY:
	  hPos.setZ(dWaterBottomPMTWindowZ - dPMTBodyOffset);
	  break;
        
	case PMT_BASE:
	  hPos.setZ(dWaterBottomPMTWindowZ - dPMTBaseOffset);
	  break;
	}
		
    
      const G4int hWaterBottomPMTsX[24] = {4462, 4157, 3570, 2739, 1722, 587, -588, -1723, -2740, -3571, -4158, -4462, -4462, 
					   -4158, -3571, -2740, -1723, -588, 587, 1722, 2739, 3570, 4157, 4462}; // SERENA // final Tank R = 4.8m
    
    
      const G4int hWaterBottomPMTsY[24] = {587, 1722, 2739, 3570, 4157, 4462, 4462, 4157, 3570, 2739, 1722, 587, -588, -1723,
					   -2740, -3571, -4158, -4462, -4462, -4158, -3571, -2740, -1723, -588}; // SERENA // final Tank R = 4.8m
    
    
      hPos.setX(hWaterBottomPMTsX[iPMTNb]);			// SERENA
      hPos.setY(hWaterBottomPMTsY[iPMTNb]);			// SERENA
      //	G4cout << iPMTNb << G4endl;
    
		
    }
  
  //*** LATERAL WATER PMTs *************************************************************************************************************************
  else 
      {
	iPMTNb -= iNbWaterTopPMTs+iNbWaterBottomPMTs;
    
	switch(ePMTPart)
	  {
	  case PMT_WINDOW:
	    hPos.setX(dWaterSidePMTWindowR);
	    break;
        
	  case PMT_BODY:
	    hPos.setX(dWaterSidePMTWindowR + dPMTBodyOffset);	// Serena's comment
	    //hPos.setX(dWaterSidePMTWindowR - dPMTBodyOffset);	// SERENA
	    break;
        
	  case PMT_BASE:
	    hPos.setX(dWaterSidePMTWindowR + dPMTBaseOffset);	// Serena's comment
	    //hPos.setX(dWaterSidePMTWindowR - dPMTBaseOffset);	// SERENA
	    break;
	  }
		
	hPos.setY(0);
	//	hPos.setZ((0.5*(iNbWaterSidePMTRows-1)-(iPMTNb/iNbWaterSidePMTColumns))*dWaterSidePMTRowDistance);				// Serena's comment
	hPos.setZ((0.5*(iNbWaterSidePMTRows-1)-(iPMTNb/iNbWaterSidePMTColumns))*dWaterSidePMTRowDistance + 0.*cm);		// SERENA
	hPos.rotateZ((iPMTNb%iNbWaterSidePMTColumns)*(360./iNbWaterSidePMTColumns)*deg + 15.*deg); //******SERENA****** to be compatible with Rainer
												       }
  
  return hPos;
}


//**************************************************************************************************************************************************



G4RotationMatrix *
Xenon1tDetectorConstruction::GetPMTRotation(G4int iPMTNb)
{
  const G4int iNbTopPMTs = (G4int) GetGeometryParameter("NbTopPMTs");
  const G4int iNbBottomPMTs = (G4int) GetGeometryParameter("NbBottomPMTs");
  
  const G4int iNbLSPMTs = (G4int) GetGeometryParameter("NbLSPMTs");
  const G4int iNbLSTopPMTs = (G4int) GetGeometryParameter("NbLSTopPMTs");
  const G4int iNbLSBottomPMTs = (G4int) GetGeometryParameter("NbLSBottomPMTs");
  const G4int iNbLSSidePMTColumns = (G4int) GetGeometryParameter("NbLSSidePMTColumns");
  
  const G4int iNbWaterPMTs = (G4int) GetGeometryParameter("NbWaterPMTs");
  const G4int iNbWaterTopPMTs = (G4int) GetGeometryParameter("NbWaterTopPMTs");
  const G4int iNbWaterBottomPMTs = (G4int) GetGeometryParameter("NbWaterBottomPMTs");
  const G4int iNbWaterSidePMTColumns = (G4int) GetGeometryParameter("NbWaterSidePMTColumns");
  
  G4RotationMatrix *pRotationMatrix = new G4RotationMatrix();
  
  if (iPMTNb < iNbTopPMTs)
    pRotationMatrix->rotateX(180.*deg);
  else if (iPMTNb < iNbTopPMTs+iNbBottomPMTs)
    pRotationMatrix->rotateX(0.*deg);
  else if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs)
    {
      if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSTopPMTs)
	pRotationMatrix->rotateX(0.*deg);
      else if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSTopPMTs+iNbLSBottomPMTs)
	pRotationMatrix->rotateX(180.*deg);
      else
	{
	  pRotationMatrix->rotateY(-90.*deg);
	  pRotationMatrix->rotateX(((iPMTNb-iNbTopPMTs-iNbBottomPMTs-iNbLSTopPMTs-iNbLSBottomPMTs)%iNbLSSidePMTColumns)*(360./iNbLSSidePMTColumns)*deg);
	}
    }
  else if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs+iNbWaterPMTs)// WATER PMTS
    {
      if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs+iNbWaterTopPMTs) // TOP
	pRotationMatrix->rotateX(0.*deg);	// Serena's comment
      //	pRotationMatrix->rotateX(180.*deg);	// SERENA
      else if (iPMTNb < iNbTopPMTs+iNbBottomPMTs+iNbLSPMTs+iNbWaterTopPMTs+iNbWaterBottomPMTs) // BOTTOM
	pRotationMatrix->rotateX(180.*deg);
      else	// LATERAL
	{
	  pRotationMatrix->rotateY(-90.*deg); // Serena's comment
	  pRotationMatrix->rotateX(((iPMTNb-iNbTopPMTs-iNbBottomPMTs-iNbLSPMTs-iNbWaterTopPMTs-iNbWaterBottomPMTs)%iNbWaterSidePMTColumns)*(360./iNbWaterSidePMTColumns)*deg+15*deg);	
	  //******SERENA****** to be compatible with Rainer
			
			
	      //pRotationMatrix->rotateY(90.*deg); // SERENA
	      //pRotationMatrix->rotateX(-((iPMTNb-iNbTopPMTs-iNbBottomPMTs-iNbLSPMTs-iNbWaterTopPMTs-iNbWaterBottomPMTs)%iNbWaterSidePMTColumns)*(360./iNbWaterSidePMTColumns)*deg);	// SERENA
      
	      //	G4cout << (((iPMTNb-iNbTopPMTs-iNbBottomPMTs-iNbLSPMTs-iNbWaterTopPMTs-iNbWaterBottomPMTs)%iNbWaterSidePMTColumns)*(360./iNbWaterSidePMTColumns)*deg) << G4endl;
	      }
    }
  
  return pRotationMatrix;
}

void Xenon1tDetectorConstruction::SetTeflonReflectivity(G4double dReflectivity)
{
  G4Material *pTeflonMaterial = G4Material::GetMaterial(G4String("Teflon"));
  
  if(pTeflonMaterial)
    {
      G4cout << "\n----> Setting Teflon reflectivity to " << dReflectivity << G4endl;
    
      G4MaterialPropertiesTable *pTeflonPropertiesTable = pTeflonMaterial->GetMaterialPropertiesTable();
    
      const G4int iNbEntries = 3;
    
      G4double teflon_PP[iNbEntries] = { 6.91 * eV, 6.98 * eV, 7.05 * eV };
      G4double teflon_REFL[iNbEntries] = {dReflectivity, dReflectivity, dReflectivity};
      pTeflonPropertiesTable->RemoveProperty("REFLECTIVITY");
      pTeflonPropertiesTable->AddProperty("REFLECTIVITY", teflon_PP, teflon_REFL, iNbEntries);
      //pTeflonPropertiesTable->DumpTable();
   }
  else
    {
      G4cout << "!!!!> Teflon material not found!" << G4endl;
      exit(-1);
    }
}


void Xenon1tDetectorConstruction::SetLXeScintillation(G4bool bScintillation)
{
  G4cout << "----> Setting LXe(GXe) scintillation to " << bScintillation << G4endl;
  
  G4Material *pLXeMaterial = G4Material::GetMaterial(G4String("LXe"));
  if(pLXeMaterial)
    {  
    
      G4MaterialPropertiesTable *pLXePropertiesTable = pLXeMaterial->GetMaterialPropertiesTable();
      if(bScintillation)
	pLXePropertiesTable->AddConstProperty("SCINTILLATIONYIELD", 1000./(1.0*keV));
    }
  else
    {
      G4cout << "ls!> LXe materials not found!" << G4endl;
      exit(-1);
    }
  
  G4Material *pGXeMaterial = G4Material::GetMaterial(G4String("GXe"));
  if(pGXeMaterial)
    {  
    
      G4MaterialPropertiesTable *pGXePropertiesTable = pGXeMaterial->GetMaterialPropertiesTable();
      if(bScintillation)
	pGXePropertiesTable->AddConstProperty("SCINTILLATIONYIELD", 1000./(1.0*keV));
    }
  else
    {
      G4cout << "ls!> GXe materials not found!" << G4endl;
      exit(-1);
    }
}



void Xenon1tDetectorConstruction::SetLXeAbsorbtionLength(G4double dAbsorbtionLength)
{
  G4Material *pLXeMaterial = G4Material::GetMaterial(G4String("LXe"));
  
  if(pLXeMaterial)
    {
      G4cout << "----> Setting LXe absorbtion length to " << dAbsorbtionLength/cm << " cm" << G4endl;
    
      G4MaterialPropertiesTable *pLXePropertiesTable = pLXeMaterial->GetMaterialPropertiesTable();
    
      const G4int iNbEntries = 3;
    
      G4double LXe_PP[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double LXe_ABSL[iNbEntries] = {dAbsorbtionLength, dAbsorbtionLength, dAbsorbtionLength};
      pLXePropertiesTable->RemoveProperty("ABSLENGTH");
      pLXePropertiesTable->AddProperty("ABSLENGTH", LXe_PP, LXe_ABSL, iNbEntries);
    }
  else
    {
      G4cout << "ls!> LXe materials not found!" << G4endl;
      exit(-1);
    }
}

void Xenon1tDetectorConstruction::SetLXeRayScatterLength(G4double dRayScatterLength)
{
  G4Material *pLXeMaterial = G4Material::GetMaterial(G4String("LXe"));
  
  if(pLXeMaterial)
    {
    
      G4cout << "----> Setting LXe scattering length to " << dRayScatterLength/cm << " cm" << G4endl;
    
      G4MaterialPropertiesTable *pLXePropertiesTable = pLXeMaterial->GetMaterialPropertiesTable();
    
      const G4int iNbEntries = 3;
    
      G4double LXe_PP[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double LXe_SCAT[iNbEntries] = {dRayScatterLength, dRayScatterLength, dRayScatterLength};
      pLXePropertiesTable->RemoveProperty("RAYLEIGH");
      pLXePropertiesTable->AddProperty("RAYLEIGH", LXe_PP, LXe_SCAT, iNbEntries);
    }
  else
    {
      G4cout << "ls!> LXe materials not found!" << G4endl;
      exit(-1);
    }
}


void Xenon1tDetectorConstruction::SetGridMeshTransparency(G4double dTransparency)
{
  G4Material *pGridMeshMaterial = G4Material::GetMaterial(G4String("GridMeshAluminium"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetGridMeshTransparency " << dTransparency << G4endl;

  if(pGridMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("GridMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pGridMeshPropertiesTable = pGridMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdGridMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdGridMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pGridMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pGridMeshPropertiesTable->AddProperty("ABSLENGTH", pdGridMeshPhotonMomentum, pdGridMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> grid material not found!" << G4endl;
      exit(-1);
    }
}


// Cyril, June 2014
void Xenon1tDetectorConstruction::SetTopScreeningMeshTransparency(G4double dTransparency)
{
  G4Material *pTopScreeningMeshMaterial = G4Material::GetMaterial(G4String("TopScreeningMesh"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetTopScreeningMeshTransparency " << dTransparency << G4endl;

  if(pTopScreeningMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("TopScreeningMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pTopScreeningMeshPropertiesTable = pTopScreeningMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdTopScreeningMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdTopScreeningMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pTopScreeningMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pTopScreeningMeshPropertiesTable->AddProperty("ABSLENGTH", pdTopScreeningMeshPhotonMomentum, pdTopScreeningMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> top screenin mesh material not found!" << G4endl;
      exit(-1);
    }
}

void Xenon1tDetectorConstruction::SetBottomScreeningMeshTransparency(G4double dTransparency)
{
  G4Material *pBottomScreeningMeshMaterial = G4Material::GetMaterial(G4String("BottomScreeningMesh"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetBottomScreeningMeshTransparency " << dTransparency << G4endl;

  if(pBottomScreeningMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("BottomScreeningMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pBottomScreeningMeshPropertiesTable = pBottomScreeningMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdBottomScreeningMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdBottomScreeningMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pBottomScreeningMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pBottomScreeningMeshPropertiesTable->AddProperty("ABSLENGTH", pdBottomScreeningMeshPhotonMomentum, pdBottomScreeningMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> bottom screening mesh material not found!" << G4endl;
      exit(-1);
    }
}

void Xenon1tDetectorConstruction::SetCathodeMeshTransparency(G4double dTransparency)
{
  G4Material *pCathodeMeshMaterial = G4Material::GetMaterial(G4String("CathodeMesh"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetCathodeMeshTransparency " << dTransparency << G4endl;

  if(pCathodeMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("CathodeMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pCathodeMeshPropertiesTable = pCathodeMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdCathodeMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdCathodeMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pCathodeMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pCathodeMeshPropertiesTable->AddProperty("ABSLENGTH", pdCathodeMeshPhotonMomentum, pdCathodeMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> cathode mesh material not found!" << G4endl;
      exit(-1);
    }
}

void Xenon1tDetectorConstruction::SetAnodeMeshTransparency(G4double dTransparency)
{ 
  G4Material *pAnodeMeshMaterial = G4Material::GetMaterial(G4String("AnodeMesh"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetAnodeMeshTransparency " << dTransparency << G4endl;

  if(pAnodeMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("AnodeMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pAnodeMeshPropertiesTable = pAnodeMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdAnodeMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdAnodeMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pAnodeMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pAnodeMeshPropertiesTable->AddProperty("ABSLENGTH", pdAnodeMeshPhotonMomentum, pdAnodeMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> anode mesh material not found!" << G4endl;
      exit(-1);
    }
}

void Xenon1tDetectorConstruction::SetGateMeshTransparency(G4double dTransparency)
{
  G4Material *pGateMeshMaterial = G4Material::GetMaterial(G4String("GateMesh"));
  
  G4cout << "!!!!!!!!!!!!!!!! SetGateMeshTransparency " << dTransparency << G4endl;

  if(pGateMeshMaterial)
    {
      G4cout << "----> Setting grid transparency to " << dTransparency*100 << " %" << G4endl;
      G4double dAbsorptionLength =  ((G4double)GetGeometryParameter("GateMeshThickness"))/(-log(dTransparency)); 
      G4MaterialPropertiesTable *pGateMeshPropertiesTable = pGateMeshMaterial->GetMaterialPropertiesTable();
      const G4int iNbEntries = 3;
      G4double pdGateMeshPhotonMomentum[iNbEntries] = {6.91*eV, 6.98*eV, 7.05*eV};
      G4double pdGateMeshAbsorptionLength[iNbEntries] = {dAbsorptionLength, dAbsorptionLength, dAbsorptionLength};
      pGateMeshPropertiesTable->RemoveProperty("ABSLENGTH");
      pGateMeshPropertiesTable->AddProperty("ABSLENGTH", pdGateMeshPhotonMomentum, pdGateMeshAbsorptionLength, iNbEntries);
   }
  else
    {
      G4cout << "ls!> gate mesh material not found!" << G4endl;
      exit(-1);
    }
}
















// SERENA: you may be interested or not, but this routien writes teh geometry parameters to a root file. 
// als material information is written to file. 
void Xenon1tDetectorConstruction::MakeDetectorPlots()
{
  _fGeom = new TFile(detRootFile,"RECREATE");
  _detector = _fGeom->mkdir("detector");
  
  // xenon
  MakeXenonPlots();
  // cryostat
  MakeCryostatPlots();
  
  // TPC
  
  // Water tank
  
  // etc etc
  
  _fGeom->Write();
  _fGeom->Close();
  
}

// SERENA: if you are interested you can write the geometry parameters + 
void Xenon1tDetectorConstruction::MakeXenonPlots()
{
  
  // make a list of materials for graphs
  G4int nmaterial = G4Material::GetNumberOfMaterials(); 
  G4cout <<"MakeDetectorPlots:: Number of materials = "<<nmaterial<<G4endl;
  
  TDirectory *_materials = _detector->mkdir("materials");
  _materials->cd();
  
  //  for(G4int imat=0; imat<(G4int)matNames.size(); imat++){
  vector<TDirectory*> matdirs;
  
  for(G4int imat=0; imat<nmaterial; imat++){
    G4Material *mat = G4NistManager::Instance()->GetMaterial(imat);
    G4String matname = mat->GetName();
    G4cout <<"MakeDetectorPlots:: "<<matname<<G4endl;
    G4double T   = mat->GetTemperature();
    G4double rho = mat->GetDensity();
    G4double P   = mat->GetPressure();
    
    matdirs.push_back(_materials->mkdir(matname));
    matdirs[imat]->cd();
    TParameter<double> *TemperaturePar = new TParameter<double>("Temperature",T);
    TemperaturePar->Write();
    TParameter<double> *DensityPar     = new TParameter<double>("Density",rho / (g/cm3));
    DensityPar->Write();
    TParameter<double> *PressurePar    = new TParameter<double>("Pressure",P / bar);
    PressurePar->Write();
    // disect the material
    size_t nele = mat->GetNumberOfElements();
    G4ElementVector *elems       = (G4ElementVector*)mat->GetElementVector();
    G4double        *fractionVec = (G4double*)mat->GetFractionVector();
    
    for(size_t iele=0; iele<nele; iele++){
      G4String elname = (*elems)[iele]->GetName();
      G4double frac   = fractionVec[iele];
      //      G4cout <<iele<<" elem = "<<(*elems)[iele]->GetName()<<" f = "<<fractionVec[iele]<<G4endl;
      char  elFrac[100];
      sprintf(elFrac,"f_%s",elname.c_str());
      TParameter<double> *_fracPar = new TParameter<double>((G4String)elFrac,frac);
      _fracPar->Write();
    }
    
    
    _materials->cd();
  }
  
  _fGeom->cd();
}


void Xenon1tDetectorConstruction::MakeCryostatPlots()
{
  TDirectory *_cryostat = _detector->mkdir("cryostat");
  TDirectory *_inner    = _cryostat->mkdir("inner");
  TDirectory *_outer    = _cryostat->mkdir("outer");
  _cryostat->cd();
  TNamed *CryostatTypePar = new TNamed("CryostatType",pCryostatType);
  CryostatTypePar->Write();  
  TParameter<double> *LXeLevelPar = new TParameter<double>("LiquidLevelZ",GetGeometryParameter("LiquidLevelZ"));
  LXeLevelPar->Write();
  
  // parameters for the outer cryostat
  _outer->cd();
  TNamed *OuterCryostatMaterialPar = new TNamed("OuterCryostatMaterial",pCryostatMaterial);
  OuterCryostatMaterialPar->Write();
  TParameter<double> *OuterCryostatMassPar = new TParameter<double>("OuterCryostatMass",dOuterCryostatMass);
  OuterCryostatMassPar->Write();
  TParameter<double> *OuterCryostatThicknessPar = new TParameter<double>("OuterCryostatThickness",GetGeometryParameter("OuterCryostatThickness"));
  OuterCryostatThicknessPar->Write();
  TParameter<double> *OuterCryostatThicknessTopPar = new TParameter<double>("OuterCryostatThicknessTop",GetGeometryParameter("OuterCryostatThicknessTop"));
  OuterCryostatThicknessTopPar->Write();
  TParameter<double> *OuterCryostatThicknessBotPar = new TParameter<double>("OuterCryostatThicknessBot",GetGeometryParameter("OuterCryostatThicknessBot"));
  OuterCryostatThicknessBotPar->Write();
  TParameter<double> *OuterCryostatOuterDiameterPar = new TParameter<double>("OuterCryostatOuterDiameter",GetGeometryParameter("OuterCryostatOuterDiameter"));
  OuterCryostatOuterDiameterPar->Write();
  TParameter<double> *OuterCryostatCylinderHeightPar = new TParameter<double>("OuterCryostatCylinderHeight",GetGeometryParameter("OuterCryostatCylinderHeight"));
  OuterCryostatCylinderHeightPar->Write();
  TParameter<double> *OuterCryostatFlangeHeightPar = new TParameter<double>("OuterCryostatFlangeHeight",GetGeometryParameter("OuterCryostatFlangeHeight"));
  OuterCryostatFlangeHeightPar->Write();
  TParameter<double> *OuterCryostatFlangeZPar = new TParameter<double>("OuterCryostatFlangeZ",GetGeometryParameter("OuterCryostatFlangeZ"));
  OuterCryostatFlangeZPar->Write();
  TParameter<double> *OuterCryostatFlangeThicknessPar = new TParameter<double>("OuterCryostatFlangeThickness",GetGeometryParameter("OuterCryostatFlangeThickness"));
  OuterCryostatFlangeThicknessPar->Write();
  TParameter<double> *OuterCryostatOffsetZPar = new TParameter<double>("OuterCryostatOffsetZ",GetGeometryParameter("OuterCryostatOffsetZ"));
  OuterCryostatOffsetZPar->Write();
  TParameter<double> *OuterCryostatR0topPar = new TParameter<double>("OuterCryostatR0top",GetGeometryParameter("OuterCryostatR0top"));
  OuterCryostatR0topPar->Write();
  TParameter<double> *OuterCryostatR1topPar = new TParameter<double>("OuterCryostatR1top",GetGeometryParameter("OuterCryostatR1top"));
  OuterCryostatR1topPar->Write();
  TParameter<double> *OuterCryostatR0botPar = new TParameter<double>("OuterCryostatR0bot",GetGeometryParameter("OuterCryostatR0bot"));
  OuterCryostatR0botPar->Write();
  TParameter<double> *OuterCryostatR1botPar = new TParameter<double>("OuterCryostatR1bot",GetGeometryParameter("OuterCryostatR1bot"));
  OuterCryostatR1botPar->Write();  
  
  // parameters for the inner cryostat
  _inner->cd();
  TNamed *InnerCryostatMaterialPar = new TNamed("InnerCryostatMaterial",pCryostatMaterial);
  InnerCryostatMaterialPar->Write();
  TParameter<double> *InnerCryostatMassPar = new TParameter<double>("InnerCryostatMass",dInnerCryostatMass);
  InnerCryostatMassPar->Write();
  TParameter<double> *InnerCryostatThicknessPar = new TParameter<double>("InnerCryostatThickness",GetGeometryParameter("InnerCryostatThickness"));
  InnerCryostatThicknessPar->Write();
  TParameter<double> *InnerCryostatThicknessTopPar = new TParameter<double>("InnerCryostatThicknessTop",GetGeometryParameter("InnerCryostatThicknessTop"));
  InnerCryostatThicknessTopPar->Write();
  TParameter<double> *InnerCryostatThicknessBotPar = new TParameter<double>("InnerCryostatThicknessBot",GetGeometryParameter("InnerCryostatThicknessBot"));
  InnerCryostatThicknessBotPar->Write();
  TParameter<double> *InnerCryostatOuterDiameterPar = new TParameter<double>("InnerCryostatOuterDiameter",GetGeometryParameter("InnerCryostatOuterDiameter"));
  InnerCryostatOuterDiameterPar->Write();
  TParameter<double> *InnerCryostatCylinderHeightPar = new TParameter<double>("InnerCryostatCylinderHeight",GetGeometryParameter("InnerCryostatCylinderHeight"));
  InnerCryostatCylinderHeightPar->Write();
  TParameter<double> *InnerCryostatFlangeHeightPar = new TParameter<double>("InnerCryostatFlangeHeight",GetGeometryParameter("InnerCryostatFlangeHeight"));
  InnerCryostatFlangeHeightPar->Write();
  TParameter<double> *InnerCryostatFlangeZPar = new TParameter<double>("InnerCryostatFlangeZ",GetGeometryParameter("InnerCryostatFlangeZ"));
  InnerCryostatFlangeZPar->Write();
  TParameter<double> *InnerCryostatFlangeThicknessPar = new TParameter<double>("InnerCryostatFlangeThickness",GetGeometryParameter("InnerCryostatFlangeThickness"));
  InnerCryostatFlangeThicknessPar->Write();
  TParameter<double> *InnerCryostatOffsetZPar = new TParameter<double>("InnerCryostatOffsetZ",GetGeometryParameter("InnerCryostatOffsetZ"));
  InnerCryostatOffsetZPar->Write();
  TParameter<double> *InnerCryostatR0topPar = new TParameter<double>("InnerCryostatR0top",GetGeometryParameter("InnerCryostatR0top"));
  InnerCryostatR0topPar->Write();
  TParameter<double> *InnerCryostatR1topPar = new TParameter<double>("InnerCryostatR1top",GetGeometryParameter("InnerCryostatR1top"));
  InnerCryostatR1topPar->Write();
  TParameter<double> *InnerCryostatR0botPar = new TParameter<double>("InnerCryostatR0bot",GetGeometryParameter("InnerCryostatR0bot"));
  InnerCryostatR0botPar->Write();
  TParameter<double> *InnerCryostatR1botPar = new TParameter<double>("InnerCryostatR1bot",GetGeometryParameter("InnerCryostatR1bot"));
  InnerCryostatR1botPar->Write(); 
  
  _fGeom->cd();
}
