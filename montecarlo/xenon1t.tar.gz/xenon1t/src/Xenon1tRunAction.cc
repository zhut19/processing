#include <Randomize.hh>

#include <sys/time.h>

#include "Xenon1tAnalysisManager.hh"

#include "Xenon1tRunAction.hh"

Xenon1tRunAction::Xenon1tRunAction(Xenon1tAnalysisManager *pAnalysisManager)
{
  m_hRanSeed         = 12345; // default value
  m_pMessenger       = new Xenon1tRunActionMessenger(this);
  
  m_pAnalysisManager = pAnalysisManager;
  
}

Xenon1tRunAction::~Xenon1tRunAction()
{
  delete m_pMessenger;
}

void
Xenon1tRunAction::BeginOfRunAction(const G4Run *pRun)
{
  if(m_pAnalysisManager) {
    //    m_pAnalysisManager->SetForcedTransport(m_hForcedTransport);
    m_pAnalysisManager->BeginOfRun(pRun);
  }
  
  // random seeding of the MC
  if(m_hRanSeed > 0){
    CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
    G4cout << "Xenon1tRunAction::BeginOfRunAction Initialize random numbers with seed = "<<m_hRanSeed<<G4endl;
    CLHEP::HepRandom::setTheSeed(m_hRanSeed);
  } else {
    // initialize with time.....
    struct timeval hTimeValue;
    gettimeofday(&hTimeValue, NULL);
    G4cout << "Xenon1tRunAction::BeginOfRunAction Initialize random numbers with seed = "<<hTimeValue.tv_usec<<G4endl;
    CLHEP::HepRandom::setTheSeed(hTimeValue.tv_usec);
  }
}

void
Xenon1tRunAction::EndOfRunAction(const G4Run *pRun)
{
  if(m_pAnalysisManager)
    m_pAnalysisManager->EndOfRun(pRun);
}

