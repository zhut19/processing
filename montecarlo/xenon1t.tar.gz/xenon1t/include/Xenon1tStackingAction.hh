#ifndef __XENON10PSTACKINGACTION_H__
#define __XENON10PSTACKINGACTION_H__

#include <globals.hh>
#include <G4UserStackingAction.hh>

class Xenon1tAnalysisManager;

class Xenon1tStackingAction: public G4UserStackingAction
{
public:
	Xenon1tStackingAction(Xenon1tAnalysisManager *pAnalysisManager=0);
	~Xenon1tStackingAction();
  
	virtual G4ClassificationOfNewTrack ClassifyNewTrack(const G4Track* aTrack);
	virtual void NewStage();
	virtual void PrepareNewEvent();

private:
	Xenon1tAnalysisManager *m_pAnalysisManager;
};

#endif // __XENON10PSTACKINGACTION_H__

