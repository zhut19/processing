#ifndef Xenon1tDetectorMessenger_h
#define Xenon1tDetectorMessenger_h 1

#include <G4UImessenger.hh>
#include <globals.hh>

class Xenon1tDetectorConstruction;

class G4UIcommand;
class G4UIdirectory;
class G4UIcmdWithoutParameter;
class G4UIcmdWithAString;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWith3Vector;
class G4UIcmdWith3VectorAndUnit;
class G4UIcmdWithAnInteger;
class G4UIcmdWithADouble;
class G4UIcmdWithABool;
class G4UIcmdWithoutParameter;

class Xenon1tDetectorMessenger: public G4UImessenger
{
public:
	Xenon1tDetectorMessenger(Xenon1tDetectorConstruction *pXeDetector);
	~Xenon1tDetectorMessenger();

	void     SetNewValue(G4UIcommand *pUIcommand, G4String hString);
//  G4String GetCurrentValue(G4UIcommand *pUIcommand);
private:
	Xenon1tDetectorConstruction* m_pXeDetector;

	G4UIdirectory *m_pDetectorDir;

	G4UIcmdWithADouble *m_pTeflonReflectivityCmd;
	G4UIcmdWithABool *m_pLXeScintillationCmd;
	G4UIcmdWithADoubleAndUnit *m_pLXeAbsorbtionLengthCmd;
	G4UIcmdWithADoubleAndUnit *m_pLXeRayScatterLengthCmd;
  G4UIcmdWithADouble *m_pGridMeshTransparencyCmd; // Cyril, December 2013

  G4UIcmdWithADouble *m_pBottomScreeningMeshTransparencyCmd;
  G4UIcmdWithADouble *m_pTopScreeningMeshTransparencyCmd;
  G4UIcmdWithADouble *m_pAnodeMeshTransparencyCmd;
  G4UIcmdWithADouble *m_pCathodeMeshTransparencyCmd;
  G4UIcmdWithADouble *m_pGateMeshTransparencyCmd;

  // SERENA.....
  
  // APC 25-07-2011
	//
	// In order to run with different materials and wall thicknesses
	//
	G4UIcmdWithAString        *m_pCryostatTypeCmd;
  G4UIcmdWithAString        *m_pCryostatMaterialCmd;
  G4UIcmdWithAString        *m_pNeutronSourceSurroundingsCmd;
	G4UIcmdWithADoubleAndUnit *m_pCryostatOuterWallCmd;
	G4UIcmdWithADoubleAndUnit *m_pCryostatInnerWallCmd;
  G4UIcmdWithADoubleAndUnit *m_pCryostatInnerODCmd;
  G4UIcmdWithADoubleAndUnit *m_pCryostatOuterODCmd;
    
      G4UIcmdWithAString        *m_pMuonVetoMaterialCmd;
    G4UIcmdWithABool        *m_pSetFillBufferCmd;
  G4UIcmdWithADoubleAndUnit  *m_pSetBufferThicknessCmd;
  G4UIcmdWithABool        *m_pSetTpcWithBellCmd;
  G4UIcmdWithABool        *m_pSetLXeVetoCmd;
  
  // do we want tot check for overlapping objects?
  G4UIcmdWithABool          *m_pCheckOverlapCmd;
  G4UIcmdWithABool          *m_pSetTPCCmd;

	
};

#endif

