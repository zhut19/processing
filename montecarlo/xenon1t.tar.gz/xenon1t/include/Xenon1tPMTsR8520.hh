#ifndef Xenon1tPMTsR8520_H
#define Xenon1tPMTsR8520_H

#include <G4Material.hh>
#include <G4Box.hh>
#include <G4Tubs.hh>
#include <G4Polyhedra.hh>
#include <G4Polycone.hh>
#include <G4Ellipsoid.hh>
#include <G4UnionSolid.hh>
#include <G4SubtractionSolid.hh>
#include <G4LogicalVolume.hh>
#include <G4VPhysicalVolume.hh>
#include <G4VisAttributes.hh>
#include <G4Colour.hh>
#include <globals.hh>

#include "Xenon1tDetectorConstruction.hh"
// #include "Xenon1tMaterials.hh"

class Xenon1tPMTsR8520
{
public:
  Xenon1tPMTsR8520(Xenon1tDetectorConstruction*);
  ~Xenon1tPMTsR8520();

  G4LogicalVolume* Construct();

private:
//   Xenon1tMaterials            *pMaterials;
  Xenon1tDetectorConstruction *pDetectorConstrution;

  G4double dVetoPmtWidth;
  G4double dVetoPmtSpacing; 
  G4double dVetoPmtWindowWidth;
  G4double dVetoPmtWindowThickness;
  G4double dVetoPmtCasingWidth;
  G4double dVetoPmtCasingHeight; 
  G4double dVetoPmtCasingThickness;
  G4double dVetoPmtPhotoCathodeWidth;
  G4double dVetoPmtPhotoCathodeThickness;
  G4double dVetoPmtBaseThickness;
  G4double dVetoPmtToPmtBase;
  G4double dVetoPmtBaseSpacerHeight;

  G4LogicalVolume *m_pVetoPMTLogicalVolume;
  G4LogicalVolume *m_pVetoPMTWindowLogicalVolume;
  G4LogicalVolume *m_pVetoPMTCasingLogicalVolume;
  G4LogicalVolume *m_pVetoPMTInteriorLogicalVolume;
  G4LogicalVolume *m_pVetoPMTPhotoCathodeLogicalVolume;
  G4LogicalVolume *m_pVetoPMTBaseLogicalVolume;

  G4VPhysicalVolume *m_pVetoPMTWindowPhysicalVolume;
  G4VPhysicalVolume *m_pVetoPMTCasingPhysicalVolume;
  G4VPhysicalVolume *m_pVetoPMTInteriorPhysicalVolume;
  G4VPhysicalVolume *m_pVetoPMTPhotoCathodePhysicalVolume;
  G4VPhysicalVolume *m_pVetoPMTBasePhysicalVolume;

};

#endif
