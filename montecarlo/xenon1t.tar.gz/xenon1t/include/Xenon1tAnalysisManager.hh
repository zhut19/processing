#ifndef __XENON10PANALYSISMANAGER_H__
#define __XENON10PANALYSISMANAGER_H__

#include <globals.hh>

#include <TParameter.h>
#include <TDirectory.h>
#include <G4Timer.hh>
#include <G4ThreeVector.hh>

class G4Run;
class G4Event;
class G4Step;

class TFile;
class TTree;

class Xenon1tEventData;
class Xenon1tPrimaryGeneratorAction;
class Xenon1tAnalysisMessenger;

class Xenon1tAnalysisManager
{
public:
  Xenon1tAnalysisManager(Xenon1tPrimaryGeneratorAction *pPrimaryGeneratorAction);
  virtual ~Xenon1tAnalysisManager();

public:
  virtual void BeginOfRun(const G4Run *pRun); 
  virtual void EndOfRun(const G4Run *pRun); 
  virtual void BeginOfEvent(const G4Event *pEvent); 
  virtual void EndOfEvent(const G4Event *pEvent); 
  virtual void Step(const G4Step *pStep);	
  
  void SetDataFilename(const G4String &hFilename) { m_hDataFilename = hFilename; }
  void SetNbEventsToSimulate(G4int iNbEventsToSimulate) { m_iNbEventsToSimulate = iNbEventsToSimulate;}

  void FillParticleInSave(G4int flag, G4int partPDGcode, G4ThreeVector pos, G4ThreeVector dir, G4float nrg, G4float time, G4int trackID);


  void SetPMTHitsDetails(G4bool details) {m_pmtHitsDetails = details;}

  void SetOptPhotStepsInfos(G4bool infos) {m_optPhotStepsInfos = infos;}
  G4bool PrintOpticalPhotonsStepsInfos() {return m_optPhotStepsInfos;};

private:
  G4bool FilterEvent(Xenon1tEventData *pEventData);

private:

  Xenon1tAnalysisMessenger *m_pAnalysisMessenger;


  G4int m_iLXeHitsCollectionID;
  G4int m_iPmtHitsCollectionID;

  G4String m_hDataFilename;
  G4int m_iNbEventsToSimulate;

  TFile      *m_pTreeFile;
  TTree      *m_pTree;
  TDirectory *_events;

  TParameter<int> *m_pNbEventsToSimulateParameter;
  //  TParameter<double> *nRejectParameter;
  // TParameter<double> *nAcceptParameter;

  Xenon1tPrimaryGeneratorAction *m_pPrimaryGeneratorAction;

  Xenon1tEventData *m_pEventData;
  G4bool            plotPhysics;

  G4Timer *runTime;
  G4bool            writeEmptyEvents;


  G4bool m_pmtHitsDetails;
  G4bool m_optPhotStepsInfos;
  
};

#endif // __XENON10PANALYSISMANAGER_H__

