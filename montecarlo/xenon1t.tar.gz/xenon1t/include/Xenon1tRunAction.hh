#ifndef __XENON10PRUNACTION_H__
#define __XENON10PRUNACTION_H__

#include <G4UserRunAction.hh>
#include "Xenon1tRunActionMessenger.hh"

class G4Run;

class Xenon1tAnalysisManager;


class Xenon1tRunAction: public G4UserRunAction
{
public:
	Xenon1tRunAction(Xenon1tAnalysisManager *pAnalysisManager=0);
	~Xenon1tRunAction();

public:
	void BeginOfRunAction(const G4Run *pRun);
	void EndOfRunAction(const G4Run *pRun);
        
	void SetRanSeed(G4int hRanSeed) { m_hRanSeed = hRanSeed; }
//	void SetForcedTransport(G4bool doit) { m_hForcedTransport = doit; }

private:
	G4int m_hRanSeed;
//        G4bool m_hForcedTransport;
	Xenon1tAnalysisManager *m_pAnalysisManager;
	Xenon1tRunActionMessenger *m_pMessenger;
};

#endif // __XENON10PRUNACTION_H__

