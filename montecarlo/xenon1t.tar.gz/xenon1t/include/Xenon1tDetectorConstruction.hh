#ifndef __XENON10PDETECTORCONSTRUCTION_H__
#define __XENON10PDETECTORCONSTRUCTION_H__


#include <globals.hh>

#include <vector>
#include <map>
#include "TFile.h"
#include "TDirectory.h"

using std::vector;
using std::map;

class G4Sphere;
class G4Colour;
class G4LogicalVolume;
class G4VPhysicalVolume;
class Xenon1tDetectorMessenger;

// APC 25-07-2011: for the Klopperboden implementation
#include <G4UnionSolid.hh>
#include <G4SubtractionSolid.hh>

#include <G4UImanager.hh>

#include "Xenon1tPmtSensitiveDetector.hh"
#include "Xenon1tNeutronGenerator.hh"
#include <G4VUserDetectorConstruction.hh>

class Xenon1tDetectorConstruction: public G4VUserDetectorConstruction
{
public:
	Xenon1tDetectorConstruction(G4String fName);
	~Xenon1tDetectorConstruction();

	G4VPhysicalVolume* Construct();

	void SetTeflonReflectivity(G4double dReflectivity);
	void SetLXeScintillation(G4bool dScintillation);
	void SetLXeAbsorbtionLength(G4double dAbsorbtionLength);
	void SetLXeRayScatterLength(G4double dRayScatterLength);
  void SetGridMeshTransparency(G4double dTransparency); // Cyril, December 2013

  void SetTopScreeningMeshTransparency(G4double dTransparency); // Cyril, June 2014
  void SetBottomScreeningMeshTransparency(G4double dTransparency);// Cyril, June 2014
  void SetAnodeMeshTransparency(G4double dTransparency);// Cyril, June 2014
  void SetCathodeMeshTransparency(G4double dTransparency);// Cyril, June 2014
  void SetGateMeshTransparency(G4double dTransparency);// Cyril, June 2014


	 // APC 25-07-2011
  // for communication with the Xenon1tDetectorMessenger
  void SetCryostatType(G4String dCryostatType)           {pCryostatType     = dCryostatType;};
  void SetCryostatMaterial(G4String dCryostatMaterial)   {pCryostatMaterial = dCryostatMaterial;};
  void SetNeutronSourceSurroundings(G4String dNeutronSourceSurroundings)
  { pNeutronSourceSurroundings = dNeutronSourceSurroundings;};
  void SetOuterWallThickness(G4double dCryostatOuterWall){pCryostatOuterWallThickness = dCryostatOuterWall;};
  void SetInnerOD(G4double dInnerOD){OD_Inner_Requested = dInnerOD;};
  void SetOuterOD(G4double dOuterOD){OD_Outer_Requested = dOuterOD;};
  void SetInnerWallThickness(G4double dCryostatInnerWall){pCryostatInnerWallThickness = dCryostatInnerWall;};
  void SetCheckOverlap(G4bool dCheckOverlap)             {pCheckOverlap = dCheckOverlap;};
  void SetTPC(G4bool dTPC)                               {pTPC          = dTPC;};
    void SetMuonVetoMaterial(G4String dMuonVetoMaterial) {pMuonVetoMaterial = dMuonVetoMaterial;};
    void SetFillBuffer(G4bool dFillBuffer) {pFillBuffer = dFillBuffer;};
    void SetTpcWithBell(G4bool dTpcWithBell) {pTpcWithBell = dTpcWithBell;};
    void SetBufferThickness(G4double dBufferThickness) {pBufferThickness = dBufferThickness;};
  void SetLXeVeto(G4bool dLXeVeto) {pLXeVeto = dLXeVeto;};
   //  till here



	static G4double GetGeometryParameter(const char *szParameter);


private:
	void DefineMaterials();
	void DefineGeometryParameters();

	void ConstructLaboratory();
	void ConstructVeto();
	
        void ConstructNewSupportStructure();            //ANDREA
	void ConstructHexapod();			// SERENA
	void ConstructCablesPipe();			// SERENA
	void ConstructLeadBrick();
        void ConstructNeutronGenerator();
	//void ConstructCryostat();
	//void ConstructNikhefCryostat();
        void ConstructColumbiaCryostat();

	void ConstructXenon();

  void ConstructTopTPC();                          //Fabio Valerio
  void ConstructTPC();                             //Fabio Valerio

        void ConstructGrids();                          // RINO
        
  void ConstructHVFT();                                // Fabio Valerio
  G4UnionSolid* ConstructPillar();                                // Fabio Valerio

	void ConstructVetoPMTArrays();
  void ConstructLXeVetoPMTArrays();              // Cyril

  void ConstructPipe();

	void CheckOverlapping();
	void SecondOverlapCheck();
	void PrintGeometryInformation();

	typedef enum {PMT_WINDOW, PMT_BODY, PMT_BASE} PMTPart;

  	G4ThreeVector GetPMTsPositionTopArray(G4int);    // RINO
  	G4ThreeVector GetPMTsPositionBottomArray(G4int); // RINO

	G4ThreeVector GetPMTPosition(G4int iPMTNb, PMTPart ePMTPart);
	G4ThreeVector GetQUPIDPositionTopArray(G4int iPMTNb, PMTPart ePMTPart);
	G4ThreeVector GetQUPIDPositionBottomArray(G4int iPMTNb, PMTPart ePMTPart);
	G4ThreeVector GetPMTPositionLSArray(G4int iPMTNb, PMTPart ePMTPart);
	G4ThreeVector GetPMTPositionWaterArray(G4int iPMTNb, PMTPart ePMTPart);
	G4RotationMatrix *GetPMTRotation(G4int iPMTNb);

  void MakeDetectorPlots();
  void MakeCryostatPlots();
  void MakeXenonPlots();
	

//   G4Sphere* ConstructVesselMod(G4double D, G4double L, G4double R0top, 
// 			       G4double R1top, G4double R0bot, G4double R1bot,
// 			       G4double TopCor, G4double BotCor,
// 			       G4double dR_Flange, G4double h_Flange, 
// 			       G4double z_Flange, G4bool doBottom,
// 			       G4bool gxe_Flag);



  // APC 25-07-2011
  // basic function for creating teh 'special' bottom of the vessel
  //typedef enum {INSIDE, OUTSIDE} VesselSide;
  //G4UnionSolid* ConstructVessel(VesselSide iside, G4double D, G4double L, G4double dWall, 
  //                              G4double dR_Flange, G4double h_Flange, G4double z_Flange);
  
  G4UnionSolid* ConstructVessel(G4double D, G4double L, G4double R0top, G4double R1top, 
				G4double R0bot, G4double R1bot, G4double TopCor, 
				G4double BotCor, G4double dR_Flange, G4double h_Flange, 
				G4double z_Flange, G4bool doBottom);
	
G4UnionSolid* ConstructBeam(G4double x_outer, G4double y_outer, G4double z_outer, G4double x_inner, G4double y_inner, G4double z_inner);
private:
	// rotation matrices

	// LOGICAL VOLUMES
	G4LogicalVolume *m_pMotherLogicalVolume;

	G4LogicalVolume *m_pLabLogicalVolume;

	//G4LogicalVolume *m_pWaterTankLogicalVolume;	// SERENAs COMMENT
	G4LogicalVolume *m_pWaterTankTubLogicalVolume;	// SERENA
	G4LogicalVolume *m_pTankConsLogicalVolume;	// SERENA
	G4LogicalVolume *m_pAirConsLogicalVolume; // SERENA
	G4LogicalVolume *m_pWaterTankDomeLogicalVolume; // SERENA
	G4LogicalVolume *m_pWaterDomeLogicalVolume; // SERENA

	G4LogicalVolume *m_pWaterLogicalVolume;
	G4LogicalVolume *m_pWaterConsLogicalVolume;		// SERENA


	//G4LogicalVolume *m_pLSVesselLogicalVolume;
	//G4LogicalVolume *m_pLSLogicalVolume;

	G4LogicalVolume *logicOuterPoly;
	G4LogicalVolume *logicOuterLead;
	G4LogicalVolume *logicInnerPoly;
	G4LogicalVolume *logicAirCorners;
	G4LogicalVolume *logicInnerLead;
	G4LogicalVolume *logicInnerAir;
	
	G4LogicalVolume *m_pHexapodPlatformLogicalVolume; // SERENA
	G4LogicalVolume *m_pHexapodLegLogicalVolume; // SERENA

        //ANDREA
        G4LogicalVolume *m_pLegFloor1LogicalVolume;
        G4LogicalVolume *m_pLegMedium1LogicalVolume;
        G4LogicalVolume *m_pLegMedium2LogicalVolume;
        G4LogicalVolume *m_pLegMedium3LogicalVolume;
        G4LogicalVolume *m_pLegMedium4LogicalVolume;
        G4LogicalVolume *m_pLegHorizontal1LogicalVolume;
	G4LogicalVolume *m_pLegTiltedCons1LogicalVolume;
        G4LogicalVolume *m_pLegTiltedCons2LogicalVolume;
        G4LogicalVolume *m_pLegTiltedCons3LogicalVolume;
        G4LogicalVolume *m_pLegTiltedCons4LogicalVolume;
	G4LogicalVolume *m_pLegTopLogicalVolume1;
        G4LogicalVolume *m_pLegTopLogicalVolume2;
        G4LogicalVolume *m_pLegTopLogicalVolume3;
        G4LogicalVolume *m_pLegTopLogicalVolume4;
        G4LogicalVolume *m_pLegConnection1LogicalVolume;
        G4LogicalVolume *m_pLegTiltedLogicalVolume;

        G4LogicalVolume *m_pLegFloorAir1LogicalVolume;
        G4LogicalVolume *m_pLegMediumAir1LogicalVolume;
        G4LogicalVolume *m_pLegHorizontalAir1LogicalVolume;
        G4LogicalVolume *m_pLegTiltedConsAir1LogicalVolume;
        G4LogicalVolume *m_pLegTopAirLogicalVolume1;
        G4LogicalVolume *m_pLegTopAirLogicalVolume2;
        G4LogicalVolume *m_pLegTopAirLogicalVolume3;
        G4LogicalVolume *m_pLegTopAirLogicalVolume4;
        G4LogicalVolume *m_pLegConnectionAir1LogicalVolume;
        G4LogicalVolume *m_pLegTiltedAirLogicalVolume;
        G4LogicalVolume *m_pLegPlatformLogicalVolume;
        G4LogicalVolume *m_pLegPlatformAirLogicalVolume;
	G4LogicalVolume *m_pBraceRodLogicalVolume;
        G4LogicalVolume *m_pBraceRodMediumLogicalVolume;
    
    G4LogicalVolume *m_pTieRodLogicalVolume;
    G4LogicalVolume *m_pTie2RodLogicalVolume;
    G4LogicalVolume *m_pTieConsRodLogicalVolume;
    G4LogicalVolume *m_pLegSpreaderLogicalVolume;
    G4LogicalVolume *m_pLegSpreaderAirLogicalVolume;
    
    G4LogicalVolume *m_pLegSpreaderPlatLogicalVolume;


//Pipes

    
    
       G4LogicalVolume *m_pPipeCylinderSmallSSLogicalVolume;

       G4LogicalVolume *m_pPipeCylinderSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume_1;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume_2;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume_3;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume_4;
       G4LogicalVolume *m_pPipeCylinderInternalSSLogicalVolume_5;
       G4LogicalVolume *m_pPipeCylinderSmallStainSSLogicalVolume;
    
    G4LogicalVolume *m_pPipeCylinderLowSSLogicalVolume;
    G4LogicalVolume *m_pPipeCylinderLowAirLogicalVolume;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume_1;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume_2;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume_3;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume_4;
    G4LogicalVolume *m_pPipeCylinderInternalLowSSLogicalVolume_5;
    

       G4LogicalVolume *m_pPipeCylinderAirLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderAirSmallLogicalVolume;

       G4LogicalVolume *m_pPipeCylinderAirLogicalVolume_1;
       G4LogicalVolume *m_pPipeCylinderAirLogicalVolume_2;
       G4LogicalVolume *m_pPipeTorusSSLogicalVolume;
       G4LogicalVolume *m_pPipeTorusSmallSSLogicalVolume;
       G4LogicalVolume *m_pPipeTorusAirLogicalVolume;
       G4LogicalVolume *m_pPipeTorusAirSmallLogicalVolume;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume_1;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume_2;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume_3;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume_4;
       G4LogicalVolume *m_pPipeTorusInternalSSLogicalVolume_5;
    
       G4LogicalVolume *m_pPipeCylinderTiltedSSLogicalVolume;
       G4LogicalVolume *m_pPipeTorusAirInternalLogicalVolume;
       G4LogicalVolume *m_pPipeTorusAirLogicalVolume_1;
       G4LogicalVolume *m_pPipeTorusAirLogicalVolume_2;
       G4LogicalVolume *m_pPipeCylinderTiltedInternalSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderTiltedInternalSSLogicalVolume_1;
       G4LogicalVolume *m_pPipeCylinderTiltedInternalSSLogicalVolume_2;
       G4LogicalVolume *m_pPipeCylinderTiltedAirLogicalVolume;
    
       G4LogicalVolume *m_pPipeCylinderTiltedLongSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderTiltedLongSmallSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume_1;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume_2;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume_3;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume_4;
       G4LogicalVolume *m_pPipeCylinderTiltedLongInternalSSLogicalVolume_5;
       G4LogicalVolume *m_pPipeCylinderTiltedLongAirLogicalVolume;
       G4LogicalVolume *m_pPipeCylinderTiltedLongAirSmallLogicalVolume;
    G4LogicalVolume *m_pPipeTolonLogicalVolume;

       G4LogicalVolume *m_pPipeCylinderTiltedLong2AirLogicalVolume;
       G4LogicalVolume *m_pPipeBaseLogicalVolume;
       G4LogicalVolume *m_pPipeBaseSmallLogicalVolume;

       G4LogicalVolume *m_pPipeBaseInternalLogicalVolume;
       G4LogicalVolume *m_pPipeBaseInternal1LogicalVolume;
       G4LogicalVolume *m_pPipeBaseInternal2LogicalVolume;
       G4LogicalVolume *m_pPipeBaseInternal3LogicalVolume;
       G4LogicalVolume *m_pPipeBaseInternal4LogicalVolume;
       G4LogicalVolume *m_pPipeBaseInternal5LogicalVolume;

       G4LogicalVolume *m_pPipeBaseHalfLogicalVolume;
    
       G4LogicalVolume *m_pPipeBaseHalfInternalLogicalVolume;


	
	
	G4LogicalVolume *m_pCablesPipeBaseLogicalVolume;	// SERENA
	G4LogicalVolume *m_pCablesPipeLogicalVolume;		// SERENA
	G4LogicalVolume *m_pCablesPipeAirLogicalVolume;		// SERENA
    
    G4LogicalVolume *m_pLeadBrickLogicalVolume;
    G4LogicalVolume *m_pGeneratorContainerLogicalVolume;
    G4LogicalVolume *m_pGeneratorCavityLogicalVolume;

	G4LogicalVolume *m_pOuterCryostatLogicalVolume;
	G4LogicalVolume *m_pOuterCryostatVacuumLogicalVolume;
	G4LogicalVolume *m_pInnerCryostatLogicalVolume;
	G4LogicalVolume *m_pFlangeLogicalVolume;
	G4LogicalVolume *m_pFlangePart1LogicalVolume;
	G4LogicalVolume *m_pFlangePart2LogicalVolume;
	G4LogicalVolume *m_pFlangePart3LogicalVolume;
	G4LogicalVolume *m_pFlangePart4LogicalVolume;

	G4LogicalVolume *m_pLXeLogicalVolume;            //RINO
	G4LogicalVolume *m_pLXeVacuumLogicalVolume;      //RINO
	G4LogicalVolume *m_pGXeLogicalVolume;            //RINO
        G4LogicalVolume *m_pLXeTopLogicalVolume;         //Cyril
  G4LogicalVolume *m_pLateralBellLogicalVolume; //MarcoS
        G4LogicalVolume *m_pLXeAroundBellLogicalVolume;         //MarcoS

    
    G4LogicalVolume *m_pLateralPolyFillerLogicalVolume;   //MarcoS
    G4LogicalVolume *m_pLateralUpperFillerLogicalVolume;   //MarcoS
    G4LogicalVolume *m_pTopFillerLogicalVolume;   //MarcoS
    G4LogicalVolume *m_pBottomPolyFillerLogicalVolume;   //MarcoS
    
 	G4LogicalVolume *m_pPmtR11410LogicalVolume;      //RINO
 	G4LogicalVolume *m_pPmtR8520LogicalVolume;      //Cyril



        G4LogicalVolume *m_pBellLogicalVolume;           //RINO
  G4LogicalVolume *m_pBellRingAroundHVFTTubsLogicalVolume;           //Fabio Valerio
	G4LogicalVolume *m_pBellGXeLogicalVolume;        //RINO
    	G4LogicalVolume *m_pTopHolderLogicalVolume;      //RINO
    	G4LogicalVolume *m_pPmtBasesLogicalVolume;       //RINO
    	G4LogicalVolume *m_pTopTeflonLogicalVolume;      //RINO
  
  
	G4LogicalVolume *m_pUpperPlateLogicalVolume;     //RINO
  G4LogicalVolume *m_pUpperPlate_1LogicalVolume;   
  G4LogicalVolume *m_pTpcLogicalVolume;            //RINO
  	G4LogicalVolume *m_pLowerPlateLogicalVolume;     //RINO
  G4LogicalVolume *m_pLowerPlate_1LogicalVolume;
  	G4LogicalVolume *m_pBelowTpcRingLogicalVolume;      //Fabio Valerio
    	G4LogicalVolume *m_pFieldShaperRingLogicalVolume;//RINO
   
  G4LogicalVolume *m_pTopPlateLogicalVolume;              //Fabio Valerio  
  G4LogicalVolume *m_pTopPMTsHolderLogicalVolume;         //Fabio Valerio  
  G4LogicalVolume *m_pTopPMTCopperLogicalVolume;            //Fabio Valerio 
  G4LogicalVolume *m_pTopPTFELogicalVolume;               //Fabio Valerio
  G4LogicalVolume *m_pSSPlateLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pSSRing_LXeLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pGateElectrodeRingLogicalVolume;     //Fabio Valerio
  G4LogicalVolume *m_pBotElectrodePTFELogicalVolume;      //Fabio Valerio
  //G4LogicalVolume *m_pTopPTFERingLogicalVolume;           //Fabio Valerio
  //G4LogicalVolume *m_pTopPTFERing_LXeLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pTopPTFEinnerRing_GXeLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pTopPTFEinnerRing_LXeLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pTopElectrodePTFELogicalVolume;      //Fabio Valerio
  G4LogicalVolume *m_pTopElectrodePTFELXeLogicalVolume;      //Fabio Valerio
  G4LogicalVolume *m_pTopMeshRingLogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pAnodeRing_1LogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pAnodeRing_2LogicalVolume;           //Fabio Valerio
  
  G4LogicalVolume *m_pBottomPTFELogicalVolume;            //Fabio Valerio
  G4LogicalVolume *m_pBottomHolderLogicalVolume;          //Fabio Valerio   
  G4LogicalVolume *m_pBottomReflectorLogicalVolume;         //Fabio Valerio
  G4LogicalVolume *m_pOuterTpcRingLogicalVolume;          //Fabio Valerio
  G4LogicalVolume *m_pPTFEpillarLogicalVolume;          //Fabio Valerio
  G4LogicalVolume *m_pCopperRingBelowPillarsLogicalVolume; //Fabio Valerio
  G4LogicalVolume *m_pCathodeSupportLogicalVolume;          //Fabio Valerio
  G4LogicalVolume *m_pBottomFillerLogicalVolume;        //Fabio Valerio
  G4LogicalVolume *m_pVacuumBottomFillerLogicalVolume;        //Fabio Valerio
  G4LogicalVolume *m_pBottomFillerCoverLogicalVolume;     //Marco selvi
  
  G4LogicalVolume *m_pPTFELayerCryoLogicalVolume; // Cyril
  G4LogicalVolume *m_pPTFEInWallLogicalVolume; // Cyril
  G4LogicalVolume *m_pPTFEAboveTPC1LogicalVolume; // Cyril
  G4LogicalVolume *m_pPTFEAboveTPC2LogicalVolume; // Cyril
  G4LogicalVolume *m_pPTFEBelowTPC1LogicalVolume; // Cyril
  G4LogicalVolume *m_pPTFEBelowTPC2LogicalVolume; // Cyril

        G4LogicalVolume *m_pTopGridMeshLogicalVolume;    //RINO
    	G4LogicalVolume *m_pAnodeMeshLogicalVolume;      //RINO
      	G4LogicalVolume *m_pGroundMeshLogicalVolume;     //RINO
   	G4LogicalVolume *m_pCathodeMeshLogicalVolume;    //RINO
	G4LogicalVolume *m_pBottomGridMeshLogicalVolume; //RINO
  
  //____________________________________________________________________//
  G4LogicalVolume *m_pTopGridMesh_RingLogicalVolume;    //Fabio Valerio
  G4LogicalVolume *m_pAnodeMesh_RingLogicalVolume;      //Fabio Valerio
  G4LogicalVolume *m_pGroundMesh_RingLogicalVolume;     //Fabio Valerio
  G4LogicalVolume *m_pCathodeMesh_RingLogicalVolume;    //Fabio Valerio
  G4LogicalVolume *m_pCathode_Ring_2LogicalVolume;    //Fabio Valerio
  G4LogicalVolume *m_pBottomGridMesh_RingLogicalVolume; //Fabio Valerio
  
  //____________________________________________________________________//

	G4LogicalVolume *m_pSidePTFELogicalVolume;
	G4LogicalVolume *m_pTopCopperPlateLogicalVolume;
	G4LogicalVolume *m_pBottomCopperPlateLogicalVolume;

	G4LogicalVolume *m_pSideAcrylicLogicalVolume;

	G4LogicalVolume *m_pQUPIDWindowLogicalVolume;
	G4LogicalVolume *m_pQUPIDPhotocathodeLogicalVolume;
	G4LogicalVolume *m_pQUPIDPhotocathodeInteriorLogicalVolume;
	G4LogicalVolume *m_pQUPIDBodyLogicalVolume;
	G4LogicalVolume *m_pQUPIDBodyAluminiumCoatingLogicalVolume;
	G4LogicalVolume *m_pQUPIDBodyInteriorLogicalVolume;
	G4LogicalVolume *m_pQUPIDAPDLogicalVolume;
	G4LogicalVolume *m_pQUPIDBaseLogicalVolume;
	G4LogicalVolume *m_pQUPIDBaseAluminiumCoatingLogicalVolume;

	G4LogicalVolume *m_pPMTWindowLogicalVolume;
	G4LogicalVolume *m_pPMTPhotocathodeLogicalVolume;
	G4LogicalVolume *m_pPMTPhotocathodeInterior1LogicalVolume;
  G4LogicalVolume *m_pPMTPhotocathodeInterior2LogicalVolume;
	G4LogicalVolume *m_pPMTBodyLogicalVolume;
	G4LogicalVolume *m_pPMTBodyInteriorLogicalVolume;
	G4LogicalVolume *m_pPMTBaseLogicalVolume;
        G4LogicalVolume *m_pPMTBaseInteriorLogicalVolume;

  G4LogicalVolume *m_pVetoPMTBaseLogicalVolume; // Cyril



 
  //_______________ HVFT logical volumes ______________________________________//
  G4LogicalVolume *m_pOuterSS_GXeHVFT_LogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pInnerPoly_GXeHVFT_LogicalVolume;         //Fabio Valerio
  G4LogicalVolume *m_pInnerAir_GXeHVFT_LogicalVolume;          //Fabio Valerio
  G4LogicalVolume *m_pInnerSS_GXeHVFT_LogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pInnerInAir_GXeHVFT_LogicalVolume;        //Fabio Valerio
  
  G4LogicalVolume *m_pOuterSS_HVFT_LogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pInnerPoly_HVFT_LogicalVolume;         //Fabio Valerio
  G4LogicalVolume *m_pInnerAir_HVFT_LogicalVolume;          //Fabio Valerio
  G4LogicalVolume *m_pInnerSS_HVFT_LogicalVolume;           //Fabio Valerio
  G4LogicalVolume *m_pInnerInAir_HVFT_LogicalVolume;        //Fabio Valerio
  
  G4LogicalVolume *m_pBottom_Poly_HVFT_LogicalVolume;       //Fabio Valerio
  G4LogicalVolume *m_pBottom_InnerAir_HVFT_LogicalVolume;   //Fabio Valerio
  G4LogicalVolume *m_pBottom_InnerSS_HVFT_LogicalVolume;    //Fabio Valerio
  G4LogicalVolume *m_pBottom_InnerInAir_HVFT_LogicalVolume; //Fabio Valerio
  
  G4LogicalVolume *m_plast_bottom_SS_HVFT_LogicalVolume;    //Fabio Valerio
  G4LogicalVolume *m_plast_bottom_Air_HVFT_LogicalVolume;   //Fabio Valerio
  //___________________________________________________________________________//
  
	// PHYSICAL VOLUMES
	G4VPhysicalVolume *m_pLabPhysicalVolume;

	//G4VPhysicalVolume *m_pWaterTankPhysicalVolume;	// SERENAs COMMENT
	G4VPhysicalVolume *m_pWaterTankTubePhysicalVolume;	// SERENA
	G4VPhysicalVolume *m_pTankConsPhysicalVolume;	// SERENA
	

	G4VPhysicalVolume *m_pWaterPhysicalVolume;
	G4VPhysicalVolume *m_pWaterConsPhysicalVolume;		// SERENA
	G4VPhysicalVolume *m_pAirConsPhysicalVolume; // SERENA
	G4VPhysicalVolume *m_pWaterTankDomePhysicalVolume; // SERENA
	G4VPhysicalVolume *m_pWaterDomePhysicalVolume; //SERENA
	
	G4VPhysicalVolume *m_pLSVesselPhysicalVolume;
	G4VPhysicalVolume *m_pLSPhysicalVolume;

	G4VPhysicalVolume *physiOuterPoly;
	G4VPhysicalVolume *physiOuterLead;
	G4VPhysicalVolume *physiInnerPoly;
	G4VPhysicalVolume *physiAirCorners;
	G4VPhysicalVolume *physiInnerLead;
	G4VPhysicalVolume *physiInnerAir;

	// HEXAPOD
	G4VPhysicalVolume *m_pHexapodPlatformPhysicalVolume; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_1; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_2; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_3; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_4; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_5; // SERENA
	G4VPhysicalVolume *m_pHexapodLegPhysicalVolume_6; // SERENA
 
        //ANDREA
        G4VPhysicalVolume *m_pLegFloor1PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloor2PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloor3PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloor4PhysicalVolume;
        G4VPhysicalVolume *m_pLegMedium1PhysicalVolume;
        G4VPhysicalVolume *m_pLegMedium2PhysicalVolume;
        G4VPhysicalVolume *m_pLegMedium3PhysicalVolume;
        G4VPhysicalVolume *m_pLegMedium4PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal1PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal2PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal3PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal4PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal5PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal6PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal7PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontal8PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedCons1PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedCons2PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedCons3PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedCons4PhysicalVolume;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume1;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume2;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume3;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume4;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume5;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume6;
        G4VPhysicalVolume *m_pLegTopPhysicalVolume7;
        G4VPhysicalVolume *m_pLegConnection1PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnection2PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnection3PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnection4PhysicalVolume;
        G4VPhysicalVolume *m_pLegTilted1PhysicalVolume;
        G4VPhysicalVolume *m_pLegTilted2PhysicalVolume;
        G4VPhysicalVolume *m_pLegTilted3PhysicalVolume;
        G4VPhysicalVolume *m_pLegTilted4PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalPlatformPhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalPlatform1PhysicalVolume;
        G4VPhysicalVolume *m_pLegPlatformSmallPhysicalVolume;
        G4VPhysicalVolume *m_pLegPlatformSmall1PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow1PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow2PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow3PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow4PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow5PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow6PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow7PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodLow8PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium1PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium2PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium3PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium4PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium5PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium6PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium7PhysicalVolume;
        G4VPhysicalVolume *m_pBraceRodMedium8PhysicalVolume;


        G4VPhysicalVolume *m_pLegFloorAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloorAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloorAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegFloorAir4PhysicalVolume;
        G4VPhysicalVolume *m_pLegMediumAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegMediumAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegMediumAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegMediumAir4PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir4PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir5PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir6PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir7PhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalAir8PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedConsAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedConsAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedConsAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedConsAir4PhysicalVolume;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume1;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume2;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume3;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume4;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume5;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume6;
        G4VPhysicalVolume *m_pLegTopAirPhysicalVolume7;
        G4VPhysicalVolume *m_pLegConnectionAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnectionAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnectionAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegConnectionAir4PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedAir2PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedAir3PhysicalVolume;
        G4VPhysicalVolume *m_pLegTiltedAir4PhysicalVolume;
        
        G4VPhysicalVolume *m_pLegHorizontalPlatformAirPhysicalVolume;
        G4VPhysicalVolume *m_pLegHorizontalPlatformAir1PhysicalVolume;
        G4VPhysicalVolume *m_pLegPlatformSmallAirPhysicalVolume;
        G4VPhysicalVolume *m_pLegPlatformSmallAir1PhysicalVolume;
    
    G4VPhysicalVolume * m_pLegSpreader1PhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreader2PhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreader3PhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreaderPlat1PhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreaderPlat2PhysicalVolume;
    
    G4VPhysicalVolume * m_pTieRod1PhysicalVolume;
    G4VPhysicalVolume * m_pTieRod2PhysicalVolume;
    G4VPhysicalVolume * m_pTieRod3PhysicalVolume;
    G4VPhysicalVolume * m_pTieRodCons1PhysicalVolume;
    G4VPhysicalVolume * m_pTieRodCons2PhysicalVolume;
    G4VPhysicalVolume * m_pTieRodCons3PhysicalVolume;
    
    G4VPhysicalVolume * m_pTie2Rod1PhysicalVolume;
    G4VPhysicalVolume * m_pTie2Rod2PhysicalVolume;
    G4VPhysicalVolume * m_pTie2Rod3PhysicalVolume;
    
    G4VPhysicalVolume * m_pLegSpreader1AirPhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreader2AirPhysicalVolume;
    G4VPhysicalVolume * m_pLegSpreader3AirPhysicalVolume;



	// CABLES PIPE
	G4VPhysicalVolume *m_pCablesPipeBasePhysicalVolume; // SERENA
	G4VPhysicalVolume *m_pCablesPipePhysicalVolume; // SERENA
	G4VPhysicalVolume *m_pCablesPipeAirPhysicalVolume;// SERENA

	G4VPhysicalVolume *m_pOuterCryostatPhysicalVolume;
	G4VPhysicalVolume *m_pOuterCryostatVacuumPhysicalVolume;
	G4VPhysicalVolume *m_pInnerCryostatPhysicalVolume;
	G4VPhysicalVolume *m_pFlangePhysicalVolume;
	G4VPhysicalVolume *m_pFlangePart1PhysicalVolume;
	G4VPhysicalVolume *m_pFlangePart2PhysicalVolume;
	G4VPhysicalVolume *m_pFlangePart3PhysicalVolume;
	G4VPhysicalVolume *m_pFlangePart4PhysicalVolume;

G4VPhysicalVolume *m_pPipeCylinderSSPhysicalVolume;
G4VPhysicalVolume *m_pPipeCylinderSmallSSPhysicalVolume;

       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume_1;
       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume_2;
       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume_3;
       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume_4;
       G4VPhysicalVolume *m_pPipeCylinderInternalSSPhysicalVolume_5;
      
       G4VPhysicalVolume *m_pPipeCylinderAirPhysicalVolume;
    G4VPhysicalVolume *m_pPipeCylinderAirSmallPhysicalVolume;
    
    G4VPhysicalVolume *m_pPipeCylinderLowSSPhysicalVolume;
    
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume;
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume_1;
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume_2;
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume_3;
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume_4;
    G4VPhysicalVolume *m_pPipeCylinderInternalLowSSPhysicalVolume_5;
    
    G4VPhysicalVolume *m_pPipeCylinderLowAirPhysicalVolume;

    
    
       G4VPhysicalVolume *m_pPipeTorusSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusSmallSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume_1;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume_2;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume_3;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume_4;
       G4VPhysicalVolume *m_pPipeTorusInternalSSPhysicalVolume_5;
       G4VPhysicalVolume *m_pPipeTolonPhysicalVolume1;
       G4VPhysicalVolume *m_pPipeTolonPhysicalVolume2;
       G4VPhysicalVolume *m_pPipeTolonPhysicalVolume3;
       G4VPhysicalVolume *m_pPipeTolonPhysicalVolume4;
       G4VPhysicalVolume *m_pPipeTolonPhysicalVolume5;
 
       G4VPhysicalVolume *m_pPipeTorusAirPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusAirSmallPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusAirPhysicalVolume_1;
       G4VPhysicalVolume *m_pPipeTorusAirPhysicalVolume_2;
       G4VPhysicalVolume *m_pPipeCylinderTiltedSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeTorusAirInternalPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedInternalSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedInternalSSPhysicalVolume_1;
       G4VPhysicalVolume *m_pPipeCylinderTiltedInternalSSPhysicalVolume_2;
       G4VPhysicalVolume *m_pPipeCylinderTiltedAirPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongSSPhysicalVolume;
    G4VPhysicalVolume *m_pPipeCylinderTiltedLongSmallSSPhysicalVolume;

       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_1;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_2;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_3;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_4;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongInternalSSPhysicalVolume_5;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongAirPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLongAirSmallPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderTiltedLong2AirPhysicalVolume;
       G4VPhysicalVolume *m_pPipeCylinderSmallStainSSPhysicalVolume1;
       G4VPhysicalVolume *m_pPipeCylinderSmallStainSSPhysicalVolume2;
       G4VPhysicalVolume *m_pPipeCylinderSmallStainSSPhysicalVolume3;
    
       
       G4VPhysicalVolume *m_pPipeBaseLowPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseSmallLowPhysicalVolume;

       G4VPhysicalVolume *m_pPipeBaseLowInternal1PhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseLowInternal2PhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseLowInternal3PhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseLowInternal4PhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseLowInternal5PhysicalVolume;



       G4VPhysicalVolume *m_pPipeBaseLowInternalPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseTorusLowPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseHighPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseTorusLowInternalPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseHighInternalPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseTorusHighPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseTorusHighInternalPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseHalfPhysicalVolume;
       G4VPhysicalVolume *m_pPipeBaseHalfInternalPhysicalVolume;

    
    G4VPhysicalVolume *m_pLeadBrickPhysicalVolume;
    G4VPhysicalVolume *m_pGeneratorContainerPhysicalVolume;
    G4VPhysicalVolume *m_pGeneratorCavityPhysicalVolume;

	G4VPhysicalVolume *m_pLXePhysicalVolume;             //RINO
	G4VPhysicalVolume *m_pLXeVacuumPhysicalVolume;       //RINO
	G4VPhysicalVolume *m_pGXePhysicalVolume;             //RINO
       
    	G4VPhysicalVolume *m_pLXeTopPhysicalVolume;          //Cyril
    	G4VPhysicalVolume *m_pLateralBellPhysicalVolume;          //MarcoS
    	G4VPhysicalVolume *m_pLXeAroundBellPhysicalVolume;          //MarcoS

    G4VPhysicalVolume *m_pLateralPolyFillerPhysicalVolume; // MarcoS
    G4VPhysicalVolume *m_pLateralUpperFillerPhysicalVolume; // MarcoS
    G4VPhysicalVolume *m_pTopFillerPhysicalVolume; // MarcoS
    G4VPhysicalVolume *m_pBottomPolyFillerPhysicalVolume; // MarcoS
    
        vector<G4VPhysicalVolume*> m_pPMTPhysicalVolumes;    //RINO

        G4VPhysicalVolume *m_pBellPhysicalVolume;            //RINO
  G4VPhysicalVolume *m_pBellRingAroundHVFTTubsPhysicalVolume;            //Fabio Valerio
	G4VPhysicalVolume *m_pBellGXePhysicalVolume;         //RINO
	G4VPhysicalVolume *m_pTopHolderPhysicalVolume;       //RINO
        vector<G4VPhysicalVolume*> m_pPmtBasesPhysicalVolumes; //RINO
	G4VPhysicalVolume *m_pTopTeflonPhysicalVolume;      //RINO
  G4VPhysicalVolume *m_pBottomTeflonPmtPhysicalVolume;         //Fabio Valerio
  
	G4VPhysicalVolume *m_pUpperPlatePhysicalVolume;      //RINO
  G4VPhysicalVolume *m_pUpperPlate_1PhysicalVolume;  
  G4VPhysicalVolume *m_pTpcPhysicalVolume;             //RINO
	G4VPhysicalVolume *m_pLowerPlatePhysicalVolume; //RINO
  G4VPhysicalVolume *m_pLowerPlate_1PhysicalVolume; 
	G4VPhysicalVolume *m_pBelowTpcRingPhysicalVolume;       //Fabio Valerio
  vector<G4VPhysicalVolume*> m_pFieldShaperRingPhysicalVolumes; //RINO


  
  G4VPhysicalVolume *m_pTopPlatePhysicalVolume;            //Fabio Valerio
  G4VPhysicalVolume *m_pTopPMTsHolderPhysicalVolume;       //Fabio Valerio
  G4VPhysicalVolume *m_pTopPMTCopperPhysicalVolume;          //Fabio Valerio
  G4VPhysicalVolume *m_pTopPTFEPhysicalVolume;             //Fabio Valerio
  G4VPhysicalVolume *m_pSSPlatePhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pSSRing_LXePhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pGateElectrodeRingPhysicalVolume;   //Fabio Valerio
  //G4VPhysicalVolume *m_pTopPTFERingPhysicalVolume;         //Fabio Valerio
  //G4VPhysicalVolume *m_pTopPTFERing_LXePhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pTopPTFEinnerRing_GXePhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pTopPTFEinnerRing_LXePhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pTopElectrodePTFEPhysicalVolume;    //Fabio Valerio
  G4VPhysicalVolume *m_pTopElectrodePTFELXePhysicalVolume;    //Fabio Valerio
  G4VPhysicalVolume *m_pTopMeshRingPhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pAnodeRing_1PhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pAnodeRing_2PhysicalVolume;         //Fabio Valerio
  
  G4VPhysicalVolume *m_pBottomPTFEPhysicalVolume;          //Fabio Valerio
  G4VPhysicalVolume *m_pBottomHolderPhysicalVolume;        //Fabio Valerio
  G4VPhysicalVolume *m_pBottomReflectorPhysicalVolume;       //Fabio Valerio
  G4VPhysicalVolume *m_pOuterTpcRingPhysicalVolume;        //Fabio Valerio
  vector<G4VPhysicalVolume*> m_pPTFEpillarPhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pCopperRingBelowPillarsPhysicalVolume;  //Fabio Valerio
  vector<G4VPhysicalVolume*> m_pCathodeSupportPhysicalVolume; //Fabio Valerio
  G4VPhysicalVolume *m_pBottomFillerPhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pVacuumBottomFillerPhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pBottomFillerCoverPhysicalVolume;    //Marco Selvi

	G4VPhysicalVolume *m_pTopGridMeshPhysicalVolume;     //RINO
	G4VPhysicalVolume *m_pAnodeMeshPhysicalVolume;       //RINO
   	G4VPhysicalVolume *m_pGroundMeshPhysicalVolume;      //RINO
   	G4VPhysicalVolume *m_pCathodeMeshPhysicalVolume;     //RINO
	G4VPhysicalVolume *m_pBottomGridMeshPhysicalVolume;  //RINO

  //_________________________________________________________________________//
  G4VPhysicalVolume *m_pTopGridMesh_RingPhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pAnodeMesh_RingPhysicalVolume;       //Fabio Valerio
  G4VPhysicalVolume *m_pGroundMesh_RingPhysicalVolume;      //Fabio Valerio
  G4VPhysicalVolume *m_pCathodeMesh_RingPhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pCathode_Ring_2PhysicalVolume;     //Fabio Valerio
  G4VPhysicalVolume *m_pBottomGridMesh_RingPhysicalVolume;  //Fabio Valerio
  //__________________________________________________________________________//
  G4VPhysicalVolume *m_pLowerTeflonPhysicalVolume;         //Fabio Valerio
  //__________________________________________________________________________//
  
	G4VPhysicalVolume *m_pSidePTFEPhysicalVolume;
	G4VPhysicalVolume *m_pTopCopperPlatePhysicalVolume;
	G4VPhysicalVolume *m_pBottomCopperPlatePhysicalVolume;

	G4VPhysicalVolume *m_pSideAcrylicPhysicalVolume;

	vector<G4VPhysicalVolume *> m_hQUPIDWindowPhysicalVolumes;
	G4VPhysicalVolume *m_pQUPIDPhotocathodePhysicalVolume;
	G4VPhysicalVolume *m_pQUPIDPhotocathodeInteriorPhysicalVolume;
	vector<G4VPhysicalVolume *> m_hQUPIDBodyPhysicalVolumes;
	G4VPhysicalVolume *m_pQUPIDBodyAluminiumCoatingPhysicalVolume;
	G4VPhysicalVolume *m_pQUPIDBodyInteriorPhysicalVolume;
	G4VPhysicalVolume *m_pQUPIDAPDPhysicalVolume;
	vector<G4VPhysicalVolume *> m_hQUPIDBasePhysicalVolumes;
	G4VPhysicalVolume *m_pQUPIDBaseAluminiumCoatingPhysicalVolume;

	vector<G4VPhysicalVolume *> m_hPMTWindowPhysicalVolumes;
	G4VPhysicalVolume *m_pPMTPhotocathodePhysicalVolume;
	G4VPhysicalVolume *m_pPMTPhotocathodeInterior1PhysicalVolume;
	G4VPhysicalVolume *m_pPMTPhotocathodeInterior2PhysicalVolume;
	vector<G4VPhysicalVolume *> m_hPMTBodyPhysicalVolumes;
	G4VPhysicalVolume *m_pPMTBodyInteriorPhysicalVolume;
  vector<G4VPhysicalVolume *> m_hPMTBasePhysicalVolumes;
	G4VPhysicalVolume *m_pPMTBaseInteriorPhysicalVolume;
  
     //Neutron Generator
        Xenon1tNeutronGenerator * m_pNeutronGenerator; 
  
   // HVFT physical volumes
  G4VPhysicalVolume *m_pOuterSS_GXeHVFT_PhysicalVolume;  //Fabio Valerio
  G4VPhysicalVolume *m_pInnerPoly_GXeHVFT_PhysicalVolume;//Fabio Valerio
  G4VPhysicalVolume *m_pInnerAir_GXeHVFT_PhysicalVolume;            //Fabio Valerio
  G4VPhysicalVolume *m_pInnerSS_GXeHVFT_PhysicalVolume;             //Fabio Valerio
  G4VPhysicalVolume *m_pInnerInAir_GXeHVFT_PhysicalVolume;           //Fabio Valerio
  
  G4VPhysicalVolume *m_pOuterSS_HVFT_PhysicalVolume;  //Fabio Valerio
  G4VPhysicalVolume *m_pInnerPoly_HVFT_PhysicalVolume;//Fabio Valerio
  G4VPhysicalVolume *m_pInnerAir_HVFT_PhysicalVolume;            //Fabio Valerio
  G4VPhysicalVolume *m_pInnerSS_HVFT_PhysicalVolume;             //Fabio Valerio
  G4VPhysicalVolume *m_pInnerInAir_HVFT_PhysicalVolume;           //Fabio Valerio
  
  G4VPhysicalVolume *m_pBottom_Poly_HVFT_PhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_pBottom_InnerAir_HVFT_PhysicalVolume;          //Fabio Valerio
  G4VPhysicalVolume *m_pBottom_InnerSS_HVFT_PhysicalVolume;   //Fabio Valerio
  G4VPhysicalVolume *m_pBottom_InnerInAir_HVFT_PhysicalVolume;          //Fabio Valerio
  
  G4VPhysicalVolume *m_plast_bottom_SS_HVFT_PhysicalVolume;         //Fabio Valerio
  G4VPhysicalVolume *m_plast_bottom_Air_HVFT_PhysicalVolume;          //Fabio Valerio
  
  G4VPhysicalVolume *m_pPTFELayerCryoPhysicalVolume; // Cyril
  vector<G4VPhysicalVolume*> m_pPTFEInWallPhysicalVolume; // Cyril
  G4VPhysicalVolume *m_pPTFEAboveTPC1PhysicalVolume; // Cyril
  G4VPhysicalVolume *m_pPTFEAboveTPC2PhysicalVolume; // Cyril
  G4VPhysicalVolume *m_pPTFEBelowTPC1PhysicalVolume; // Cyril
  G4VPhysicalVolume *m_pPTFEBelowTPC2PhysicalVolume; // Cyril

	static map<G4String, G4double> m_hGeometryParameters;
	
	Xenon1tDetectorMessenger *m_pDetectorMessenger;

	Xenon1tPmtSensitiveDetector *pPmtSD;
	  
  // parameters for communications with Xenon1tGeometryMessenger
  G4String pCryostatType;
  G4String pCryostatMaterial;
  G4String pNeutronSourceSurroundings;
  G4double pCryostatInnerWallThickness;
  G4double pCryostatOuterWallThickness;
  G4bool   pTPC;
  G4bool   pCheckOverlap;
    G4String pMuonVetoMaterial;
    G4bool pFillBuffer;
    G4bool pTpcWithBell;
  G4bool pLXeVeto;
   G4double pBufferThickness;
  G4bool pFlagAcrylicBetweenPmt;
  G4bool pFlagHVFT;
  //G4UImanager *pUImanager;  
  
  // ROOT stuff
  TFile      *_fGeom;
  G4String    detRootFile;
  TDirectory *_detector;
  
  G4double dOuterCryostatMass;
  G4double dInnerCryostatMass;
  G4double dTotalCryostatMass;
	
  G4double OD_Inner_Requested;
  G4double OD_Outer_Requested;
};

#endif // __XENON10PDETECTORCONSTRUCTION_H__

