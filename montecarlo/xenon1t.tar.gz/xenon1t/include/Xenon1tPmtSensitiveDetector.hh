#ifndef __XENON10PPMTSENSITIVEDETECTOR_H__
#define __XENON10PPMTSENSITIVEDETECTOR_H__

#include <G4VSensitiveDetector.hh>

#include "Xenon1tPmtHit.hh"

class G4Step;
class G4HCofThisEvent;

class Xenon1tPmtSensitiveDetector: public G4VSensitiveDetector
{
public:
	Xenon1tPmtSensitiveDetector(G4String hName);
	~Xenon1tPmtSensitiveDetector();

	void Initialize(G4HCofThisEvent *pHitsCollectionOfThisEvent);
	G4bool ProcessHits(G4Step *pStep, G4TouchableHistory *pHistory);
	void EndOfEvent(G4HCofThisEvent *pHitsCollectionOfThisEvent);

private:
	Xenon1tPmtHitsCollection* m_pPmtHitsCollection;
};

#endif // __XENON10PPMTSENSITIVEDETECTOR_H__

