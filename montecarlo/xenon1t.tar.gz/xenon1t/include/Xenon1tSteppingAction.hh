#ifndef Xenon1tSteppingAction_H
#define Xenon1tSteppingAction_H 1

#include "G4UserSteppingAction.hh"
#include "globals.hh"

class Xenon1tAnalysisManager;

class Xenon1tSteppingAction : public G4UserSteppingAction
{
public:
  Xenon1tSteppingAction(Xenon1tAnalysisManager* );
  ~Xenon1tSteppingAction(){};

  void UserSteppingAction(const G4Step*);

private:

G4String particle;
Xenon1tAnalysisManager* myAnalysisManager;


};

#endif
