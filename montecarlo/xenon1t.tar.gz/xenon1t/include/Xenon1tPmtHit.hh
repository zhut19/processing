#ifndef __XENON10PPMTHIT_H__
#define __XENON10PPMTHIT_H__

#include <G4VHit.hh>
#include <G4THitsCollection.hh>
#include <G4Allocator.hh>
#include <G4ThreeVector.hh>

class Xenon1tPmtHit: public G4VHit
{
public:
	Xenon1tPmtHit();
	~Xenon1tPmtHit();
	Xenon1tPmtHit(const Xenon1tPmtHit &);
	const Xenon1tPmtHit & operator=(const Xenon1tPmtHit &);
	G4int operator==(const Xenon1tPmtHit &) const;

	inline void* operator new(size_t);
	inline void  operator delete(void*);

	void Draw();
	void Print();

public:
	void SetPosition(G4ThreeVector hPosition) { m_hPosition = hPosition; }
	void SetTime(G4double dTime) { m_dTime = dTime; }
	void SetPmtNb(G4int iPmtNb) { m_iPmtNb = iPmtNb; }

	G4ThreeVector GetPosition() { return m_hPosition; }
	G4double GetTime() { return m_dTime; }
	G4int GetPmtNb() { return m_iPmtNb; }

private:
	G4ThreeVector m_hPosition;
	G4double m_dTime;
	G4int m_iPmtNb;
};

typedef G4THitsCollection<Xenon1tPmtHit> Xenon1tPmtHitsCollection;

extern G4Allocator<Xenon1tPmtHit> Xenon1tPmtHitAllocator;

inline void*
Xenon1tPmtHit::operator new(size_t)
{
	return((void *) Xenon1tPmtHitAllocator.MallocSingle());
}

inline void
Xenon1tPmtHit::operator delete(void *pXenon1tPmtHit)
{
	Xenon1tPmtHitAllocator.FreeSingle((Xenon1tPmtHit*) pXenon1tPmtHit);
}

#endif // __XENON10PPMTHIT_H__

