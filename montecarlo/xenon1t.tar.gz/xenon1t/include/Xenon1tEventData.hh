#ifndef __XENON10PEVENTDATA_H__
#define __XENON10PEVENTDATA_H__

#include <string>
#include <vector>

using std::string;
using std::vector;

class Xenon1tEventData
{
public:
	 Xenon1tEventData();
	~Xenon1tEventData();

public:
	void Clear();

public:
	int m_iEventId;								// the event ID
	int m_iNbTopPmtHits;						// number of top pmt hits
	int m_iNbBottomPmtHits;						// number of bottom pmt hits
	int m_iNbLSPmtHits;						// number of LS pmt hits
	int m_iNbWaterPmtHits;						// number of water pmt hits
        int m_iNbLXeVetoBotPmtHits;	            			// number of lxe veto bottom pmt hits
        int m_iNbLXeVetoTopPmtHits;			 		// number of lxe veto top pmt hits
        int m_iNbLXeVetoBelowPmtHits;					// number of lxe veto below pmt hits
        int m_iNbLXeVetoAbovePmtHits;					// number of lxe veto above pmt hits
        int m_iNbLXeVetoCenterPmtHits;					// number of lxe veto center pmt hits
         vector<int> *m_pPmtHits;					// number of photon hits per pmt
	float m_fTotalEnergyDeposited;				// total energy deposited in the ScintSD
	int m_iNbSteps;								// number of energy depositing steps
	vector<int> *m_pTrackId;					// id of the particle
	vector<int> *m_pParentId;					// id of the parent particle
	vector<string> *m_pParticleType;			// type of particle
	vector<string> *m_pParentType;				// type of particle
	vector<string> *m_pCreatorProcess;			// interaction
	vector<string> *m_pDepositingProcess;		// energy depositing process
	vector<float> *m_pX;						// position of the step
	vector<float> *m_pY;
	vector<float> *m_pZ;
	vector<float> *m_pEnergyDeposited; 			// energy deposited in the step
	vector<float> *m_pKineticEnergy;			// track kinetic energy	
  	vector<float> *m_pPreStepEnergy;			// pre-step particle energy	
    vector<float> *m_pPostStepEnergy;			// post-step particle energy
	vector<float> *m_pTime;						// time of the step
	vector<string> *m_pPrimaryParticleType;		// type of particle
	float m_fPrimaryX;							// position of the primary particle
	float m_fPrimaryY;
	float m_fPrimaryZ;	
	float m_fForcedPrimaryX;							// position of the primary particle
	float m_fForcedPrimaryY;
	float m_fForcedPrimaryZ;	
  float m_fPrimaryE;	
  float m_fPrimaryW;	

 //MS In the following bank we save particle information in various positions, for ex. 
  //- entering the OuterCryostat from outside ... i.e. those crossing the whole shield
  //- neutron capture in the water or LS shield
  //NOT YET- optical photons when touching the tank surfaces
  //NOT YET- entering the active LXe volume (between anode and cathode)

  int	m_iNSave;              //
  vector<int> *m_pSave_flag;
  vector<int> *m_pSave_type;
  vector<float> *m_pSave_x;
  vector<float> *m_pSave_y;
  vector<float> *m_pSave_z;
  vector<float> *m_pSave_cx;
  vector<float> *m_pSave_cy;
  vector<float> *m_pSave_cz;
  vector<float> *m_pSave_e;
  vector<float> *m_pSave_t;
  vector<int> *m_pSave_trkid;

};

#endif // __XENON10PEVENTDATA_H__

